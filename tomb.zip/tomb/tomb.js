(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });
  var __commonJS = (cb, mod) => function __require2() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/internal/constants.js
  var require_constants = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/internal/constants.js"(exports, module) {
      var SEMVER_SPEC_VERSION = "2.0.0";
      var MAX_LENGTH = 256;
      var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || /* istanbul ignore next */
      9007199254740991;
      var MAX_SAFE_COMPONENT_LENGTH = 16;
      var MAX_SAFE_BUILD_LENGTH = MAX_LENGTH - 6;
      var RELEASE_TYPES = [
        "major",
        "premajor",
        "minor",
        "preminor",
        "patch",
        "prepatch",
        "prerelease"
      ];
      module.exports = {
        MAX_LENGTH,
        MAX_SAFE_COMPONENT_LENGTH,
        MAX_SAFE_BUILD_LENGTH,
        MAX_SAFE_INTEGER,
        RELEASE_TYPES,
        SEMVER_SPEC_VERSION,
        FLAG_INCLUDE_PRERELEASE: 1,
        FLAG_LOOSE: 2
      };
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/internal/debug.js
  var require_debug = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/internal/debug.js"(exports, module) {
      var debug = typeof process === "object" && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {
      };
      module.exports = debug;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/internal/re.js
  var require_re = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/internal/re.js"(exports, module) {
      var {
        MAX_SAFE_COMPONENT_LENGTH,
        MAX_SAFE_BUILD_LENGTH,
        MAX_LENGTH
      } = require_constants();
      var debug = require_debug();
      exports = module.exports = {};
      var re = exports.re = [];
      var safeRe = exports.safeRe = [];
      var src = exports.src = [];
      var t = exports.t = {};
      var R = 0;
      var LETTERDASHNUMBER = "[a-zA-Z0-9-]";
      var safeRegexReplacements = [
        ["\\s", 1],
        ["\\d", MAX_LENGTH],
        [LETTERDASHNUMBER, MAX_SAFE_BUILD_LENGTH]
      ];
      var makeSafeRegex = (value) => {
        for (const [token, max] of safeRegexReplacements) {
          value = value.split(`${token}*`).join(`${token}{0,${max}}`).split(`${token}+`).join(`${token}{1,${max}}`);
        }
        return value;
      };
      var createToken = (name, value, isGlobal) => {
        const safe = makeSafeRegex(value);
        const index = R++;
        debug(name, index, value);
        t[name] = index;
        src[index] = value;
        re[index] = new RegExp(value, isGlobal ? "g" : void 0);
        safeRe[index] = new RegExp(safe, isGlobal ? "g" : void 0);
      };
      createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
      createToken("NUMERICIDENTIFIERLOOSE", "\\d+");
      createToken("NONNUMERICIDENTIFIER", `\\d*[a-zA-Z-]${LETTERDASHNUMBER}*`);
      createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})`);
      createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})`);
      createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NUMERICIDENTIFIER]}|${src[t.NONNUMERICIDENTIFIER]})`);
      createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NUMERICIDENTIFIERLOOSE]}|${src[t.NONNUMERICIDENTIFIER]})`);
      createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
      createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
      createToken("BUILDIDENTIFIER", `${LETTERDASHNUMBER}+`);
      createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
      createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
      createToken("FULL", `^${src[t.FULLPLAIN]}$`);
      createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
      createToken("LOOSE", `^${src[t.LOOSEPLAIN]}$`);
      createToken("GTLT", "((?:<|>)?=?)");
      createToken("XRANGEIDENTIFIERLOOSE", `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`);
      createToken("XRANGEIDENTIFIER", `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`);
      createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?)?)?`);
      createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?)?)?`);
      createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`);
      createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`);
      createToken("COERCEPLAIN", `${"(^|[^\\d])(\\d{1,"}${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?`);
      createToken("COERCE", `${src[t.COERCEPLAIN]}(?:$|[^\\d])`);
      createToken("COERCEFULL", src[t.COERCEPLAIN] + `(?:${src[t.PRERELEASE]})?(?:${src[t.BUILD]})?(?:$|[^\\d])`);
      createToken("COERCERTL", src[t.COERCE], true);
      createToken("COERCERTLFULL", src[t.COERCEFULL], true);
      createToken("LONETILDE", "(?:~>?)");
      createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
      exports.tildeTrimReplace = "$1~";
      createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`);
      createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`);
      createToken("LONECARET", "(?:\\^)");
      createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
      exports.caretTrimReplace = "$1^";
      createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`);
      createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`);
      createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`);
      createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`);
      createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
      exports.comparatorTrimReplace = "$1$2$3";
      createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})\\s+-\\s+(${src[t.XRANGEPLAIN]})\\s*$`);
      createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t.XRANGEPLAINLOOSE]})\\s*$`);
      createToken("STAR", "(<|>)?=?\\s*\\*");
      createToken("GTE0", "^\\s*>=\\s*0\\.0\\.0\\s*$");
      createToken("GTE0PRE", "^\\s*>=\\s*0\\.0\\.0-0\\s*$");
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/internal/parse-options.js
  var require_parse_options = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/internal/parse-options.js"(exports, module) {
      var looseOption = Object.freeze({ loose: true });
      var emptyOpts = Object.freeze({});
      var parseOptions = (options) => {
        if (!options) {
          return emptyOpts;
        }
        if (typeof options !== "object") {
          return looseOption;
        }
        return options;
      };
      module.exports = parseOptions;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/internal/identifiers.js
  var require_identifiers = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/internal/identifiers.js"(exports, module) {
      var numeric = /^[0-9]+$/;
      var compareIdentifiers = (a, b) => {
        const anum = numeric.test(a);
        const bnum = numeric.test(b);
        if (anum && bnum) {
          a = +a;
          b = +b;
        }
        return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
      };
      var rcompareIdentifiers = (a, b) => compareIdentifiers(b, a);
      module.exports = {
        compareIdentifiers,
        rcompareIdentifiers
      };
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/classes/semver.js
  var require_semver = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/classes/semver.js"(exports, module) {
      var debug = require_debug();
      var { MAX_LENGTH, MAX_SAFE_INTEGER } = require_constants();
      var { safeRe: re, t } = require_re();
      var parseOptions = require_parse_options();
      var { compareIdentifiers } = require_identifiers();
      var SemVer = class _SemVer {
        constructor(version, options) {
          options = parseOptions(options);
          if (version instanceof _SemVer) {
            if (version.loose === !!options.loose && version.includePrerelease === !!options.includePrerelease) {
              return version;
            } else {
              version = version.version;
            }
          } else if (typeof version !== "string") {
            throw new TypeError(`Invalid version. Must be a string. Got type "${typeof version}".`);
          }
          if (version.length > MAX_LENGTH) {
            throw new TypeError(
              `version is longer than ${MAX_LENGTH} characters`
            );
          }
          debug("SemVer", version, options);
          this.options = options;
          this.loose = !!options.loose;
          this.includePrerelease = !!options.includePrerelease;
          const m = version.trim().match(options.loose ? re[t.LOOSE] : re[t.FULL]);
          if (!m) {
            throw new TypeError(`Invalid Version: ${version}`);
          }
          this.raw = version;
          this.major = +m[1];
          this.minor = +m[2];
          this.patch = +m[3];
          if (this.major > MAX_SAFE_INTEGER || this.major < 0) {
            throw new TypeError("Invalid major version");
          }
          if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) {
            throw new TypeError("Invalid minor version");
          }
          if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) {
            throw new TypeError("Invalid patch version");
          }
          if (!m[4]) {
            this.prerelease = [];
          } else {
            this.prerelease = m[4].split(".").map((id) => {
              if (/^[0-9]+$/.test(id)) {
                const num = +id;
                if (num >= 0 && num < MAX_SAFE_INTEGER) {
                  return num;
                }
              }
              return id;
            });
          }
          this.build = m[5] ? m[5].split(".") : [];
          this.format();
        }
        format() {
          this.version = `${this.major}.${this.minor}.${this.patch}`;
          if (this.prerelease.length) {
            this.version += `-${this.prerelease.join(".")}`;
          }
          return this.version;
        }
        toString() {
          return this.version;
        }
        compare(other) {
          debug("SemVer.compare", this.version, this.options, other);
          if (!(other instanceof _SemVer)) {
            if (typeof other === "string" && other === this.version) {
              return 0;
            }
            other = new _SemVer(other, this.options);
          }
          if (other.version === this.version) {
            return 0;
          }
          return this.compareMain(other) || this.comparePre(other);
        }
        compareMain(other) {
          if (!(other instanceof _SemVer)) {
            other = new _SemVer(other, this.options);
          }
          return compareIdentifiers(this.major, other.major) || compareIdentifiers(this.minor, other.minor) || compareIdentifiers(this.patch, other.patch);
        }
        comparePre(other) {
          if (!(other instanceof _SemVer)) {
            other = new _SemVer(other, this.options);
          }
          if (this.prerelease.length && !other.prerelease.length) {
            return -1;
          } else if (!this.prerelease.length && other.prerelease.length) {
            return 1;
          } else if (!this.prerelease.length && !other.prerelease.length) {
            return 0;
          }
          let i = 0;
          do {
            const a = this.prerelease[i];
            const b = other.prerelease[i];
            debug("prerelease compare", i, a, b);
            if (a === void 0 && b === void 0) {
              return 0;
            } else if (b === void 0) {
              return 1;
            } else if (a === void 0) {
              return -1;
            } else if (a === b) {
              continue;
            } else {
              return compareIdentifiers(a, b);
            }
          } while (++i);
        }
        compareBuild(other) {
          if (!(other instanceof _SemVer)) {
            other = new _SemVer(other, this.options);
          }
          let i = 0;
          do {
            const a = this.build[i];
            const b = other.build[i];
            debug("prerelease compare", i, a, b);
            if (a === void 0 && b === void 0) {
              return 0;
            } else if (b === void 0) {
              return 1;
            } else if (a === void 0) {
              return -1;
            } else if (a === b) {
              continue;
            } else {
              return compareIdentifiers(a, b);
            }
          } while (++i);
        }
        // preminor will bump the version up to the next minor release, and immediately
        // down to pre-release. premajor and prepatch work the same way.
        inc(release, identifier, identifierBase) {
          switch (release) {
            case "premajor":
              this.prerelease.length = 0;
              this.patch = 0;
              this.minor = 0;
              this.major++;
              this.inc("pre", identifier, identifierBase);
              break;
            case "preminor":
              this.prerelease.length = 0;
              this.patch = 0;
              this.minor++;
              this.inc("pre", identifier, identifierBase);
              break;
            case "prepatch":
              this.prerelease.length = 0;
              this.inc("patch", identifier, identifierBase);
              this.inc("pre", identifier, identifierBase);
              break;
            case "prerelease":
              if (this.prerelease.length === 0) {
                this.inc("patch", identifier, identifierBase);
              }
              this.inc("pre", identifier, identifierBase);
              break;
            case "major":
              if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0) {
                this.major++;
              }
              this.minor = 0;
              this.patch = 0;
              this.prerelease = [];
              break;
            case "minor":
              if (this.patch !== 0 || this.prerelease.length === 0) {
                this.minor++;
              }
              this.patch = 0;
              this.prerelease = [];
              break;
            case "patch":
              if (this.prerelease.length === 0) {
                this.patch++;
              }
              this.prerelease = [];
              break;
            case "pre": {
              const base = Number(identifierBase) ? 1 : 0;
              if (!identifier && identifierBase === false) {
                throw new Error("invalid increment argument: identifier is empty");
              }
              if (this.prerelease.length === 0) {
                this.prerelease = [base];
              } else {
                let i = this.prerelease.length;
                while (--i >= 0) {
                  if (typeof this.prerelease[i] === "number") {
                    this.prerelease[i]++;
                    i = -2;
                  }
                }
                if (i === -1) {
                  if (identifier === this.prerelease.join(".") && identifierBase === false) {
                    throw new Error("invalid increment argument: identifier already exists");
                  }
                  this.prerelease.push(base);
                }
              }
              if (identifier) {
                let prerelease = [identifier, base];
                if (identifierBase === false) {
                  prerelease = [identifier];
                }
                if (compareIdentifiers(this.prerelease[0], identifier) === 0) {
                  if (isNaN(this.prerelease[1])) {
                    this.prerelease = prerelease;
                  }
                } else {
                  this.prerelease = prerelease;
                }
              }
              break;
            }
            default:
              throw new Error(`invalid increment argument: ${release}`);
          }
          this.raw = this.format();
          if (this.build.length) {
            this.raw += `+${this.build.join(".")}`;
          }
          return this;
        }
      };
      module.exports = SemVer;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/parse.js
  var require_parse = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/parse.js"(exports, module) {
      var SemVer = require_semver();
      var parse = (version, options, throwErrors = false) => {
        if (version instanceof SemVer) {
          return version;
        }
        try {
          return new SemVer(version, options);
        } catch (er) {
          if (!throwErrors) {
            return null;
          }
          throw er;
        }
      };
      module.exports = parse;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/valid.js
  var require_valid = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/valid.js"(exports, module) {
      var parse = require_parse();
      var valid = (version, options) => {
        const v = parse(version, options);
        return v ? v.version : null;
      };
      module.exports = valid;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/clean.js
  var require_clean = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/clean.js"(exports, module) {
      var parse = require_parse();
      var clean = (version, options) => {
        const s2 = parse(version.trim().replace(/^[=v]+/, ""), options);
        return s2 ? s2.version : null;
      };
      module.exports = clean;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/inc.js
  var require_inc = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/inc.js"(exports, module) {
      var SemVer = require_semver();
      var inc = (version, release, options, identifier, identifierBase) => {
        if (typeof options === "string") {
          identifierBase = identifier;
          identifier = options;
          options = void 0;
        }
        try {
          return new SemVer(
            version instanceof SemVer ? version.version : version,
            options
          ).inc(release, identifier, identifierBase).version;
        } catch (er) {
          return null;
        }
      };
      module.exports = inc;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/diff.js
  var require_diff = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/diff.js"(exports, module) {
      var parse = require_parse();
      var diff = (version1, version2) => {
        const v1 = parse(version1, null, true);
        const v2 = parse(version2, null, true);
        const comparison = v1.compare(v2);
        if (comparison === 0) {
          return null;
        }
        const v1Higher = comparison > 0;
        const highVersion = v1Higher ? v1 : v2;
        const lowVersion = v1Higher ? v2 : v1;
        const highHasPre = !!highVersion.prerelease.length;
        const lowHasPre = !!lowVersion.prerelease.length;
        if (lowHasPre && !highHasPre) {
          if (!lowVersion.patch && !lowVersion.minor) {
            return "major";
          }
          if (highVersion.patch) {
            return "patch";
          }
          if (highVersion.minor) {
            return "minor";
          }
          return "major";
        }
        const prefix = highHasPre ? "pre" : "";
        if (v1.major !== v2.major) {
          return prefix + "major";
        }
        if (v1.minor !== v2.minor) {
          return prefix + "minor";
        }
        if (v1.patch !== v2.patch) {
          return prefix + "patch";
        }
        return "prerelease";
      };
      module.exports = diff;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/major.js
  var require_major = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/major.js"(exports, module) {
      var SemVer = require_semver();
      var major = (a, loose) => new SemVer(a, loose).major;
      module.exports = major;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/minor.js
  var require_minor = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/minor.js"(exports, module) {
      var SemVer = require_semver();
      var minor = (a, loose) => new SemVer(a, loose).minor;
      module.exports = minor;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/patch.js
  var require_patch = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/patch.js"(exports, module) {
      var SemVer = require_semver();
      var patch = (a, loose) => new SemVer(a, loose).patch;
      module.exports = patch;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/prerelease.js
  var require_prerelease = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/prerelease.js"(exports, module) {
      var parse = require_parse();
      var prerelease = (version, options) => {
        const parsed = parse(version, options);
        return parsed && parsed.prerelease.length ? parsed.prerelease : null;
      };
      module.exports = prerelease;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/compare.js
  var require_compare = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/compare.js"(exports, module) {
      var SemVer = require_semver();
      var compare2 = (a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose));
      module.exports = compare2;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/rcompare.js
  var require_rcompare = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/rcompare.js"(exports, module) {
      var compare2 = require_compare();
      var rcompare = (a, b, loose) => compare2(b, a, loose);
      module.exports = rcompare;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/compare-loose.js
  var require_compare_loose = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/compare-loose.js"(exports, module) {
      var compare2 = require_compare();
      var compareLoose = (a, b) => compare2(a, b, true);
      module.exports = compareLoose;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/compare-build.js
  var require_compare_build = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/compare-build.js"(exports, module) {
      var SemVer = require_semver();
      var compareBuild = (a, b, loose) => {
        const versionA = new SemVer(a, loose);
        const versionB = new SemVer(b, loose);
        return versionA.compare(versionB) || versionA.compareBuild(versionB);
      };
      module.exports = compareBuild;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/sort.js
  var require_sort = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/sort.js"(exports, module) {
      var compareBuild = require_compare_build();
      var sort = (list, loose) => list.sort((a, b) => compareBuild(a, b, loose));
      module.exports = sort;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/rsort.js
  var require_rsort = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/rsort.js"(exports, module) {
      var compareBuild = require_compare_build();
      var rsort = (list, loose) => list.sort((a, b) => compareBuild(b, a, loose));
      module.exports = rsort;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/gt.js
  var require_gt = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/gt.js"(exports, module) {
      var compare2 = require_compare();
      var gt = (a, b, loose) => compare2(a, b, loose) > 0;
      module.exports = gt;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/lt.js
  var require_lt = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/lt.js"(exports, module) {
      var compare2 = require_compare();
      var lt = (a, b, loose) => compare2(a, b, loose) < 0;
      module.exports = lt;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/eq.js
  var require_eq = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/eq.js"(exports, module) {
      var compare2 = require_compare();
      var eq = (a, b, loose) => compare2(a, b, loose) === 0;
      module.exports = eq;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/neq.js
  var require_neq = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/neq.js"(exports, module) {
      var compare2 = require_compare();
      var neq = (a, b, loose) => compare2(a, b, loose) !== 0;
      module.exports = neq;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/gte.js
  var require_gte = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/gte.js"(exports, module) {
      var compare2 = require_compare();
      var gte = (a, b, loose) => compare2(a, b, loose) >= 0;
      module.exports = gte;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/lte.js
  var require_lte = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/lte.js"(exports, module) {
      var compare2 = require_compare();
      var lte = (a, b, loose) => compare2(a, b, loose) <= 0;
      module.exports = lte;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/cmp.js
  var require_cmp = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/cmp.js"(exports, module) {
      var eq = require_eq();
      var neq = require_neq();
      var gt = require_gt();
      var gte = require_gte();
      var lt = require_lt();
      var lte = require_lte();
      var cmp = (a, op, b, loose) => {
        switch (op) {
          case "===":
            if (typeof a === "object") {
              a = a.version;
            }
            if (typeof b === "object") {
              b = b.version;
            }
            return a === b;
          case "!==":
            if (typeof a === "object") {
              a = a.version;
            }
            if (typeof b === "object") {
              b = b.version;
            }
            return a !== b;
          case "":
          case "=":
          case "==":
            return eq(a, b, loose);
          case "!=":
            return neq(a, b, loose);
          case ">":
            return gt(a, b, loose);
          case ">=":
            return gte(a, b, loose);
          case "<":
            return lt(a, b, loose);
          case "<=":
            return lte(a, b, loose);
          default:
            throw new TypeError(`Invalid operator: ${op}`);
        }
      };
      module.exports = cmp;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/coerce.js
  var require_coerce = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/coerce.js"(exports, module) {
      var SemVer = require_semver();
      var parse = require_parse();
      var { safeRe: re, t } = require_re();
      var coerce = (version, options) => {
        if (version instanceof SemVer) {
          return version;
        }
        if (typeof version === "number") {
          version = String(version);
        }
        if (typeof version !== "string") {
          return null;
        }
        options = options || {};
        let match = null;
        if (!options.rtl) {
          match = version.match(options.includePrerelease ? re[t.COERCEFULL] : re[t.COERCE]);
        } else {
          const coerceRtlRegex = options.includePrerelease ? re[t.COERCERTLFULL] : re[t.COERCERTL];
          let next;
          while ((next = coerceRtlRegex.exec(version)) && (!match || match.index + match[0].length !== version.length)) {
            if (!match || next.index + next[0].length !== match.index + match[0].length) {
              match = next;
            }
            coerceRtlRegex.lastIndex = next.index + next[1].length + next[2].length;
          }
          coerceRtlRegex.lastIndex = -1;
        }
        if (match === null) {
          return null;
        }
        const major = match[2];
        const minor = match[3] || "0";
        const patch = match[4] || "0";
        const prerelease = options.includePrerelease && match[5] ? `-${match[5]}` : "";
        const build = options.includePrerelease && match[6] ? `+${match[6]}` : "";
        return parse(`${major}.${minor}.${patch}${prerelease}${build}`, options);
      };
      module.exports = coerce;
    }
  });

  // node_modules/.pnpm/yallist@4.0.0/node_modules/yallist/iterator.js
  var require_iterator = __commonJS({
    "node_modules/.pnpm/yallist@4.0.0/node_modules/yallist/iterator.js"(exports, module) {
      "use strict";
      module.exports = function(Yallist) {
        Yallist.prototype[Symbol.iterator] = function* () {
          for (let walker = this.head; walker; walker = walker.next) {
            yield walker.value;
          }
        };
      };
    }
  });

  // node_modules/.pnpm/yallist@4.0.0/node_modules/yallist/yallist.js
  var require_yallist = __commonJS({
    "node_modules/.pnpm/yallist@4.0.0/node_modules/yallist/yallist.js"(exports, module) {
      "use strict";
      module.exports = Yallist;
      Yallist.Node = Node;
      Yallist.create = Yallist;
      function Yallist(list) {
        var self = this;
        if (!(self instanceof Yallist)) {
          self = new Yallist();
        }
        self.tail = null;
        self.head = null;
        self.length = 0;
        if (list && typeof list.forEach === "function") {
          list.forEach(function(item) {
            self.push(item);
          });
        } else if (arguments.length > 0) {
          for (var i = 0, l = arguments.length; i < l; i++) {
            self.push(arguments[i]);
          }
        }
        return self;
      }
      Yallist.prototype.removeNode = function(node) {
        if (node.list !== this) {
          throw new Error("removing node which does not belong to this list");
        }
        var next = node.next;
        var prev = node.prev;
        if (next) {
          next.prev = prev;
        }
        if (prev) {
          prev.next = next;
        }
        if (node === this.head) {
          this.head = next;
        }
        if (node === this.tail) {
          this.tail = prev;
        }
        node.list.length--;
        node.next = null;
        node.prev = null;
        node.list = null;
        return next;
      };
      Yallist.prototype.unshiftNode = function(node) {
        if (node === this.head) {
          return;
        }
        if (node.list) {
          node.list.removeNode(node);
        }
        var head = this.head;
        node.list = this;
        node.next = head;
        if (head) {
          head.prev = node;
        }
        this.head = node;
        if (!this.tail) {
          this.tail = node;
        }
        this.length++;
      };
      Yallist.prototype.pushNode = function(node) {
        if (node === this.tail) {
          return;
        }
        if (node.list) {
          node.list.removeNode(node);
        }
        var tail = this.tail;
        node.list = this;
        node.prev = tail;
        if (tail) {
          tail.next = node;
        }
        this.tail = node;
        if (!this.head) {
          this.head = node;
        }
        this.length++;
      };
      Yallist.prototype.push = function() {
        for (var i = 0, l = arguments.length; i < l; i++) {
          push(this, arguments[i]);
        }
        return this.length;
      };
      Yallist.prototype.unshift = function() {
        for (var i = 0, l = arguments.length; i < l; i++) {
          unshift(this, arguments[i]);
        }
        return this.length;
      };
      Yallist.prototype.pop = function() {
        if (!this.tail) {
          return void 0;
        }
        var res = this.tail.value;
        this.tail = this.tail.prev;
        if (this.tail) {
          this.tail.next = null;
        } else {
          this.head = null;
        }
        this.length--;
        return res;
      };
      Yallist.prototype.shift = function() {
        if (!this.head) {
          return void 0;
        }
        var res = this.head.value;
        this.head = this.head.next;
        if (this.head) {
          this.head.prev = null;
        } else {
          this.tail = null;
        }
        this.length--;
        return res;
      };
      Yallist.prototype.forEach = function(fn, thisp) {
        thisp = thisp || this;
        for (var walker = this.head, i = 0; walker !== null; i++) {
          fn.call(thisp, walker.value, i, this);
          walker = walker.next;
        }
      };
      Yallist.prototype.forEachReverse = function(fn, thisp) {
        thisp = thisp || this;
        for (var walker = this.tail, i = this.length - 1; walker !== null; i--) {
          fn.call(thisp, walker.value, i, this);
          walker = walker.prev;
        }
      };
      Yallist.prototype.get = function(n) {
        for (var i = 0, walker = this.head; walker !== null && i < n; i++) {
          walker = walker.next;
        }
        if (i === n && walker !== null) {
          return walker.value;
        }
      };
      Yallist.prototype.getReverse = function(n) {
        for (var i = 0, walker = this.tail; walker !== null && i < n; i++) {
          walker = walker.prev;
        }
        if (i === n && walker !== null) {
          return walker.value;
        }
      };
      Yallist.prototype.map = function(fn, thisp) {
        thisp = thisp || this;
        var res = new Yallist();
        for (var walker = this.head; walker !== null; ) {
          res.push(fn.call(thisp, walker.value, this));
          walker = walker.next;
        }
        return res;
      };
      Yallist.prototype.mapReverse = function(fn, thisp) {
        thisp = thisp || this;
        var res = new Yallist();
        for (var walker = this.tail; walker !== null; ) {
          res.push(fn.call(thisp, walker.value, this));
          walker = walker.prev;
        }
        return res;
      };
      Yallist.prototype.reduce = function(fn, initial) {
        var acc;
        var walker = this.head;
        if (arguments.length > 1) {
          acc = initial;
        } else if (this.head) {
          walker = this.head.next;
          acc = this.head.value;
        } else {
          throw new TypeError("Reduce of empty list with no initial value");
        }
        for (var i = 0; walker !== null; i++) {
          acc = fn(acc, walker.value, i);
          walker = walker.next;
        }
        return acc;
      };
      Yallist.prototype.reduceReverse = function(fn, initial) {
        var acc;
        var walker = this.tail;
        if (arguments.length > 1) {
          acc = initial;
        } else if (this.tail) {
          walker = this.tail.prev;
          acc = this.tail.value;
        } else {
          throw new TypeError("Reduce of empty list with no initial value");
        }
        for (var i = this.length - 1; walker !== null; i--) {
          acc = fn(acc, walker.value, i);
          walker = walker.prev;
        }
        return acc;
      };
      Yallist.prototype.toArray = function() {
        var arr = new Array(this.length);
        for (var i = 0, walker = this.head; walker !== null; i++) {
          arr[i] = walker.value;
          walker = walker.next;
        }
        return arr;
      };
      Yallist.prototype.toArrayReverse = function() {
        var arr = new Array(this.length);
        for (var i = 0, walker = this.tail; walker !== null; i++) {
          arr[i] = walker.value;
          walker = walker.prev;
        }
        return arr;
      };
      Yallist.prototype.slice = function(from, to) {
        to = to || this.length;
        if (to < 0) {
          to += this.length;
        }
        from = from || 0;
        if (from < 0) {
          from += this.length;
        }
        var ret = new Yallist();
        if (to < from || to < 0) {
          return ret;
        }
        if (from < 0) {
          from = 0;
        }
        if (to > this.length) {
          to = this.length;
        }
        for (var i = 0, walker = this.head; walker !== null && i < from; i++) {
          walker = walker.next;
        }
        for (; walker !== null && i < to; i++, walker = walker.next) {
          ret.push(walker.value);
        }
        return ret;
      };
      Yallist.prototype.sliceReverse = function(from, to) {
        to = to || this.length;
        if (to < 0) {
          to += this.length;
        }
        from = from || 0;
        if (from < 0) {
          from += this.length;
        }
        var ret = new Yallist();
        if (to < from || to < 0) {
          return ret;
        }
        if (from < 0) {
          from = 0;
        }
        if (to > this.length) {
          to = this.length;
        }
        for (var i = this.length, walker = this.tail; walker !== null && i > to; i--) {
          walker = walker.prev;
        }
        for (; walker !== null && i > from; i--, walker = walker.prev) {
          ret.push(walker.value);
        }
        return ret;
      };
      Yallist.prototype.splice = function(start, deleteCount, ...nodes) {
        if (start > this.length) {
          start = this.length - 1;
        }
        if (start < 0) {
          start = this.length + start;
        }
        for (var i = 0, walker = this.head; walker !== null && i < start; i++) {
          walker = walker.next;
        }
        var ret = [];
        for (var i = 0; walker && i < deleteCount; i++) {
          ret.push(walker.value);
          walker = this.removeNode(walker);
        }
        if (walker === null) {
          walker = this.tail;
        }
        if (walker !== this.head && walker !== this.tail) {
          walker = walker.prev;
        }
        for (var i = 0; i < nodes.length; i++) {
          walker = insert(this, walker, nodes[i]);
        }
        return ret;
      };
      Yallist.prototype.reverse = function() {
        var head = this.head;
        var tail = this.tail;
        for (var walker = head; walker !== null; walker = walker.prev) {
          var p = walker.prev;
          walker.prev = walker.next;
          walker.next = p;
        }
        this.head = tail;
        this.tail = head;
        return this;
      };
      function insert(self, node, value) {
        var inserted = node === self.head ? new Node(value, null, node, self) : new Node(value, node, node.next, self);
        if (inserted.next === null) {
          self.tail = inserted;
        }
        if (inserted.prev === null) {
          self.head = inserted;
        }
        self.length++;
        return inserted;
      }
      function push(self, item) {
        self.tail = new Node(item, self.tail, null, self);
        if (!self.head) {
          self.head = self.tail;
        }
        self.length++;
      }
      function unshift(self, item) {
        self.head = new Node(item, null, self.head, self);
        if (!self.tail) {
          self.tail = self.head;
        }
        self.length++;
      }
      function Node(value, prev, next, list) {
        if (!(this instanceof Node)) {
          return new Node(value, prev, next, list);
        }
        this.list = list;
        this.value = value;
        if (prev) {
          prev.next = this;
          this.prev = prev;
        } else {
          this.prev = null;
        }
        if (next) {
          next.prev = this;
          this.next = next;
        } else {
          this.next = null;
        }
      }
      try {
        require_iterator()(Yallist);
      } catch (er) {
      }
    }
  });

  // node_modules/.pnpm/lru-cache@6.0.0/node_modules/lru-cache/index.js
  var require_lru_cache = __commonJS({
    "node_modules/.pnpm/lru-cache@6.0.0/node_modules/lru-cache/index.js"(exports, module) {
      "use strict";
      var Yallist = require_yallist();
      var MAX = Symbol("max");
      var LENGTH = Symbol("length");
      var LENGTH_CALCULATOR = Symbol("lengthCalculator");
      var ALLOW_STALE = Symbol("allowStale");
      var MAX_AGE = Symbol("maxAge");
      var DISPOSE = Symbol("dispose");
      var NO_DISPOSE_ON_SET = Symbol("noDisposeOnSet");
      var LRU_LIST = Symbol("lruList");
      var CACHE = Symbol("cache");
      var UPDATE_AGE_ON_GET = Symbol("updateAgeOnGet");
      var naiveLength = () => 1;
      var LRUCache = class {
        constructor(options) {
          if (typeof options === "number")
            options = { max: options };
          if (!options)
            options = {};
          if (options.max && (typeof options.max !== "number" || options.max < 0))
            throw new TypeError("max must be a non-negative number");
          const max = this[MAX] = options.max || Infinity;
          const lc = options.length || naiveLength;
          this[LENGTH_CALCULATOR] = typeof lc !== "function" ? naiveLength : lc;
          this[ALLOW_STALE] = options.stale || false;
          if (options.maxAge && typeof options.maxAge !== "number")
            throw new TypeError("maxAge must be a number");
          this[MAX_AGE] = options.maxAge || 0;
          this[DISPOSE] = options.dispose;
          this[NO_DISPOSE_ON_SET] = options.noDisposeOnSet || false;
          this[UPDATE_AGE_ON_GET] = options.updateAgeOnGet || false;
          this.reset();
        }
        // resize the cache when the max changes.
        set max(mL) {
          if (typeof mL !== "number" || mL < 0)
            throw new TypeError("max must be a non-negative number");
          this[MAX] = mL || Infinity;
          trim(this);
        }
        get max() {
          return this[MAX];
        }
        set allowStale(allowStale) {
          this[ALLOW_STALE] = !!allowStale;
        }
        get allowStale() {
          return this[ALLOW_STALE];
        }
        set maxAge(mA) {
          if (typeof mA !== "number")
            throw new TypeError("maxAge must be a non-negative number");
          this[MAX_AGE] = mA;
          trim(this);
        }
        get maxAge() {
          return this[MAX_AGE];
        }
        // resize the cache when the lengthCalculator changes.
        set lengthCalculator(lC) {
          if (typeof lC !== "function")
            lC = naiveLength;
          if (lC !== this[LENGTH_CALCULATOR]) {
            this[LENGTH_CALCULATOR] = lC;
            this[LENGTH] = 0;
            this[LRU_LIST].forEach((hit) => {
              hit.length = this[LENGTH_CALCULATOR](hit.value, hit.key);
              this[LENGTH] += hit.length;
            });
          }
          trim(this);
        }
        get lengthCalculator() {
          return this[LENGTH_CALCULATOR];
        }
        get length() {
          return this[LENGTH];
        }
        get itemCount() {
          return this[LRU_LIST].length;
        }
        rforEach(fn, thisp) {
          thisp = thisp || this;
          for (let walker = this[LRU_LIST].tail; walker !== null; ) {
            const prev = walker.prev;
            forEachStep(this, fn, walker, thisp);
            walker = prev;
          }
        }
        forEach(fn, thisp) {
          thisp = thisp || this;
          for (let walker = this[LRU_LIST].head; walker !== null; ) {
            const next = walker.next;
            forEachStep(this, fn, walker, thisp);
            walker = next;
          }
        }
        keys() {
          return this[LRU_LIST].toArray().map((k) => k.key);
        }
        values() {
          return this[LRU_LIST].toArray().map((k) => k.value);
        }
        reset() {
          if (this[DISPOSE] && this[LRU_LIST] && this[LRU_LIST].length) {
            this[LRU_LIST].forEach((hit) => this[DISPOSE](hit.key, hit.value));
          }
          this[CACHE] = /* @__PURE__ */ new Map();
          this[LRU_LIST] = new Yallist();
          this[LENGTH] = 0;
        }
        dump() {
          return this[LRU_LIST].map((hit) => isStale(this, hit) ? false : {
            k: hit.key,
            v: hit.value,
            e: hit.now + (hit.maxAge || 0)
          }).toArray().filter((h) => h);
        }
        dumpLru() {
          return this[LRU_LIST];
        }
        set(key, value, maxAge) {
          maxAge = maxAge || this[MAX_AGE];
          if (maxAge && typeof maxAge !== "number")
            throw new TypeError("maxAge must be a number");
          const now = maxAge ? Date.now() : 0;
          const len = this[LENGTH_CALCULATOR](value, key);
          if (this[CACHE].has(key)) {
            if (len > this[MAX]) {
              del(this, this[CACHE].get(key));
              return false;
            }
            const node = this[CACHE].get(key);
            const item = node.value;
            if (this[DISPOSE]) {
              if (!this[NO_DISPOSE_ON_SET])
                this[DISPOSE](key, item.value);
            }
            item.now = now;
            item.maxAge = maxAge;
            item.value = value;
            this[LENGTH] += len - item.length;
            item.length = len;
            this.get(key);
            trim(this);
            return true;
          }
          const hit = new Entry(key, value, len, now, maxAge);
          if (hit.length > this[MAX]) {
            if (this[DISPOSE])
              this[DISPOSE](key, value);
            return false;
          }
          this[LENGTH] += hit.length;
          this[LRU_LIST].unshift(hit);
          this[CACHE].set(key, this[LRU_LIST].head);
          trim(this);
          return true;
        }
        has(key) {
          if (!this[CACHE].has(key))
            return false;
          const hit = this[CACHE].get(key).value;
          return !isStale(this, hit);
        }
        get(key) {
          return get(this, key, true);
        }
        peek(key) {
          return get(this, key, false);
        }
        pop() {
          const node = this[LRU_LIST].tail;
          if (!node)
            return null;
          del(this, node);
          return node.value;
        }
        del(key) {
          del(this, this[CACHE].get(key));
        }
        load(arr) {
          this.reset();
          const now = Date.now();
          for (let l = arr.length - 1; l >= 0; l--) {
            const hit = arr[l];
            const expiresAt = hit.e || 0;
            if (expiresAt === 0)
              this.set(hit.k, hit.v);
            else {
              const maxAge = expiresAt - now;
              if (maxAge > 0) {
                this.set(hit.k, hit.v, maxAge);
              }
            }
          }
        }
        prune() {
          this[CACHE].forEach((value, key) => get(this, key, false));
        }
      };
      var get = (self, key, doUse) => {
        const node = self[CACHE].get(key);
        if (node) {
          const hit = node.value;
          if (isStale(self, hit)) {
            del(self, node);
            if (!self[ALLOW_STALE])
              return void 0;
          } else {
            if (doUse) {
              if (self[UPDATE_AGE_ON_GET])
                node.value.now = Date.now();
              self[LRU_LIST].unshiftNode(node);
            }
          }
          return hit.value;
        }
      };
      var isStale = (self, hit) => {
        if (!hit || !hit.maxAge && !self[MAX_AGE])
          return false;
        const diff = Date.now() - hit.now;
        return hit.maxAge ? diff > hit.maxAge : self[MAX_AGE] && diff > self[MAX_AGE];
      };
      var trim = (self) => {
        if (self[LENGTH] > self[MAX]) {
          for (let walker = self[LRU_LIST].tail; self[LENGTH] > self[MAX] && walker !== null; ) {
            const prev = walker.prev;
            del(self, walker);
            walker = prev;
          }
        }
      };
      var del = (self, node) => {
        if (node) {
          const hit = node.value;
          if (self[DISPOSE])
            self[DISPOSE](hit.key, hit.value);
          self[LENGTH] -= hit.length;
          self[CACHE].delete(hit.key);
          self[LRU_LIST].removeNode(node);
        }
      };
      var Entry = class {
        constructor(key, value, length, now, maxAge) {
          this.key = key;
          this.value = value;
          this.length = length;
          this.now = now;
          this.maxAge = maxAge || 0;
        }
      };
      var forEachStep = (self, fn, node, thisp) => {
        let hit = node.value;
        if (isStale(self, hit)) {
          del(self, node);
          if (!self[ALLOW_STALE])
            hit = void 0;
        }
        if (hit)
          fn.call(thisp, hit.value, hit.key, self);
      };
      module.exports = LRUCache;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/classes/range.js
  var require_range = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/classes/range.js"(exports, module) {
      var Range = class _Range {
        constructor(range, options) {
          options = parseOptions(options);
          if (range instanceof _Range) {
            if (range.loose === !!options.loose && range.includePrerelease === !!options.includePrerelease) {
              return range;
            } else {
              return new _Range(range.raw, options);
            }
          }
          if (range instanceof Comparator) {
            this.raw = range.value;
            this.set = [[range]];
            this.format();
            return this;
          }
          this.options = options;
          this.loose = !!options.loose;
          this.includePrerelease = !!options.includePrerelease;
          this.raw = range.trim().split(/\s+/).join(" ");
          this.set = this.raw.split("||").map((r) => this.parseRange(r.trim())).filter((c) => c.length);
          if (!this.set.length) {
            throw new TypeError(`Invalid SemVer Range: ${this.raw}`);
          }
          if (this.set.length > 1) {
            const first = this.set[0];
            this.set = this.set.filter((c) => !isNullSet(c[0]));
            if (this.set.length === 0) {
              this.set = [first];
            } else if (this.set.length > 1) {
              for (const c of this.set) {
                if (c.length === 1 && isAny(c[0])) {
                  this.set = [c];
                  break;
                }
              }
            }
          }
          this.format();
        }
        format() {
          this.range = this.set.map((comps) => comps.join(" ").trim()).join("||").trim();
          return this.range;
        }
        toString() {
          return this.range;
        }
        parseRange(range) {
          const memoOpts = (this.options.includePrerelease && FLAG_INCLUDE_PRERELEASE) | (this.options.loose && FLAG_LOOSE);
          const memoKey = memoOpts + ":" + range;
          const cached = cache.get(memoKey);
          if (cached) {
            return cached;
          }
          const loose = this.options.loose;
          const hr = loose ? re[t.HYPHENRANGELOOSE] : re[t.HYPHENRANGE];
          range = range.replace(hr, hyphenReplace(this.options.includePrerelease));
          debug("hyphen replace", range);
          range = range.replace(re[t.COMPARATORTRIM], comparatorTrimReplace);
          debug("comparator trim", range);
          range = range.replace(re[t.TILDETRIM], tildeTrimReplace);
          debug("tilde trim", range);
          range = range.replace(re[t.CARETTRIM], caretTrimReplace);
          debug("caret trim", range);
          let rangeList = range.split(" ").map((comp) => parseComparator(comp, this.options)).join(" ").split(/\s+/).map((comp) => replaceGTE0(comp, this.options));
          if (loose) {
            rangeList = rangeList.filter((comp) => {
              debug("loose invalid filter", comp, this.options);
              return !!comp.match(re[t.COMPARATORLOOSE]);
            });
          }
          debug("range list", rangeList);
          const rangeMap = /* @__PURE__ */ new Map();
          const comparators = rangeList.map((comp) => new Comparator(comp, this.options));
          for (const comp of comparators) {
            if (isNullSet(comp)) {
              return [comp];
            }
            rangeMap.set(comp.value, comp);
          }
          if (rangeMap.size > 1 && rangeMap.has("")) {
            rangeMap.delete("");
          }
          const result = [...rangeMap.values()];
          cache.set(memoKey, result);
          return result;
        }
        intersects(range, options) {
          if (!(range instanceof _Range)) {
            throw new TypeError("a Range is required");
          }
          return this.set.some((thisComparators) => {
            return isSatisfiable(thisComparators, options) && range.set.some((rangeComparators) => {
              return isSatisfiable(rangeComparators, options) && thisComparators.every((thisComparator) => {
                return rangeComparators.every((rangeComparator) => {
                  return thisComparator.intersects(rangeComparator, options);
                });
              });
            });
          });
        }
        // if ANY of the sets match ALL of its comparators, then pass
        test(version) {
          if (!version) {
            return false;
          }
          if (typeof version === "string") {
            try {
              version = new SemVer(version, this.options);
            } catch (er) {
              return false;
            }
          }
          for (let i = 0; i < this.set.length; i++) {
            if (testSet(this.set[i], version, this.options)) {
              return true;
            }
          }
          return false;
        }
      };
      module.exports = Range;
      var LRU = require_lru_cache();
      var cache = new LRU({ max: 1e3 });
      var parseOptions = require_parse_options();
      var Comparator = require_comparator();
      var debug = require_debug();
      var SemVer = require_semver();
      var {
        safeRe: re,
        t,
        comparatorTrimReplace,
        tildeTrimReplace,
        caretTrimReplace
      } = require_re();
      var { FLAG_INCLUDE_PRERELEASE, FLAG_LOOSE } = require_constants();
      var isNullSet = (c) => c.value === "<0.0.0-0";
      var isAny = (c) => c.value === "";
      var isSatisfiable = (comparators, options) => {
        let result = true;
        const remainingComparators = comparators.slice();
        let testComparator = remainingComparators.pop();
        while (result && remainingComparators.length) {
          result = remainingComparators.every((otherComparator) => {
            return testComparator.intersects(otherComparator, options);
          });
          testComparator = remainingComparators.pop();
        }
        return result;
      };
      var parseComparator = (comp, options) => {
        debug("comp", comp, options);
        comp = replaceCarets(comp, options);
        debug("caret", comp);
        comp = replaceTildes(comp, options);
        debug("tildes", comp);
        comp = replaceXRanges(comp, options);
        debug("xrange", comp);
        comp = replaceStars(comp, options);
        debug("stars", comp);
        return comp;
      };
      var isX = (id) => !id || id.toLowerCase() === "x" || id === "*";
      var replaceTildes = (comp, options) => {
        return comp.trim().split(/\s+/).map((c) => replaceTilde(c, options)).join(" ");
      };
      var replaceTilde = (comp, options) => {
        const r = options.loose ? re[t.TILDELOOSE] : re[t.TILDE];
        return comp.replace(r, (_, M, m, p, pr) => {
          debug("tilde", comp, _, M, m, p, pr);
          let ret;
          if (isX(M)) {
            ret = "";
          } else if (isX(m)) {
            ret = `>=${M}.0.0 <${+M + 1}.0.0-0`;
          } else if (isX(p)) {
            ret = `>=${M}.${m}.0 <${M}.${+m + 1}.0-0`;
          } else if (pr) {
            debug("replaceTilde pr", pr);
            ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
          } else {
            ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
          }
          debug("tilde return", ret);
          return ret;
        });
      };
      var replaceCarets = (comp, options) => {
        return comp.trim().split(/\s+/).map((c) => replaceCaret(c, options)).join(" ");
      };
      var replaceCaret = (comp, options) => {
        debug("caret", comp, options);
        const r = options.loose ? re[t.CARETLOOSE] : re[t.CARET];
        const z = options.includePrerelease ? "-0" : "";
        return comp.replace(r, (_, M, m, p, pr) => {
          debug("caret", comp, _, M, m, p, pr);
          let ret;
          if (isX(M)) {
            ret = "";
          } else if (isX(m)) {
            ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
          } else if (isX(p)) {
            if (M === "0") {
              ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
            } else {
              ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`;
            }
          } else if (pr) {
            debug("replaceCaret pr", pr);
            if (M === "0") {
              if (m === "0") {
                ret = `>=${M}.${m}.${p}-${pr} <${M}.${m}.${+p + 1}-0`;
              } else {
                ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
              }
            } else {
              ret = `>=${M}.${m}.${p}-${pr} <${+M + 1}.0.0-0`;
            }
          } else {
            debug("no pr");
            if (M === "0") {
              if (m === "0") {
                ret = `>=${M}.${m}.${p}${z} <${M}.${m}.${+p + 1}-0`;
              } else {
                ret = `>=${M}.${m}.${p}${z} <${M}.${+m + 1}.0-0`;
              }
            } else {
              ret = `>=${M}.${m}.${p} <${+M + 1}.0.0-0`;
            }
          }
          debug("caret return", ret);
          return ret;
        });
      };
      var replaceXRanges = (comp, options) => {
        debug("replaceXRanges", comp, options);
        return comp.split(/\s+/).map((c) => replaceXRange(c, options)).join(" ");
      };
      var replaceXRange = (comp, options) => {
        comp = comp.trim();
        const r = options.loose ? re[t.XRANGELOOSE] : re[t.XRANGE];
        return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
          debug("xRange", comp, ret, gtlt, M, m, p, pr);
          const xM = isX(M);
          const xm = xM || isX(m);
          const xp = xm || isX(p);
          const anyX = xp;
          if (gtlt === "=" && anyX) {
            gtlt = "";
          }
          pr = options.includePrerelease ? "-0" : "";
          if (xM) {
            if (gtlt === ">" || gtlt === "<") {
              ret = "<0.0.0-0";
            } else {
              ret = "*";
            }
          } else if (gtlt && anyX) {
            if (xm) {
              m = 0;
            }
            p = 0;
            if (gtlt === ">") {
              gtlt = ">=";
              if (xm) {
                M = +M + 1;
                m = 0;
                p = 0;
              } else {
                m = +m + 1;
                p = 0;
              }
            } else if (gtlt === "<=") {
              gtlt = "<";
              if (xm) {
                M = +M + 1;
              } else {
                m = +m + 1;
              }
            }
            if (gtlt === "<") {
              pr = "-0";
            }
            ret = `${gtlt + M}.${m}.${p}${pr}`;
          } else if (xm) {
            ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`;
          } else if (xp) {
            ret = `>=${M}.${m}.0${pr} <${M}.${+m + 1}.0-0`;
          }
          debug("xRange return", ret);
          return ret;
        });
      };
      var replaceStars = (comp, options) => {
        debug("replaceStars", comp, options);
        return comp.trim().replace(re[t.STAR], "");
      };
      var replaceGTE0 = (comp, options) => {
        debug("replaceGTE0", comp, options);
        return comp.trim().replace(re[options.includePrerelease ? t.GTE0PRE : t.GTE0], "");
      };
      var hyphenReplace = (incPr) => ($0, from, fM, fm, fp, fpr, fb, to, tM, tm, tp, tpr, tb) => {
        if (isX(fM)) {
          from = "";
        } else if (isX(fm)) {
          from = `>=${fM}.0.0${incPr ? "-0" : ""}`;
        } else if (isX(fp)) {
          from = `>=${fM}.${fm}.0${incPr ? "-0" : ""}`;
        } else if (fpr) {
          from = `>=${from}`;
        } else {
          from = `>=${from}${incPr ? "-0" : ""}`;
        }
        if (isX(tM)) {
          to = "";
        } else if (isX(tm)) {
          to = `<${+tM + 1}.0.0-0`;
        } else if (isX(tp)) {
          to = `<${tM}.${+tm + 1}.0-0`;
        } else if (tpr) {
          to = `<=${tM}.${tm}.${tp}-${tpr}`;
        } else if (incPr) {
          to = `<${tM}.${tm}.${+tp + 1}-0`;
        } else {
          to = `<=${to}`;
        }
        return `${from} ${to}`.trim();
      };
      var testSet = (set, version, options) => {
        for (let i = 0; i < set.length; i++) {
          if (!set[i].test(version)) {
            return false;
          }
        }
        if (version.prerelease.length && !options.includePrerelease) {
          for (let i = 0; i < set.length; i++) {
            debug(set[i].semver);
            if (set[i].semver === Comparator.ANY) {
              continue;
            }
            if (set[i].semver.prerelease.length > 0) {
              const allowed = set[i].semver;
              if (allowed.major === version.major && allowed.minor === version.minor && allowed.patch === version.patch) {
                return true;
              }
            }
          }
          return false;
        }
        return true;
      };
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/classes/comparator.js
  var require_comparator = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/classes/comparator.js"(exports, module) {
      var ANY = Symbol("SemVer ANY");
      var Comparator = class _Comparator {
        static get ANY() {
          return ANY;
        }
        constructor(comp, options) {
          options = parseOptions(options);
          if (comp instanceof _Comparator) {
            if (comp.loose === !!options.loose) {
              return comp;
            } else {
              comp = comp.value;
            }
          }
          comp = comp.trim().split(/\s+/).join(" ");
          debug("comparator", comp, options);
          this.options = options;
          this.loose = !!options.loose;
          this.parse(comp);
          if (this.semver === ANY) {
            this.value = "";
          } else {
            this.value = this.operator + this.semver.version;
          }
          debug("comp", this);
        }
        parse(comp) {
          const r = this.options.loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR];
          const m = comp.match(r);
          if (!m) {
            throw new TypeError(`Invalid comparator: ${comp}`);
          }
          this.operator = m[1] !== void 0 ? m[1] : "";
          if (this.operator === "=") {
            this.operator = "";
          }
          if (!m[2]) {
            this.semver = ANY;
          } else {
            this.semver = new SemVer(m[2], this.options.loose);
          }
        }
        toString() {
          return this.value;
        }
        test(version) {
          debug("Comparator.test", version, this.options.loose);
          if (this.semver === ANY || version === ANY) {
            return true;
          }
          if (typeof version === "string") {
            try {
              version = new SemVer(version, this.options);
            } catch (er) {
              return false;
            }
          }
          return cmp(version, this.operator, this.semver, this.options);
        }
        intersects(comp, options) {
          if (!(comp instanceof _Comparator)) {
            throw new TypeError("a Comparator is required");
          }
          if (this.operator === "") {
            if (this.value === "") {
              return true;
            }
            return new Range(comp.value, options).test(this.value);
          } else if (comp.operator === "") {
            if (comp.value === "") {
              return true;
            }
            return new Range(this.value, options).test(comp.semver);
          }
          options = parseOptions(options);
          if (options.includePrerelease && (this.value === "<0.0.0-0" || comp.value === "<0.0.0-0")) {
            return false;
          }
          if (!options.includePrerelease && (this.value.startsWith("<0.0.0") || comp.value.startsWith("<0.0.0"))) {
            return false;
          }
          if (this.operator.startsWith(">") && comp.operator.startsWith(">")) {
            return true;
          }
          if (this.operator.startsWith("<") && comp.operator.startsWith("<")) {
            return true;
          }
          if (this.semver.version === comp.semver.version && this.operator.includes("=") && comp.operator.includes("=")) {
            return true;
          }
          if (cmp(this.semver, "<", comp.semver, options) && this.operator.startsWith(">") && comp.operator.startsWith("<")) {
            return true;
          }
          if (cmp(this.semver, ">", comp.semver, options) && this.operator.startsWith("<") && comp.operator.startsWith(">")) {
            return true;
          }
          return false;
        }
      };
      module.exports = Comparator;
      var parseOptions = require_parse_options();
      var { safeRe: re, t } = require_re();
      var cmp = require_cmp();
      var debug = require_debug();
      var SemVer = require_semver();
      var Range = require_range();
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/satisfies.js
  var require_satisfies = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/functions/satisfies.js"(exports, module) {
      var Range = require_range();
      var satisfies3 = (version, range, options) => {
        try {
          range = new Range(range, options);
        } catch (er) {
          return false;
        }
        return range.test(version);
      };
      module.exports = satisfies3;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/to-comparators.js
  var require_to_comparators = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/to-comparators.js"(exports, module) {
      var Range = require_range();
      var toComparators = (range, options) => new Range(range, options).set.map((comp) => comp.map((c) => c.value).join(" ").trim().split(" "));
      module.exports = toComparators;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/max-satisfying.js
  var require_max_satisfying = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/max-satisfying.js"(exports, module) {
      var SemVer = require_semver();
      var Range = require_range();
      var maxSatisfying = (versions, range, options) => {
        let max = null;
        let maxSV = null;
        let rangeObj = null;
        try {
          rangeObj = new Range(range, options);
        } catch (er) {
          return null;
        }
        versions.forEach((v) => {
          if (rangeObj.test(v)) {
            if (!max || maxSV.compare(v) === -1) {
              max = v;
              maxSV = new SemVer(max, options);
            }
          }
        });
        return max;
      };
      module.exports = maxSatisfying;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/min-satisfying.js
  var require_min_satisfying = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/min-satisfying.js"(exports, module) {
      var SemVer = require_semver();
      var Range = require_range();
      var minSatisfying = (versions, range, options) => {
        let min = null;
        let minSV = null;
        let rangeObj = null;
        try {
          rangeObj = new Range(range, options);
        } catch (er) {
          return null;
        }
        versions.forEach((v) => {
          if (rangeObj.test(v)) {
            if (!min || minSV.compare(v) === 1) {
              min = v;
              minSV = new SemVer(min, options);
            }
          }
        });
        return min;
      };
      module.exports = minSatisfying;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/min-version.js
  var require_min_version = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/min-version.js"(exports, module) {
      var SemVer = require_semver();
      var Range = require_range();
      var gt = require_gt();
      var minVersion = (range, loose) => {
        range = new Range(range, loose);
        let minver = new SemVer("0.0.0");
        if (range.test(minver)) {
          return minver;
        }
        minver = new SemVer("0.0.0-0");
        if (range.test(minver)) {
          return minver;
        }
        minver = null;
        for (let i = 0; i < range.set.length; ++i) {
          const comparators = range.set[i];
          let setMin = null;
          comparators.forEach((comparator) => {
            const compver = new SemVer(comparator.semver.version);
            switch (comparator.operator) {
              case ">":
                if (compver.prerelease.length === 0) {
                  compver.patch++;
                } else {
                  compver.prerelease.push(0);
                }
                compver.raw = compver.format();
              case "":
              case ">=":
                if (!setMin || gt(compver, setMin)) {
                  setMin = compver;
                }
                break;
              case "<":
              case "<=":
                break;
              default:
                throw new Error(`Unexpected operation: ${comparator.operator}`);
            }
          });
          if (setMin && (!minver || gt(minver, setMin))) {
            minver = setMin;
          }
        }
        if (minver && range.test(minver)) {
          return minver;
        }
        return null;
      };
      module.exports = minVersion;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/valid.js
  var require_valid2 = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/valid.js"(exports, module) {
      var Range = require_range();
      var validRange = (range, options) => {
        try {
          return new Range(range, options).range || "*";
        } catch (er) {
          return null;
        }
      };
      module.exports = validRange;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/outside.js
  var require_outside = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/outside.js"(exports, module) {
      var SemVer = require_semver();
      var Comparator = require_comparator();
      var { ANY } = Comparator;
      var Range = require_range();
      var satisfies3 = require_satisfies();
      var gt = require_gt();
      var lt = require_lt();
      var lte = require_lte();
      var gte = require_gte();
      var outside = (version, range, hilo, options) => {
        version = new SemVer(version, options);
        range = new Range(range, options);
        let gtfn, ltefn, ltfn, comp, ecomp;
        switch (hilo) {
          case ">":
            gtfn = gt;
            ltefn = lte;
            ltfn = lt;
            comp = ">";
            ecomp = ">=";
            break;
          case "<":
            gtfn = lt;
            ltefn = gte;
            ltfn = gt;
            comp = "<";
            ecomp = "<=";
            break;
          default:
            throw new TypeError('Must provide a hilo val of "<" or ">"');
        }
        if (satisfies3(version, range, options)) {
          return false;
        }
        for (let i = 0; i < range.set.length; ++i) {
          const comparators = range.set[i];
          let high = null;
          let low = null;
          comparators.forEach((comparator) => {
            if (comparator.semver === ANY) {
              comparator = new Comparator(">=0.0.0");
            }
            high = high || comparator;
            low = low || comparator;
            if (gtfn(comparator.semver, high.semver, options)) {
              high = comparator;
            } else if (ltfn(comparator.semver, low.semver, options)) {
              low = comparator;
            }
          });
          if (high.operator === comp || high.operator === ecomp) {
            return false;
          }
          if ((!low.operator || low.operator === comp) && ltefn(version, low.semver)) {
            return false;
          } else if (low.operator === ecomp && ltfn(version, low.semver)) {
            return false;
          }
        }
        return true;
      };
      module.exports = outside;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/gtr.js
  var require_gtr = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/gtr.js"(exports, module) {
      var outside = require_outside();
      var gtr = (version, range, options) => outside(version, range, ">", options);
      module.exports = gtr;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/ltr.js
  var require_ltr = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/ltr.js"(exports, module) {
      var outside = require_outside();
      var ltr = (version, range, options) => outside(version, range, "<", options);
      module.exports = ltr;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/intersects.js
  var require_intersects = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/intersects.js"(exports, module) {
      var Range = require_range();
      var intersects = (r1, r2, options) => {
        r1 = new Range(r1, options);
        r2 = new Range(r2, options);
        return r1.intersects(r2, options);
      };
      module.exports = intersects;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/simplify.js
  var require_simplify = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/simplify.js"(exports, module) {
      var satisfies3 = require_satisfies();
      var compare2 = require_compare();
      module.exports = (versions, range, options) => {
        const set = [];
        let first = null;
        let prev = null;
        const v = versions.sort((a, b) => compare2(a, b, options));
        for (const version of v) {
          const included = satisfies3(version, range, options);
          if (included) {
            prev = version;
            if (!first) {
              first = version;
            }
          } else {
            if (prev) {
              set.push([first, prev]);
            }
            prev = null;
            first = null;
          }
        }
        if (first) {
          set.push([first, null]);
        }
        const ranges = [];
        for (const [min, max] of set) {
          if (min === max) {
            ranges.push(min);
          } else if (!max && min === v[0]) {
            ranges.push("*");
          } else if (!max) {
            ranges.push(`>=${min}`);
          } else if (min === v[0]) {
            ranges.push(`<=${max}`);
          } else {
            ranges.push(`${min} - ${max}`);
          }
        }
        const simplified = ranges.join(" || ");
        const original = typeof range.raw === "string" ? range.raw : String(range);
        return simplified.length < original.length ? simplified : range;
      };
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/subset.js
  var require_subset = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/ranges/subset.js"(exports, module) {
      var Range = require_range();
      var Comparator = require_comparator();
      var { ANY } = Comparator;
      var satisfies3 = require_satisfies();
      var compare2 = require_compare();
      var subset = (sub, dom, options = {}) => {
        if (sub === dom) {
          return true;
        }
        sub = new Range(sub, options);
        dom = new Range(dom, options);
        let sawNonNull = false;
        OUTER:
          for (const simpleSub of sub.set) {
            for (const simpleDom of dom.set) {
              const isSub = simpleSubset(simpleSub, simpleDom, options);
              sawNonNull = sawNonNull || isSub !== null;
              if (isSub) {
                continue OUTER;
              }
            }
            if (sawNonNull) {
              return false;
            }
          }
        return true;
      };
      var minimumVersionWithPreRelease = [new Comparator(">=0.0.0-0")];
      var minimumVersion = [new Comparator(">=0.0.0")];
      var simpleSubset = (sub, dom, options) => {
        if (sub === dom) {
          return true;
        }
        if (sub.length === 1 && sub[0].semver === ANY) {
          if (dom.length === 1 && dom[0].semver === ANY) {
            return true;
          } else if (options.includePrerelease) {
            sub = minimumVersionWithPreRelease;
          } else {
            sub = minimumVersion;
          }
        }
        if (dom.length === 1 && dom[0].semver === ANY) {
          if (options.includePrerelease) {
            return true;
          } else {
            dom = minimumVersion;
          }
        }
        const eqSet = /* @__PURE__ */ new Set();
        let gt, lt;
        for (const c of sub) {
          if (c.operator === ">" || c.operator === ">=") {
            gt = higherGT(gt, c, options);
          } else if (c.operator === "<" || c.operator === "<=") {
            lt = lowerLT(lt, c, options);
          } else {
            eqSet.add(c.semver);
          }
        }
        if (eqSet.size > 1) {
          return null;
        }
        let gtltComp;
        if (gt && lt) {
          gtltComp = compare2(gt.semver, lt.semver, options);
          if (gtltComp > 0) {
            return null;
          } else if (gtltComp === 0 && (gt.operator !== ">=" || lt.operator !== "<=")) {
            return null;
          }
        }
        for (const eq of eqSet) {
          if (gt && !satisfies3(eq, String(gt), options)) {
            return null;
          }
          if (lt && !satisfies3(eq, String(lt), options)) {
            return null;
          }
          for (const c of dom) {
            if (!satisfies3(eq, String(c), options)) {
              return false;
            }
          }
          return true;
        }
        let higher, lower;
        let hasDomLT, hasDomGT;
        let needDomLTPre = lt && !options.includePrerelease && lt.semver.prerelease.length ? lt.semver : false;
        let needDomGTPre = gt && !options.includePrerelease && gt.semver.prerelease.length ? gt.semver : false;
        if (needDomLTPre && needDomLTPre.prerelease.length === 1 && lt.operator === "<" && needDomLTPre.prerelease[0] === 0) {
          needDomLTPre = false;
        }
        for (const c of dom) {
          hasDomGT = hasDomGT || c.operator === ">" || c.operator === ">=";
          hasDomLT = hasDomLT || c.operator === "<" || c.operator === "<=";
          if (gt) {
            if (needDomGTPre) {
              if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomGTPre.major && c.semver.minor === needDomGTPre.minor && c.semver.patch === needDomGTPre.patch) {
                needDomGTPre = false;
              }
            }
            if (c.operator === ">" || c.operator === ">=") {
              higher = higherGT(gt, c, options);
              if (higher === c && higher !== gt) {
                return false;
              }
            } else if (gt.operator === ">=" && !satisfies3(gt.semver, String(c), options)) {
              return false;
            }
          }
          if (lt) {
            if (needDomLTPre) {
              if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomLTPre.major && c.semver.minor === needDomLTPre.minor && c.semver.patch === needDomLTPre.patch) {
                needDomLTPre = false;
              }
            }
            if (c.operator === "<" || c.operator === "<=") {
              lower = lowerLT(lt, c, options);
              if (lower === c && lower !== lt) {
                return false;
              }
            } else if (lt.operator === "<=" && !satisfies3(lt.semver, String(c), options)) {
              return false;
            }
          }
          if (!c.operator && (lt || gt) && gtltComp !== 0) {
            return false;
          }
        }
        if (gt && hasDomLT && !lt && gtltComp !== 0) {
          return false;
        }
        if (lt && hasDomGT && !gt && gtltComp !== 0) {
          return false;
        }
        if (needDomGTPre || needDomLTPre) {
          return false;
        }
        return true;
      };
      var higherGT = (a, b, options) => {
        if (!a) {
          return b;
        }
        const comp = compare2(a.semver, b.semver, options);
        return comp > 0 ? a : comp < 0 ? b : b.operator === ">" && a.operator === ">=" ? b : a;
      };
      var lowerLT = (a, b, options) => {
        if (!a) {
          return b;
        }
        const comp = compare2(a.semver, b.semver, options);
        return comp < 0 ? a : comp > 0 ? b : b.operator === "<" && a.operator === "<=" ? b : a;
      };
      module.exports = subset;
    }
  });

  // node_modules/.pnpm/semver@7.6.0/node_modules/semver/index.js
  var require_semver2 = __commonJS({
    "node_modules/.pnpm/semver@7.6.0/node_modules/semver/index.js"(exports, module) {
      var internalRe = require_re();
      var constants = require_constants();
      var SemVer = require_semver();
      var identifiers = require_identifiers();
      var parse = require_parse();
      var valid = require_valid();
      var clean = require_clean();
      var inc = require_inc();
      var diff = require_diff();
      var major = require_major();
      var minor = require_minor();
      var patch = require_patch();
      var prerelease = require_prerelease();
      var compare2 = require_compare();
      var rcompare = require_rcompare();
      var compareLoose = require_compare_loose();
      var compareBuild = require_compare_build();
      var sort = require_sort();
      var rsort = require_rsort();
      var gt = require_gt();
      var lt = require_lt();
      var eq = require_eq();
      var neq = require_neq();
      var gte = require_gte();
      var lte = require_lte();
      var cmp = require_cmp();
      var coerce = require_coerce();
      var Comparator = require_comparator();
      var Range = require_range();
      var satisfies3 = require_satisfies();
      var toComparators = require_to_comparators();
      var maxSatisfying = require_max_satisfying();
      var minSatisfying = require_min_satisfying();
      var minVersion = require_min_version();
      var validRange = require_valid2();
      var outside = require_outside();
      var gtr = require_gtr();
      var ltr = require_ltr();
      var intersects = require_intersects();
      var simplifyRange = require_simplify();
      var subset = require_subset();
      module.exports = {
        parse,
        valid,
        clean,
        inc,
        diff,
        major,
        minor,
        patch,
        prerelease,
        compare: compare2,
        rcompare,
        compareLoose,
        compareBuild,
        sort,
        rsort,
        gt,
        lt,
        eq,
        neq,
        gte,
        lte,
        cmp,
        coerce,
        Comparator,
        Range,
        satisfies: satisfies3,
        toComparators,
        maxSatisfying,
        minSatisfying,
        minVersion,
        validRange,
        outside,
        gtr,
        ltr,
        intersects,
        simplifyRange,
        subset,
        SemVer,
        re: internalRe.re,
        src: internalRe.src,
        tokens: internalRe.t,
        SEMVER_SPEC_VERSION: constants.SEMVER_SPEC_VERSION,
        RELEASE_TYPES: constants.RELEASE_TYPES,
        compareIdentifiers: identifiers.compareIdentifiers,
        rcompareIdentifiers: identifiers.rcompareIdentifiers
      };
    }
  });

  // node_modules/.pnpm/node-stream-zip@1.15.0/node_modules/node-stream-zip/node_stream_zip.js
  var require_node_stream_zip = __commonJS({
    "node_modules/.pnpm/node-stream-zip@1.15.0/node_modules/node-stream-zip/node_stream_zip.js"(exports, module) {
      var fs6 = __require("fs");
      var util = __require("util");
      var path7 = __require("path");
      var events = __require("events");
      var zlib3 = __require("zlib");
      var stream = __require("stream");
      var consts = {
        /* The local file header */
        LOCHDR: 30,
        // LOC header size
        LOCSIG: 67324752,
        // "PK\003\004"
        LOCVER: 4,
        // version needed to extract
        LOCFLG: 6,
        // general purpose bit flag
        LOCHOW: 8,
        // compression method
        LOCTIM: 10,
        // modification time (2 bytes time, 2 bytes date)
        LOCCRC: 14,
        // uncompressed file crc-32 value
        LOCSIZ: 18,
        // compressed size
        LOCLEN: 22,
        // uncompressed size
        LOCNAM: 26,
        // filename length
        LOCEXT: 28,
        // extra field length
        /* The Data descriptor */
        EXTSIG: 134695760,
        // "PK\007\008"
        EXTHDR: 16,
        // EXT header size
        EXTCRC: 4,
        // uncompressed file crc-32 value
        EXTSIZ: 8,
        // compressed size
        EXTLEN: 12,
        // uncompressed size
        /* The central directory file header */
        CENHDR: 46,
        // CEN header size
        CENSIG: 33639248,
        // "PK\001\002"
        CENVEM: 4,
        // version made by
        CENVER: 6,
        // version needed to extract
        CENFLG: 8,
        // encrypt, decrypt flags
        CENHOW: 10,
        // compression method
        CENTIM: 12,
        // modification time (2 bytes time, 2 bytes date)
        CENCRC: 16,
        // uncompressed file crc-32 value
        CENSIZ: 20,
        // compressed size
        CENLEN: 24,
        // uncompressed size
        CENNAM: 28,
        // filename length
        CENEXT: 30,
        // extra field length
        CENCOM: 32,
        // file comment length
        CENDSK: 34,
        // volume number start
        CENATT: 36,
        // internal file attributes
        CENATX: 38,
        // external file attributes (host system dependent)
        CENOFF: 42,
        // LOC header offset
        /* The entries in the end of central directory */
        ENDHDR: 22,
        // END header size
        ENDSIG: 101010256,
        // "PK\005\006"
        ENDSIGFIRST: 80,
        ENDSUB: 8,
        // number of entries on this disk
        ENDTOT: 10,
        // total number of entries
        ENDSIZ: 12,
        // central directory size in bytes
        ENDOFF: 16,
        // offset of first CEN header
        ENDCOM: 20,
        // zip file comment length
        MAXFILECOMMENT: 65535,
        /* The entries in the end of ZIP64 central directory locator */
        ENDL64HDR: 20,
        // ZIP64 end of central directory locator header size
        ENDL64SIG: 117853008,
        // ZIP64 end of central directory locator signature
        ENDL64SIGFIRST: 80,
        ENDL64OFS: 8,
        // ZIP64 end of central directory offset
        /* The entries in the end of ZIP64 central directory */
        END64HDR: 56,
        // ZIP64 end of central directory header size
        END64SIG: 101075792,
        // ZIP64 end of central directory signature
        END64SIGFIRST: 80,
        END64SUB: 24,
        // number of entries on this disk
        END64TOT: 32,
        // total number of entries
        END64SIZ: 40,
        END64OFF: 48,
        /* Compression methods */
        STORED: 0,
        // no compression
        SHRUNK: 1,
        // shrunk
        REDUCED1: 2,
        // reduced with compression factor 1
        REDUCED2: 3,
        // reduced with compression factor 2
        REDUCED3: 4,
        // reduced with compression factor 3
        REDUCED4: 5,
        // reduced with compression factor 4
        IMPLODED: 6,
        // imploded
        // 7 reserved
        DEFLATED: 8,
        // deflated
        ENHANCED_DEFLATED: 9,
        // deflate64
        PKWARE: 10,
        // PKWare DCL imploded
        // 11 reserved
        BZIP2: 12,
        //  compressed using BZIP2
        // 13 reserved
        LZMA: 14,
        // LZMA
        // 15-17 reserved
        IBM_TERSE: 18,
        // compressed using IBM TERSE
        IBM_LZ77: 19,
        //IBM LZ77 z
        /* General purpose bit flag */
        FLG_ENC: 0,
        // encrypted file
        FLG_COMP1: 1,
        // compression option
        FLG_COMP2: 2,
        // compression option
        FLG_DESC: 4,
        // data descriptor
        FLG_ENH: 8,
        // enhanced deflation
        FLG_STR: 16,
        // strong encryption
        FLG_LNG: 1024,
        // language encoding
        FLG_MSK: 4096,
        // mask header values
        FLG_ENTRY_ENC: 1,
        /* 4.5 Extensible data fields */
        EF_ID: 0,
        EF_SIZE: 2,
        /* Header IDs */
        ID_ZIP64: 1,
        ID_AVINFO: 7,
        ID_PFS: 8,
        ID_OS2: 9,
        ID_NTFS: 10,
        ID_OPENVMS: 12,
        ID_UNIX: 13,
        ID_FORK: 14,
        ID_PATCH: 15,
        ID_X509_PKCS7: 20,
        ID_X509_CERTID_F: 21,
        ID_X509_CERTID_C: 22,
        ID_STRONGENC: 23,
        ID_RECORD_MGT: 24,
        ID_X509_PKCS7_RL: 25,
        ID_IBM1: 101,
        ID_IBM2: 102,
        ID_POSZIP: 18064,
        EF_ZIP64_OR_32: 4294967295,
        EF_ZIP64_OR_16: 65535
      };
      var StreamZip2 = function(config) {
        let fd, fileSize, chunkSize, op, centralDirectory, closed;
        const ready = false, that = this, entries = config.storeEntries !== false ? {} : null, fileName = config.file, textDecoder = config.nameEncoding ? new TextDecoder(config.nameEncoding) : null;
        open();
        function open() {
          if (config.fd) {
            fd = config.fd;
            readFile();
          } else {
            fs6.open(fileName, "r", (err, f) => {
              if (err) {
                return that.emit("error", err);
              }
              fd = f;
              readFile();
            });
          }
        }
        function readFile() {
          fs6.fstat(fd, (err, stat) => {
            if (err) {
              return that.emit("error", err);
            }
            fileSize = stat.size;
            chunkSize = config.chunkSize || Math.round(fileSize / 1e3);
            chunkSize = Math.max(
              Math.min(chunkSize, Math.min(128 * 1024, fileSize)),
              Math.min(1024, fileSize)
            );
            readCentralDirectory();
          });
        }
        function readUntilFoundCallback(err, bytesRead) {
          if (err || !bytesRead) {
            return that.emit("error", err || new Error("Archive read error"));
          }
          let pos = op.lastPos;
          let bufferPosition = pos - op.win.position;
          const buffer = op.win.buffer;
          const minPos = op.minPos;
          while (--pos >= minPos && --bufferPosition >= 0) {
            if (buffer.length - bufferPosition >= 4 && buffer[bufferPosition] === op.firstByte) {
              if (buffer.readUInt32LE(bufferPosition) === op.sig) {
                op.lastBufferPosition = bufferPosition;
                op.lastBytesRead = bytesRead;
                op.complete();
                return;
              }
            }
          }
          if (pos === minPos) {
            return that.emit("error", new Error("Bad archive"));
          }
          op.lastPos = pos + 1;
          op.chunkSize *= 2;
          if (pos <= minPos) {
            return that.emit("error", new Error("Bad archive"));
          }
          const expandLength = Math.min(op.chunkSize, pos - minPos);
          op.win.expandLeft(expandLength, readUntilFoundCallback);
        }
        function readCentralDirectory() {
          const totalReadLength = Math.min(consts.ENDHDR + consts.MAXFILECOMMENT, fileSize);
          op = {
            win: new FileWindowBuffer(fd),
            totalReadLength,
            minPos: fileSize - totalReadLength,
            lastPos: fileSize,
            chunkSize: Math.min(1024, chunkSize),
            firstByte: consts.ENDSIGFIRST,
            sig: consts.ENDSIG,
            complete: readCentralDirectoryComplete
          };
          op.win.read(fileSize - op.chunkSize, op.chunkSize, readUntilFoundCallback);
        }
        function readCentralDirectoryComplete() {
          const buffer = op.win.buffer;
          const pos = op.lastBufferPosition;
          try {
            centralDirectory = new CentralDirectoryHeader();
            centralDirectory.read(buffer.slice(pos, pos + consts.ENDHDR));
            centralDirectory.headerOffset = op.win.position + pos;
            if (centralDirectory.commentLength) {
              that.comment = buffer.slice(
                pos + consts.ENDHDR,
                pos + consts.ENDHDR + centralDirectory.commentLength
              ).toString();
            } else {
              that.comment = null;
            }
            that.entriesCount = centralDirectory.volumeEntries;
            that.centralDirectory = centralDirectory;
            if (centralDirectory.volumeEntries === consts.EF_ZIP64_OR_16 && centralDirectory.totalEntries === consts.EF_ZIP64_OR_16 || centralDirectory.size === consts.EF_ZIP64_OR_32 || centralDirectory.offset === consts.EF_ZIP64_OR_32) {
              readZip64CentralDirectoryLocator();
            } else {
              op = {};
              readEntries();
            }
          } catch (err) {
            that.emit("error", err);
          }
        }
        function readZip64CentralDirectoryLocator() {
          const length = consts.ENDL64HDR;
          if (op.lastBufferPosition > length) {
            op.lastBufferPosition -= length;
            readZip64CentralDirectoryLocatorComplete();
          } else {
            op = {
              win: op.win,
              totalReadLength: length,
              minPos: op.win.position - length,
              lastPos: op.win.position,
              chunkSize: op.chunkSize,
              firstByte: consts.ENDL64SIGFIRST,
              sig: consts.ENDL64SIG,
              complete: readZip64CentralDirectoryLocatorComplete
            };
            op.win.read(op.lastPos - op.chunkSize, op.chunkSize, readUntilFoundCallback);
          }
        }
        function readZip64CentralDirectoryLocatorComplete() {
          const buffer = op.win.buffer;
          const locHeader = new CentralDirectoryLoc64Header();
          locHeader.read(
            buffer.slice(op.lastBufferPosition, op.lastBufferPosition + consts.ENDL64HDR)
          );
          const readLength = fileSize - locHeader.headerOffset;
          op = {
            win: op.win,
            totalReadLength: readLength,
            minPos: locHeader.headerOffset,
            lastPos: op.lastPos,
            chunkSize: op.chunkSize,
            firstByte: consts.END64SIGFIRST,
            sig: consts.END64SIG,
            complete: readZip64CentralDirectoryComplete
          };
          op.win.read(fileSize - op.chunkSize, op.chunkSize, readUntilFoundCallback);
        }
        function readZip64CentralDirectoryComplete() {
          const buffer = op.win.buffer;
          const zip64cd = new CentralDirectoryZip64Header();
          zip64cd.read(buffer.slice(op.lastBufferPosition, op.lastBufferPosition + consts.END64HDR));
          that.centralDirectory.volumeEntries = zip64cd.volumeEntries;
          that.centralDirectory.totalEntries = zip64cd.totalEntries;
          that.centralDirectory.size = zip64cd.size;
          that.centralDirectory.offset = zip64cd.offset;
          that.entriesCount = zip64cd.volumeEntries;
          op = {};
          readEntries();
        }
        function readEntries() {
          op = {
            win: new FileWindowBuffer(fd),
            pos: centralDirectory.offset,
            chunkSize,
            entriesLeft: centralDirectory.volumeEntries
          };
          op.win.read(op.pos, Math.min(chunkSize, fileSize - op.pos), readEntriesCallback);
        }
        function readEntriesCallback(err, bytesRead) {
          if (err || !bytesRead) {
            return that.emit("error", err || new Error("Entries read error"));
          }
          let bufferPos = op.pos - op.win.position;
          let entry = op.entry;
          const buffer = op.win.buffer;
          const bufferLength = buffer.length;
          try {
            while (op.entriesLeft > 0) {
              if (!entry) {
                entry = new ZipEntry();
                entry.readHeader(buffer, bufferPos);
                entry.headerOffset = op.win.position + bufferPos;
                op.entry = entry;
                op.pos += consts.CENHDR;
                bufferPos += consts.CENHDR;
              }
              const entryHeaderSize = entry.fnameLen + entry.extraLen + entry.comLen;
              const advanceBytes = entryHeaderSize + (op.entriesLeft > 1 ? consts.CENHDR : 0);
              if (bufferLength - bufferPos < advanceBytes) {
                op.win.moveRight(chunkSize, readEntriesCallback, bufferPos);
                op.move = true;
                return;
              }
              entry.read(buffer, bufferPos, textDecoder);
              if (!config.skipEntryNameValidation) {
                entry.validateName();
              }
              if (entries) {
                entries[entry.name] = entry;
              }
              that.emit("entry", entry);
              op.entry = entry = null;
              op.entriesLeft--;
              op.pos += entryHeaderSize;
              bufferPos += entryHeaderSize;
            }
            that.emit("ready");
          } catch (err2) {
            that.emit("error", err2);
          }
        }
        function checkEntriesExist() {
          if (!entries) {
            throw new Error("storeEntries disabled");
          }
        }
        Object.defineProperty(this, "ready", {
          get() {
            return ready;
          }
        });
        this.entry = function(name) {
          checkEntriesExist();
          return entries[name];
        };
        this.entries = function() {
          checkEntriesExist();
          return entries;
        };
        this.stream = function(entry, callback) {
          return this.openEntry(
            entry,
            (err, entry2) => {
              if (err) {
                return callback(err);
              }
              const offset = dataOffset(entry2);
              let entryStream = new EntryDataReaderStream(fd, offset, entry2.compressedSize);
              if (entry2.method === consts.STORED) {
              } else if (entry2.method === consts.DEFLATED) {
                entryStream = entryStream.pipe(zlib3.createInflateRaw());
              } else {
                return callback(new Error("Unknown compression method: " + entry2.method));
              }
              if (canVerifyCrc(entry2)) {
                entryStream = entryStream.pipe(
                  new EntryVerifyStream(entryStream, entry2.crc, entry2.size)
                );
              }
              callback(null, entryStream);
            },
            false
          );
        };
        this.entryDataSync = function(entry) {
          let err = null;
          this.openEntry(
            entry,
            (e, en) => {
              err = e;
              entry = en;
            },
            true
          );
          if (err) {
            throw err;
          }
          let data = Buffer.alloc(entry.compressedSize);
          new FsRead(fd, data, 0, entry.compressedSize, dataOffset(entry), (e) => {
            err = e;
          }).read(true);
          if (err) {
            throw err;
          }
          if (entry.method === consts.STORED) {
          } else if (entry.method === consts.DEFLATED || entry.method === consts.ENHANCED_DEFLATED) {
            data = zlib3.inflateRawSync(data);
          } else {
            throw new Error("Unknown compression method: " + entry.method);
          }
          if (data.length !== entry.size) {
            throw new Error("Invalid size");
          }
          if (canVerifyCrc(entry)) {
            const verify = new CrcVerify(entry.crc, entry.size);
            verify.data(data);
          }
          return data;
        };
        this.openEntry = function(entry, callback, sync) {
          if (typeof entry === "string") {
            checkEntriesExist();
            entry = entries[entry];
            if (!entry) {
              return callback(new Error("Entry not found"));
            }
          }
          if (!entry.isFile) {
            return callback(new Error("Entry is not file"));
          }
          if (!fd) {
            return callback(new Error("Archive closed"));
          }
          const buffer = Buffer.alloc(consts.LOCHDR);
          new FsRead(fd, buffer, 0, buffer.length, entry.offset, (err) => {
            if (err) {
              return callback(err);
            }
            let readEx;
            try {
              entry.readDataHeader(buffer);
              if (entry.encrypted) {
                readEx = new Error("Entry encrypted");
              }
            } catch (ex) {
              readEx = ex;
            }
            callback(readEx, entry);
          }).read(sync);
        };
        function dataOffset(entry) {
          return entry.offset + consts.LOCHDR + entry.fnameLen + entry.extraLen;
        }
        function canVerifyCrc(entry) {
          return (entry.flags & 8) !== 8;
        }
        function extract(entry, outPath, callback) {
          that.stream(entry, (err, stm) => {
            if (err) {
              callback(err);
            } else {
              let fsStm, errThrown;
              stm.on("error", (err2) => {
                errThrown = err2;
                if (fsStm) {
                  stm.unpipe(fsStm);
                  fsStm.close(() => {
                    callback(err2);
                  });
                }
              });
              fs6.open(outPath, "w", (err2, fdFile) => {
                if (err2) {
                  return callback(err2);
                }
                if (errThrown) {
                  fs6.close(fd, () => {
                    callback(errThrown);
                  });
                  return;
                }
                fsStm = fs6.createWriteStream(outPath, { fd: fdFile });
                fsStm.on("finish", () => {
                  that.emit("extract", entry, outPath);
                  if (!errThrown) {
                    callback();
                  }
                });
                stm.pipe(fsStm);
              });
            }
          });
        }
        function createDirectories(baseDir, dirs, callback) {
          if (!dirs.length) {
            return callback();
          }
          let dir = dirs.shift();
          dir = path7.join(baseDir, path7.join(...dir));
          fs6.mkdir(dir, { recursive: true }, (err) => {
            if (err && err.code !== "EEXIST") {
              return callback(err);
            }
            createDirectories(baseDir, dirs, callback);
          });
        }
        function extractFiles(baseDir, baseRelPath, files, callback, extractedCount) {
          if (!files.length) {
            return callback(null, extractedCount);
          }
          const file = files.shift();
          const targetPath = path7.join(baseDir, file.name.replace(baseRelPath, ""));
          extract(file, targetPath, (err) => {
            if (err) {
              return callback(err, extractedCount);
            }
            extractFiles(baseDir, baseRelPath, files, callback, extractedCount + 1);
          });
        }
        this.extract = function(entry, outPath, callback) {
          let entryName = entry || "";
          if (typeof entry === "string") {
            entry = this.entry(entry);
            if (entry) {
              entryName = entry.name;
            } else {
              if (entryName.length && entryName[entryName.length - 1] !== "/") {
                entryName += "/";
              }
            }
          }
          if (!entry || entry.isDirectory) {
            const files = [], dirs = [], allDirs = {};
            for (const e in entries) {
              if (Object.prototype.hasOwnProperty.call(entries, e) && e.lastIndexOf(entryName, 0) === 0) {
                let relPath = e.replace(entryName, "");
                const childEntry = entries[e];
                if (childEntry.isFile) {
                  files.push(childEntry);
                  relPath = path7.dirname(relPath);
                }
                if (relPath && !allDirs[relPath] && relPath !== ".") {
                  allDirs[relPath] = true;
                  let parts = relPath.split("/").filter((f) => {
                    return f;
                  });
                  if (parts.length) {
                    dirs.push(parts);
                  }
                  while (parts.length > 1) {
                    parts = parts.slice(0, parts.length - 1);
                    const partsPath = parts.join("/");
                    if (allDirs[partsPath] || partsPath === ".") {
                      break;
                    }
                    allDirs[partsPath] = true;
                    dirs.push(parts);
                  }
                }
              }
            }
            dirs.sort((x, y) => {
              return x.length - y.length;
            });
            if (dirs.length) {
              createDirectories(outPath, dirs, (err) => {
                if (err) {
                  callback(err);
                } else {
                  extractFiles(outPath, entryName, files, callback, 0);
                }
              });
            } else {
              extractFiles(outPath, entryName, files, callback, 0);
            }
          } else {
            fs6.stat(outPath, (err, stat) => {
              if (stat && stat.isDirectory()) {
                extract(entry, path7.join(outPath, path7.basename(entry.name)), callback);
              } else {
                extract(entry, outPath, callback);
              }
            });
          }
        };
        this.close = function(callback) {
          if (closed || !fd) {
            closed = true;
            if (callback) {
              callback();
            }
          } else {
            closed = true;
            fs6.close(fd, (err) => {
              fd = null;
              if (callback) {
                callback(err);
              }
            });
          }
        };
        const originalEmit = events.EventEmitter.prototype.emit;
        this.emit = function(...args) {
          if (!closed) {
            return originalEmit.call(this, ...args);
          }
        };
      };
      StreamZip2.setFs = function(customFs) {
        fs6 = customFs;
      };
      StreamZip2.debugLog = (...args) => {
        if (StreamZip2.debug) {
          console.log(...args);
        }
      };
      util.inherits(StreamZip2, events.EventEmitter);
      var propZip = Symbol("zip");
      StreamZip2.async = class StreamZipAsync extends events.EventEmitter {
        constructor(config) {
          super();
          const zip = new StreamZip2(config);
          zip.on("entry", (entry) => this.emit("entry", entry));
          zip.on("extract", (entry, outPath) => this.emit("extract", entry, outPath));
          this[propZip] = new Promise((resolve, reject) => {
            zip.on("ready", () => {
              zip.removeListener("error", reject);
              resolve(zip);
            });
            zip.on("error", reject);
          });
        }
        get entriesCount() {
          return this[propZip].then((zip) => zip.entriesCount);
        }
        get comment() {
          return this[propZip].then((zip) => zip.comment);
        }
        async entry(name) {
          const zip = await this[propZip];
          return zip.entry(name);
        }
        async entries() {
          const zip = await this[propZip];
          return zip.entries();
        }
        async stream(entry) {
          const zip = await this[propZip];
          return new Promise((resolve, reject) => {
            zip.stream(entry, (err, stm) => {
              if (err) {
                reject(err);
              } else {
                resolve(stm);
              }
            });
          });
        }
        async entryData(entry) {
          const stm = await this.stream(entry);
          return new Promise((resolve, reject) => {
            const data = [];
            stm.on("data", (chunk) => data.push(chunk));
            stm.on("end", () => {
              resolve(Buffer.concat(data));
            });
            stm.on("error", (err) => {
              stm.removeAllListeners("end");
              reject(err);
            });
          });
        }
        async extract(entry, outPath) {
          const zip = await this[propZip];
          return new Promise((resolve, reject) => {
            zip.extract(entry, outPath, (err, res) => {
              if (err) {
                reject(err);
              } else {
                resolve(res);
              }
            });
          });
        }
        async close() {
          const zip = await this[propZip];
          return new Promise((resolve, reject) => {
            zip.close((err) => {
              if (err) {
                reject(err);
              } else {
                resolve();
              }
            });
          });
        }
      };
      var CentralDirectoryHeader = class {
        read(data) {
          if (data.length !== consts.ENDHDR || data.readUInt32LE(0) !== consts.ENDSIG) {
            throw new Error("Invalid central directory");
          }
          this.volumeEntries = data.readUInt16LE(consts.ENDSUB);
          this.totalEntries = data.readUInt16LE(consts.ENDTOT);
          this.size = data.readUInt32LE(consts.ENDSIZ);
          this.offset = data.readUInt32LE(consts.ENDOFF);
          this.commentLength = data.readUInt16LE(consts.ENDCOM);
        }
      };
      var CentralDirectoryLoc64Header = class {
        read(data) {
          if (data.length !== consts.ENDL64HDR || data.readUInt32LE(0) !== consts.ENDL64SIG) {
            throw new Error("Invalid zip64 central directory locator");
          }
          this.headerOffset = readUInt64LE(data, consts.ENDSUB);
        }
      };
      var CentralDirectoryZip64Header = class {
        read(data) {
          if (data.length !== consts.END64HDR || data.readUInt32LE(0) !== consts.END64SIG) {
            throw new Error("Invalid central directory");
          }
          this.volumeEntries = readUInt64LE(data, consts.END64SUB);
          this.totalEntries = readUInt64LE(data, consts.END64TOT);
          this.size = readUInt64LE(data, consts.END64SIZ);
          this.offset = readUInt64LE(data, consts.END64OFF);
        }
      };
      var ZipEntry = class {
        readHeader(data, offset) {
          if (data.length < offset + consts.CENHDR || data.readUInt32LE(offset) !== consts.CENSIG) {
            throw new Error("Invalid entry header");
          }
          this.verMade = data.readUInt16LE(offset + consts.CENVEM);
          this.version = data.readUInt16LE(offset + consts.CENVER);
          this.flags = data.readUInt16LE(offset + consts.CENFLG);
          this.method = data.readUInt16LE(offset + consts.CENHOW);
          const timebytes = data.readUInt16LE(offset + consts.CENTIM);
          const datebytes = data.readUInt16LE(offset + consts.CENTIM + 2);
          this.time = parseZipTime(timebytes, datebytes);
          this.crc = data.readUInt32LE(offset + consts.CENCRC);
          this.compressedSize = data.readUInt32LE(offset + consts.CENSIZ);
          this.size = data.readUInt32LE(offset + consts.CENLEN);
          this.fnameLen = data.readUInt16LE(offset + consts.CENNAM);
          this.extraLen = data.readUInt16LE(offset + consts.CENEXT);
          this.comLen = data.readUInt16LE(offset + consts.CENCOM);
          this.diskStart = data.readUInt16LE(offset + consts.CENDSK);
          this.inattr = data.readUInt16LE(offset + consts.CENATT);
          this.attr = data.readUInt32LE(offset + consts.CENATX);
          this.offset = data.readUInt32LE(offset + consts.CENOFF);
        }
        readDataHeader(data) {
          if (data.readUInt32LE(0) !== consts.LOCSIG) {
            throw new Error("Invalid local header");
          }
          this.version = data.readUInt16LE(consts.LOCVER);
          this.flags = data.readUInt16LE(consts.LOCFLG);
          this.method = data.readUInt16LE(consts.LOCHOW);
          const timebytes = data.readUInt16LE(consts.LOCTIM);
          const datebytes = data.readUInt16LE(consts.LOCTIM + 2);
          this.time = parseZipTime(timebytes, datebytes);
          this.crc = data.readUInt32LE(consts.LOCCRC) || this.crc;
          const compressedSize = data.readUInt32LE(consts.LOCSIZ);
          if (compressedSize && compressedSize !== consts.EF_ZIP64_OR_32) {
            this.compressedSize = compressedSize;
          }
          const size = data.readUInt32LE(consts.LOCLEN);
          if (size && size !== consts.EF_ZIP64_OR_32) {
            this.size = size;
          }
          this.fnameLen = data.readUInt16LE(consts.LOCNAM);
          this.extraLen = data.readUInt16LE(consts.LOCEXT);
        }
        read(data, offset, textDecoder) {
          const nameData = data.slice(offset, offset += this.fnameLen);
          this.name = textDecoder ? textDecoder.decode(new Uint8Array(nameData)) : nameData.toString("utf8");
          const lastChar = data[offset - 1];
          this.isDirectory = lastChar === 47 || lastChar === 92;
          if (this.extraLen) {
            this.readExtra(data, offset);
            offset += this.extraLen;
          }
          this.comment = this.comLen ? data.slice(offset, offset + this.comLen).toString() : null;
        }
        validateName() {
          if (/\\|^\w+:|^\/|(^|\/)\.\.(\/|$)/.test(this.name)) {
            throw new Error("Malicious entry: " + this.name);
          }
        }
        readExtra(data, offset) {
          let signature, size;
          const maxPos = offset + this.extraLen;
          while (offset < maxPos) {
            signature = data.readUInt16LE(offset);
            offset += 2;
            size = data.readUInt16LE(offset);
            offset += 2;
            if (consts.ID_ZIP64 === signature) {
              this.parseZip64Extra(data, offset, size);
            }
            offset += size;
          }
        }
        parseZip64Extra(data, offset, length) {
          if (length >= 8 && this.size === consts.EF_ZIP64_OR_32) {
            this.size = readUInt64LE(data, offset);
            offset += 8;
            length -= 8;
          }
          if (length >= 8 && this.compressedSize === consts.EF_ZIP64_OR_32) {
            this.compressedSize = readUInt64LE(data, offset);
            offset += 8;
            length -= 8;
          }
          if (length >= 8 && this.offset === consts.EF_ZIP64_OR_32) {
            this.offset = readUInt64LE(data, offset);
            offset += 8;
            length -= 8;
          }
          if (length >= 4 && this.diskStart === consts.EF_ZIP64_OR_16) {
            this.diskStart = data.readUInt32LE(offset);
          }
        }
        get encrypted() {
          return (this.flags & consts.FLG_ENTRY_ENC) === consts.FLG_ENTRY_ENC;
        }
        get isFile() {
          return !this.isDirectory;
        }
      };
      var FsRead = class {
        constructor(fd, buffer, offset, length, position, callback) {
          this.fd = fd;
          this.buffer = buffer;
          this.offset = offset;
          this.length = length;
          this.position = position;
          this.callback = callback;
          this.bytesRead = 0;
          this.waiting = false;
        }
        read(sync) {
          StreamZip2.debugLog("read", this.position, this.bytesRead, this.length, this.offset);
          this.waiting = true;
          let err;
          if (sync) {
            let bytesRead = 0;
            try {
              bytesRead = fs6.readSync(
                this.fd,
                this.buffer,
                this.offset + this.bytesRead,
                this.length - this.bytesRead,
                this.position + this.bytesRead
              );
            } catch (e) {
              err = e;
            }
            this.readCallback(sync, err, err ? bytesRead : null);
          } else {
            fs6.read(
              this.fd,
              this.buffer,
              this.offset + this.bytesRead,
              this.length - this.bytesRead,
              this.position + this.bytesRead,
              this.readCallback.bind(this, sync)
            );
          }
        }
        readCallback(sync, err, bytesRead) {
          if (typeof bytesRead === "number") {
            this.bytesRead += bytesRead;
          }
          if (err || !bytesRead || this.bytesRead === this.length) {
            this.waiting = false;
            return this.callback(err, this.bytesRead);
          } else {
            this.read(sync);
          }
        }
      };
      var FileWindowBuffer = class {
        constructor(fd) {
          this.position = 0;
          this.buffer = Buffer.alloc(0);
          this.fd = fd;
          this.fsOp = null;
        }
        checkOp() {
          if (this.fsOp && this.fsOp.waiting) {
            throw new Error("Operation in progress");
          }
        }
        read(pos, length, callback) {
          this.checkOp();
          if (this.buffer.length < length) {
            this.buffer = Buffer.alloc(length);
          }
          this.position = pos;
          this.fsOp = new FsRead(this.fd, this.buffer, 0, length, this.position, callback).read();
        }
        expandLeft(length, callback) {
          this.checkOp();
          this.buffer = Buffer.concat([Buffer.alloc(length), this.buffer]);
          this.position -= length;
          if (this.position < 0) {
            this.position = 0;
          }
          this.fsOp = new FsRead(this.fd, this.buffer, 0, length, this.position, callback).read();
        }
        expandRight(length, callback) {
          this.checkOp();
          const offset = this.buffer.length;
          this.buffer = Buffer.concat([this.buffer, Buffer.alloc(length)]);
          this.fsOp = new FsRead(
            this.fd,
            this.buffer,
            offset,
            length,
            this.position + offset,
            callback
          ).read();
        }
        moveRight(length, callback, shift) {
          this.checkOp();
          if (shift) {
            this.buffer.copy(this.buffer, 0, shift);
          } else {
            shift = 0;
          }
          this.position += shift;
          this.fsOp = new FsRead(
            this.fd,
            this.buffer,
            this.buffer.length - shift,
            shift,
            this.position + this.buffer.length - shift,
            callback
          ).read();
        }
      };
      var EntryDataReaderStream = class extends stream.Readable {
        constructor(fd, offset, length) {
          super();
          this.fd = fd;
          this.offset = offset;
          this.length = length;
          this.pos = 0;
          this.readCallback = this.readCallback.bind(this);
        }
        _read(n) {
          const buffer = Buffer.alloc(Math.min(n, this.length - this.pos));
          if (buffer.length) {
            fs6.read(this.fd, buffer, 0, buffer.length, this.offset + this.pos, this.readCallback);
          } else {
            this.push(null);
          }
        }
        readCallback(err, bytesRead, buffer) {
          this.pos += bytesRead;
          if (err) {
            this.emit("error", err);
            this.push(null);
          } else if (!bytesRead) {
            this.push(null);
          } else {
            if (bytesRead !== buffer.length) {
              buffer = buffer.slice(0, bytesRead);
            }
            this.push(buffer);
          }
        }
      };
      var EntryVerifyStream = class extends stream.Transform {
        constructor(baseStm, crc, size) {
          super();
          this.verify = new CrcVerify(crc, size);
          baseStm.on("error", (e) => {
            this.emit("error", e);
          });
        }
        _transform(data, encoding, callback) {
          let err;
          try {
            this.verify.data(data);
          } catch (e) {
            err = e;
          }
          callback(err, data);
        }
      };
      var CrcVerify = class _CrcVerify {
        constructor(crc, size) {
          this.crc = crc;
          this.size = size;
          this.state = {
            crc: ~0,
            size: 0
          };
        }
        data(data) {
          const crcTable = _CrcVerify.getCrcTable();
          let crc = this.state.crc;
          let off = 0;
          let len = data.length;
          while (--len >= 0) {
            crc = crcTable[(crc ^ data[off++]) & 255] ^ crc >>> 8;
          }
          this.state.crc = crc;
          this.state.size += data.length;
          if (this.state.size >= this.size) {
            const buf = Buffer.alloc(4);
            buf.writeInt32LE(~this.state.crc & 4294967295, 0);
            crc = buf.readUInt32LE(0);
            if (crc !== this.crc) {
              throw new Error("Invalid CRC");
            }
            if (this.state.size !== this.size) {
              throw new Error("Invalid size");
            }
          }
        }
        static getCrcTable() {
          let crcTable = _CrcVerify.crcTable;
          if (!crcTable) {
            _CrcVerify.crcTable = crcTable = [];
            const b = Buffer.alloc(4);
            for (let n = 0; n < 256; n++) {
              let c = n;
              for (let k = 8; --k >= 0; ) {
                if ((c & 1) !== 0) {
                  c = 3988292384 ^ c >>> 1;
                } else {
                  c = c >>> 1;
                }
              }
              if (c < 0) {
                b.writeInt32LE(c, 0);
                c = b.readUInt32LE(0);
              }
              crcTable[n] = c;
            }
          }
          return crcTable;
        }
      };
      function parseZipTime(timebytes, datebytes) {
        const timebits = toBits(timebytes, 16);
        const datebits = toBits(datebytes, 16);
        const mt = {
          h: parseInt(timebits.slice(0, 5).join(""), 2),
          m: parseInt(timebits.slice(5, 11).join(""), 2),
          s: parseInt(timebits.slice(11, 16).join(""), 2) * 2,
          Y: parseInt(datebits.slice(0, 7).join(""), 2) + 1980,
          M: parseInt(datebits.slice(7, 11).join(""), 2),
          D: parseInt(datebits.slice(11, 16).join(""), 2)
        };
        const dt_str = [mt.Y, mt.M, mt.D].join("-") + " " + [mt.h, mt.m, mt.s].join(":") + " GMT+0";
        return new Date(dt_str).getTime();
      }
      function toBits(dec, size) {
        let b = (dec >>> 0).toString(2);
        while (b.length < size) {
          b = "0" + b;
        }
        return b.split("");
      }
      function readUInt64LE(buffer, offset) {
        return buffer.readUInt32LE(offset + 4) * 4294967296 + buffer.readUInt32LE(offset);
      }
      module.exports = StreamZip2;
    }
  });

  // src/tomb/index.ts
  var import_fs5 = __require("fs");
  var import_path6 = __require("path");

  // src/tomb/classes/tomb.ts
  var import_fs4 = __toESM(__require("fs"), 1);
  var import_path5 = __toESM(__require("path"), 1);

  // node_modules/.pnpm/spitroast@1.4.3/node_modules/spitroast/dist/esm/index.js
  var esm_exports = {};
  __export(esm_exports, {
    after: () => after,
    before: () => before,
    instead: () => instead,
    unpatchAll: () => unpatchAll
  });

  // node_modules/.pnpm/spitroast@1.4.3/node_modules/spitroast/dist/esm/shared.js
  var patchTypes = ["a", "b", "i"];
  var patchedObjects = /* @__PURE__ */ new Map();

  // node_modules/.pnpm/spitroast@1.4.3/node_modules/spitroast/dist/esm/hook.js
  function hook_default(funcName, funcParent, funcArgs, ctxt, isConstruct) {
    var _a, _b;
    const patch = (_a = patchedObjects.get(funcParent)) == null ? void 0 : _a[funcName];
    if (!patch)
      return isConstruct ? Reflect.construct(funcParent[funcName], funcArgs, ctxt) : funcParent[funcName].apply(ctxt, funcArgs);
    for (const hook of patch.b.values()) {
      const maybefuncArgs = hook.call(ctxt, funcArgs);
      if (Array.isArray(maybefuncArgs))
        funcArgs = maybefuncArgs;
    }
    let workingRetVal = [...patch.i.values()].reduce(
      (prev, current) => (...args) => current.call(ctxt, args, prev),
      // This calls the original function
      (...args) => isConstruct ? Reflect.construct(patch.o, args, ctxt) : patch.o.apply(ctxt, args)
    )(...funcArgs);
    for (const hook of patch.a.values())
      workingRetVal = (_b = hook.call(ctxt, funcArgs, workingRetVal)) != null ? _b : workingRetVal;
    return workingRetVal;
  }

  // node_modules/.pnpm/spitroast@1.4.3/node_modules/spitroast/dist/esm/unpatch.js
  function unpatch(funcParent, funcName, hookId, type) {
    const patchedObject = patchedObjects.get(funcParent);
    const patch = patchedObject == null ? void 0 : patchedObject[funcName];
    if (!(patch == null ? void 0 : patch[type].has(hookId)))
      return false;
    patch[type].delete(hookId);
    if (patchTypes.every((t) => patch[t].size === 0)) {
      const success = Reflect.defineProperty(funcParent, funcName, {
        value: patch.o,
        writable: true,
        configurable: true
      });
      if (!success)
        funcParent[funcName] = patch.o;
      delete patchedObject[funcName];
    }
    if (Object.keys(patchedObject).length == 0)
      patchedObjects.delete(funcParent);
    return true;
  }
  function unpatchAll() {
    var _a, _b;
    for (const [parentObject, patchedObject] of patchedObjects.entries())
      for (const funcName in patchedObject)
        for (const hookType of patchTypes)
          for (const hookId of (_b = (_a = patchedObject[funcName]) == null ? void 0 : _a[hookType].keys()) != null ? _b : [])
            unpatch(parentObject, funcName, hookId, hookType);
  }

  // node_modules/.pnpm/spitroast@1.4.3/node_modules/spitroast/dist/esm/getPatchFunc.js
  var getPatchFunc_default = (patchType) => (funcName, funcParent, callback, oneTime = false) => {
    if (typeof funcParent[funcName] !== "function")
      throw new Error(`${funcName} is not a function in ${funcParent.constructor.name}`);
    if (!patchedObjects.has(funcParent))
      patchedObjects.set(funcParent, {});
    const parentInjections = patchedObjects.get(funcParent);
    if (!parentInjections[funcName]) {
      const origFunc = funcParent[funcName];
      parentInjections[funcName] = {
        o: origFunc,
        b: /* @__PURE__ */ new Map(),
        i: /* @__PURE__ */ new Map(),
        a: /* @__PURE__ */ new Map()
      };
      const runHook = (ctxt, args, construct) => {
        const ret = hook_default(funcName, funcParent, args, ctxt, construct);
        if (oneTime)
          unpatchThisPatch();
        return ret;
      };
      const replaceProxy = new Proxy(origFunc, {
        apply: (_, ctxt, args) => runHook(ctxt, args, false),
        construct: (_, args) => runHook(origFunc, args, true),
        get: (target, prop, receiver) => prop == "toString" ? origFunc.toString.bind(origFunc) : Reflect.get(target, prop, receiver)
      });
      const success = Reflect.defineProperty(funcParent, funcName, {
        value: replaceProxy,
        configurable: true,
        writable: true
      });
      if (!success)
        funcParent[funcName] = replaceProxy;
    }
    const hookId = Symbol();
    const unpatchThisPatch = () => unpatch(funcParent, funcName, hookId, patchType);
    parentInjections[funcName][patchType].set(hookId, callback);
    return unpatchThisPatch;
  };

  // node_modules/.pnpm/spitroast@1.4.3/node_modules/spitroast/dist/esm/index.js
  var before = getPatchFunc_default("b");
  var instead = getPatchFunc_default("i");
  var after = getPatchFunc_default("a");

  // src/tomb/classes/tomb.ts
  var import_semver2 = __toESM(require_semver2(), 1);

  // src/tomb/classes/cache.ts
  var import_fs = __toESM(__require("fs"), 1);
  var import_path = __toESM(__require("path"), 1);
  var import_zlib2 = __toESM(__require("zlib"), 1);

  // node_modules/.pnpm/fast-json-patch@3.1.1/node_modules/fast-json-patch/module/core.mjs
  var core_exports = {};
  __export(core_exports, {
    JsonPatchError: () => JsonPatchError,
    _areEquals: () => _areEquals,
    applyOperation: () => applyOperation,
    applyPatch: () => applyPatch,
    applyReducer: () => applyReducer,
    deepClone: () => deepClone,
    getValueByPointer: () => getValueByPointer,
    validate: () => validate,
    validator: () => validator
  });

  // node_modules/.pnpm/fast-json-patch@3.1.1/node_modules/fast-json-patch/module/helpers.mjs
  var __extends = /* @__PURE__ */ function() {
    var extendStatics = function(d, b) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
        d2.__proto__ = b2;
      } || function(d2, b2) {
        for (var p in b2)
          if (b2.hasOwnProperty(p))
            d2[p] = b2[p];
      };
      return extendStatics(d, b);
    };
    return function(d, b) {
      extendStatics(d, b);
      function __() {
        this.constructor = d;
      }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
  }();
  var _hasOwnProperty = Object.prototype.hasOwnProperty;
  function hasOwnProperty(obj, key) {
    return _hasOwnProperty.call(obj, key);
  }
  function _objectKeys(obj) {
    if (Array.isArray(obj)) {
      var keys_1 = new Array(obj.length);
      for (var k = 0; k < keys_1.length; k++) {
        keys_1[k] = "" + k;
      }
      return keys_1;
    }
    if (Object.keys) {
      return Object.keys(obj);
    }
    var keys = [];
    for (var i in obj) {
      if (hasOwnProperty(obj, i)) {
        keys.push(i);
      }
    }
    return keys;
  }
  function _deepClone(obj) {
    switch (typeof obj) {
      case "object":
        return JSON.parse(JSON.stringify(obj));
      case "undefined":
        return null;
      default:
        return obj;
    }
  }
  function isInteger(str) {
    var i = 0;
    var len = str.length;
    var charCode;
    while (i < len) {
      charCode = str.charCodeAt(i);
      if (charCode >= 48 && charCode <= 57) {
        i++;
        continue;
      }
      return false;
    }
    return true;
  }
  function escapePathComponent(path7) {
    if (path7.indexOf("/") === -1 && path7.indexOf("~") === -1)
      return path7;
    return path7.replace(/~/g, "~0").replace(/\//g, "~1");
  }
  function unescapePathComponent(path7) {
    return path7.replace(/~1/g, "/").replace(/~0/g, "~");
  }
  function hasUndefined(obj) {
    if (obj === void 0) {
      return true;
    }
    if (obj) {
      if (Array.isArray(obj)) {
        for (var i_1 = 0, len = obj.length; i_1 < len; i_1++) {
          if (hasUndefined(obj[i_1])) {
            return true;
          }
        }
      } else if (typeof obj === "object") {
        var objKeys = _objectKeys(obj);
        var objKeysLength = objKeys.length;
        for (var i = 0; i < objKeysLength; i++) {
          if (hasUndefined(obj[objKeys[i]])) {
            return true;
          }
        }
      }
    }
    return false;
  }
  function patchErrorMessageFormatter(message, args) {
    var messageParts = [message];
    for (var key in args) {
      var value = typeof args[key] === "object" ? JSON.stringify(args[key], null, 2) : args[key];
      if (typeof value !== "undefined") {
        messageParts.push(key + ": " + value);
      }
    }
    return messageParts.join("\n");
  }
  var PatchError = (
    /** @class */
    function(_super) {
      __extends(PatchError2, _super);
      function PatchError2(message, name, index, operation, tree) {
        var _newTarget = this.constructor;
        var _this = _super.call(this, patchErrorMessageFormatter(message, { name, index, operation, tree })) || this;
        _this.name = name;
        _this.index = index;
        _this.operation = operation;
        _this.tree = tree;
        Object.setPrototypeOf(_this, _newTarget.prototype);
        _this.message = patchErrorMessageFormatter(message, { name, index, operation, tree });
        return _this;
      }
      return PatchError2;
    }(Error)
  );

  // node_modules/.pnpm/fast-json-patch@3.1.1/node_modules/fast-json-patch/module/core.mjs
  var JsonPatchError = PatchError;
  var deepClone = _deepClone;
  var objOps = {
    add: function(obj, key, document2) {
      obj[key] = this.value;
      return { newDocument: document2 };
    },
    remove: function(obj, key, document2) {
      var removed = obj[key];
      delete obj[key];
      return { newDocument: document2, removed };
    },
    replace: function(obj, key, document2) {
      var removed = obj[key];
      obj[key] = this.value;
      return { newDocument: document2, removed };
    },
    move: function(obj, key, document2) {
      var removed = getValueByPointer(document2, this.path);
      if (removed) {
        removed = _deepClone(removed);
      }
      var originalValue = applyOperation(document2, { op: "remove", path: this.from }).removed;
      applyOperation(document2, { op: "add", path: this.path, value: originalValue });
      return { newDocument: document2, removed };
    },
    copy: function(obj, key, document2) {
      var valueToCopy = getValueByPointer(document2, this.from);
      applyOperation(document2, { op: "add", path: this.path, value: _deepClone(valueToCopy) });
      return { newDocument: document2 };
    },
    test: function(obj, key, document2) {
      return { newDocument: document2, test: _areEquals(obj[key], this.value) };
    },
    _get: function(obj, key, document2) {
      this.value = obj[key];
      return { newDocument: document2 };
    }
  };
  var arrOps = {
    add: function(arr, i, document2) {
      if (isInteger(i)) {
        arr.splice(i, 0, this.value);
      } else {
        arr[i] = this.value;
      }
      return { newDocument: document2, index: i };
    },
    remove: function(arr, i, document2) {
      var removedList = arr.splice(i, 1);
      return { newDocument: document2, removed: removedList[0] };
    },
    replace: function(arr, i, document2) {
      var removed = arr[i];
      arr[i] = this.value;
      return { newDocument: document2, removed };
    },
    move: objOps.move,
    copy: objOps.copy,
    test: objOps.test,
    _get: objOps._get
  };
  function getValueByPointer(document2, pointer) {
    if (pointer == "") {
      return document2;
    }
    var getOriginalDestination = { op: "_get", path: pointer };
    applyOperation(document2, getOriginalDestination);
    return getOriginalDestination.value;
  }
  function applyOperation(document2, operation, validateOperation, mutateDocument, banPrototypeModifications, index) {
    if (validateOperation === void 0) {
      validateOperation = false;
    }
    if (mutateDocument === void 0) {
      mutateDocument = true;
    }
    if (banPrototypeModifications === void 0) {
      banPrototypeModifications = true;
    }
    if (index === void 0) {
      index = 0;
    }
    if (validateOperation) {
      if (typeof validateOperation == "function") {
        validateOperation(operation, 0, document2, operation.path);
      } else {
        validator(operation, 0);
      }
    }
    if (operation.path === "") {
      var returnValue = { newDocument: document2 };
      if (operation.op === "add") {
        returnValue.newDocument = operation.value;
        return returnValue;
      } else if (operation.op === "replace") {
        returnValue.newDocument = operation.value;
        returnValue.removed = document2;
        return returnValue;
      } else if (operation.op === "move" || operation.op === "copy") {
        returnValue.newDocument = getValueByPointer(document2, operation.from);
        if (operation.op === "move") {
          returnValue.removed = document2;
        }
        return returnValue;
      } else if (operation.op === "test") {
        returnValue.test = _areEquals(document2, operation.value);
        if (returnValue.test === false) {
          throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document2);
        }
        returnValue.newDocument = document2;
        return returnValue;
      } else if (operation.op === "remove") {
        returnValue.removed = document2;
        returnValue.newDocument = null;
        return returnValue;
      } else if (operation.op === "_get") {
        operation.value = document2;
        return returnValue;
      } else {
        if (validateOperation) {
          throw new JsonPatchError("Operation `op` property is not one of operations defined in RFC-6902", "OPERATION_OP_INVALID", index, operation, document2);
        } else {
          return returnValue;
        }
      }
    } else {
      if (!mutateDocument) {
        document2 = _deepClone(document2);
      }
      var path7 = operation.path || "";
      var keys = path7.split("/");
      var obj = document2;
      var t = 1;
      var len = keys.length;
      var existingPathFragment = void 0;
      var key = void 0;
      var validateFunction = void 0;
      if (typeof validateOperation == "function") {
        validateFunction = validateOperation;
      } else {
        validateFunction = validator;
      }
      while (true) {
        key = keys[t];
        if (key && key.indexOf("~") != -1) {
          key = unescapePathComponent(key);
        }
        if (banPrototypeModifications && (key == "__proto__" || key == "prototype" && t > 0 && keys[t - 1] == "constructor")) {
          throw new TypeError("JSON-Patch: modifying `__proto__` or `constructor/prototype` prop is banned for security reasons, if this was on purpose, please set `banPrototypeModifications` flag false and pass it to this function. More info in fast-json-patch README");
        }
        if (validateOperation) {
          if (existingPathFragment === void 0) {
            if (obj[key] === void 0) {
              existingPathFragment = keys.slice(0, t).join("/");
            } else if (t == len - 1) {
              existingPathFragment = operation.path;
            }
            if (existingPathFragment !== void 0) {
              validateFunction(operation, 0, document2, existingPathFragment);
            }
          }
        }
        t++;
        if (Array.isArray(obj)) {
          if (key === "-") {
            key = obj.length;
          } else {
            if (validateOperation && !isInteger(key)) {
              throw new JsonPatchError("Expected an unsigned base-10 integer value, making the new referenced value the array element with the zero-based index", "OPERATION_PATH_ILLEGAL_ARRAY_INDEX", index, operation, document2);
            } else if (isInteger(key)) {
              key = ~~key;
            }
          }
          if (t >= len) {
            if (validateOperation && operation.op === "add" && key > obj.length) {
              throw new JsonPatchError("The specified index MUST NOT be greater than the number of elements in the array", "OPERATION_VALUE_OUT_OF_BOUNDS", index, operation, document2);
            }
            var returnValue = arrOps[operation.op].call(operation, obj, key, document2);
            if (returnValue.test === false) {
              throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document2);
            }
            return returnValue;
          }
        } else {
          if (t >= len) {
            var returnValue = objOps[operation.op].call(operation, obj, key, document2);
            if (returnValue.test === false) {
              throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document2);
            }
            return returnValue;
          }
        }
        obj = obj[key];
        if (validateOperation && t < len && (!obj || typeof obj !== "object")) {
          throw new JsonPatchError("Cannot perform operation at the desired path", "OPERATION_PATH_UNRESOLVABLE", index, operation, document2);
        }
      }
    }
  }
  function applyPatch(document2, patch, validateOperation, mutateDocument, banPrototypeModifications) {
    if (mutateDocument === void 0) {
      mutateDocument = true;
    }
    if (banPrototypeModifications === void 0) {
      banPrototypeModifications = true;
    }
    if (validateOperation) {
      if (!Array.isArray(patch)) {
        throw new JsonPatchError("Patch sequence must be an array", "SEQUENCE_NOT_AN_ARRAY");
      }
    }
    if (!mutateDocument) {
      document2 = _deepClone(document2);
    }
    var results = new Array(patch.length);
    for (var i = 0, length_1 = patch.length; i < length_1; i++) {
      results[i] = applyOperation(document2, patch[i], validateOperation, true, banPrototypeModifications, i);
      document2 = results[i].newDocument;
    }
    results.newDocument = document2;
    return results;
  }
  function applyReducer(document2, operation, index) {
    var operationResult = applyOperation(document2, operation);
    if (operationResult.test === false) {
      throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document2);
    }
    return operationResult.newDocument;
  }
  function validator(operation, index, document2, existingPathFragment) {
    if (typeof operation !== "object" || operation === null || Array.isArray(operation)) {
      throw new JsonPatchError("Operation is not an object", "OPERATION_NOT_AN_OBJECT", index, operation, document2);
    } else if (!objOps[operation.op]) {
      throw new JsonPatchError("Operation `op` property is not one of operations defined in RFC-6902", "OPERATION_OP_INVALID", index, operation, document2);
    } else if (typeof operation.path !== "string") {
      throw new JsonPatchError("Operation `path` property is not a string", "OPERATION_PATH_INVALID", index, operation, document2);
    } else if (operation.path.indexOf("/") !== 0 && operation.path.length > 0) {
      throw new JsonPatchError('Operation `path` property must start with "/"', "OPERATION_PATH_INVALID", index, operation, document2);
    } else if ((operation.op === "move" || operation.op === "copy") && typeof operation.from !== "string") {
      throw new JsonPatchError("Operation `from` property is not present (applicable in `move` and `copy` operations)", "OPERATION_FROM_REQUIRED", index, operation, document2);
    } else if ((operation.op === "add" || operation.op === "replace" || operation.op === "test") && operation.value === void 0) {
      throw new JsonPatchError("Operation `value` property is not present (applicable in `add`, `replace` and `test` operations)", "OPERATION_VALUE_REQUIRED", index, operation, document2);
    } else if ((operation.op === "add" || operation.op === "replace" || operation.op === "test") && hasUndefined(operation.value)) {
      throw new JsonPatchError("Operation `value` property is not present (applicable in `add`, `replace` and `test` operations)", "OPERATION_VALUE_CANNOT_CONTAIN_UNDEFINED", index, operation, document2);
    } else if (document2) {
      if (operation.op == "add") {
        var pathLen = operation.path.split("/").length;
        var existingPathLen = existingPathFragment.split("/").length;
        if (pathLen !== existingPathLen + 1 && pathLen !== existingPathLen) {
          throw new JsonPatchError("Cannot perform an `add` operation at the desired path", "OPERATION_PATH_CANNOT_ADD", index, operation, document2);
        }
      } else if (operation.op === "replace" || operation.op === "remove" || operation.op === "_get") {
        if (operation.path !== existingPathFragment) {
          throw new JsonPatchError("Cannot perform the operation at a path that does not exist", "OPERATION_PATH_UNRESOLVABLE", index, operation, document2);
        }
      } else if (operation.op === "move" || operation.op === "copy") {
        var existingValue = { op: "_get", path: operation.from, value: void 0 };
        var error = validate([existingValue], document2);
        if (error && error.name === "OPERATION_PATH_UNRESOLVABLE") {
          throw new JsonPatchError("Cannot perform the operation from a path that does not exist", "OPERATION_FROM_UNRESOLVABLE", index, operation, document2);
        }
      }
    }
  }
  function validate(sequence, document2, externalValidator) {
    try {
      if (!Array.isArray(sequence)) {
        throw new JsonPatchError("Patch sequence must be an array", "SEQUENCE_NOT_AN_ARRAY");
      }
      if (document2) {
        applyPatch(_deepClone(document2), _deepClone(sequence), externalValidator || true);
      } else {
        externalValidator = externalValidator || validator;
        for (var i = 0; i < sequence.length; i++) {
          externalValidator(sequence[i], i, document2, void 0);
        }
      }
    } catch (e) {
      if (e instanceof JsonPatchError) {
        return e;
      } else {
        throw e;
      }
    }
  }
  function _areEquals(a, b) {
    if (a === b)
      return true;
    if (a && b && typeof a == "object" && typeof b == "object") {
      var arrA = Array.isArray(a), arrB = Array.isArray(b), i, length, key;
      if (arrA && arrB) {
        length = a.length;
        if (length != b.length)
          return false;
        for (i = length; i-- !== 0; )
          if (!_areEquals(a[i], b[i]))
            return false;
        return true;
      }
      if (arrA != arrB)
        return false;
      var keys = Object.keys(a);
      length = keys.length;
      if (length !== Object.keys(b).length)
        return false;
      for (i = length; i-- !== 0; )
        if (!b.hasOwnProperty(keys[i]))
          return false;
      for (i = length; i-- !== 0; ) {
        key = keys[i];
        if (!_areEquals(a[key], b[key]))
          return false;
      }
      return true;
    }
    return a !== a && b !== b;
  }

  // node_modules/.pnpm/fast-json-patch@3.1.1/node_modules/fast-json-patch/module/duplex.mjs
  var duplex_exports = {};
  __export(duplex_exports, {
    compare: () => compare,
    generate: () => generate,
    observe: () => observe,
    unobserve: () => unobserve
  });
  var beforeDict = /* @__PURE__ */ new WeakMap();
  var Mirror = (
    /** @class */
    /* @__PURE__ */ function() {
      function Mirror2(obj) {
        this.observers = /* @__PURE__ */ new Map();
        this.obj = obj;
      }
      return Mirror2;
    }()
  );
  var ObserverInfo = (
    /** @class */
    /* @__PURE__ */ function() {
      function ObserverInfo2(callback, observer) {
        this.callback = callback;
        this.observer = observer;
      }
      return ObserverInfo2;
    }()
  );
  function getMirror(obj) {
    return beforeDict.get(obj);
  }
  function getObserverFromMirror(mirror, callback) {
    return mirror.observers.get(callback);
  }
  function removeObserverFromMirror(mirror, observer) {
    mirror.observers.delete(observer.callback);
  }
  function unobserve(root, observer) {
    observer.unobserve();
  }
  function observe(obj, callback) {
    var patches = [];
    var observer;
    var mirror = getMirror(obj);
    if (!mirror) {
      mirror = new Mirror(obj);
      beforeDict.set(obj, mirror);
    } else {
      var observerInfo = getObserverFromMirror(mirror, callback);
      observer = observerInfo && observerInfo.observer;
    }
    if (observer) {
      return observer;
    }
    observer = {};
    mirror.value = _deepClone(obj);
    if (callback) {
      observer.callback = callback;
      observer.next = null;
      var dirtyCheck = function() {
        generate(observer);
      };
      var fastCheck = function() {
        clearTimeout(observer.next);
        observer.next = setTimeout(dirtyCheck);
      };
      if (typeof window !== "undefined") {
        window.addEventListener("mouseup", fastCheck);
        window.addEventListener("keyup", fastCheck);
        window.addEventListener("mousedown", fastCheck);
        window.addEventListener("keydown", fastCheck);
        window.addEventListener("change", fastCheck);
      }
    }
    observer.patches = patches;
    observer.object = obj;
    observer.unobserve = function() {
      generate(observer);
      clearTimeout(observer.next);
      removeObserverFromMirror(mirror, observer);
      if (typeof window !== "undefined") {
        window.removeEventListener("mouseup", fastCheck);
        window.removeEventListener("keyup", fastCheck);
        window.removeEventListener("mousedown", fastCheck);
        window.removeEventListener("keydown", fastCheck);
        window.removeEventListener("change", fastCheck);
      }
    };
    mirror.observers.set(callback, new ObserverInfo(callback, observer));
    return observer;
  }
  function generate(observer, invertible) {
    if (invertible === void 0) {
      invertible = false;
    }
    var mirror = beforeDict.get(observer.object);
    _generate(mirror.value, observer.object, observer.patches, "", invertible);
    if (observer.patches.length) {
      applyPatch(mirror.value, observer.patches);
    }
    var temp = observer.patches;
    if (temp.length > 0) {
      observer.patches = [];
      if (observer.callback) {
        observer.callback(temp);
      }
    }
    return temp;
  }
  function _generate(mirror, obj, patches, path7, invertible) {
    if (obj === mirror) {
      return;
    }
    if (typeof obj.toJSON === "function") {
      obj = obj.toJSON();
    }
    var newKeys = _objectKeys(obj);
    var oldKeys = _objectKeys(mirror);
    var changed = false;
    var deleted = false;
    for (var t = oldKeys.length - 1; t >= 0; t--) {
      var key = oldKeys[t];
      var oldVal = mirror[key];
      if (hasOwnProperty(obj, key) && !(obj[key] === void 0 && oldVal !== void 0 && Array.isArray(obj) === false)) {
        var newVal = obj[key];
        if (typeof oldVal == "object" && oldVal != null && typeof newVal == "object" && newVal != null && Array.isArray(oldVal) === Array.isArray(newVal)) {
          _generate(oldVal, newVal, patches, path7 + "/" + escapePathComponent(key), invertible);
        } else {
          if (oldVal !== newVal) {
            changed = true;
            if (invertible) {
              patches.push({ op: "test", path: path7 + "/" + escapePathComponent(key), value: _deepClone(oldVal) });
            }
            patches.push({ op: "replace", path: path7 + "/" + escapePathComponent(key), value: _deepClone(newVal) });
          }
        }
      } else if (Array.isArray(mirror) === Array.isArray(obj)) {
        if (invertible) {
          patches.push({ op: "test", path: path7 + "/" + escapePathComponent(key), value: _deepClone(oldVal) });
        }
        patches.push({ op: "remove", path: path7 + "/" + escapePathComponent(key) });
        deleted = true;
      } else {
        if (invertible) {
          patches.push({ op: "test", path: path7, value: mirror });
        }
        patches.push({ op: "replace", path: path7, value: obj });
        changed = true;
      }
    }
    if (!deleted && newKeys.length == oldKeys.length) {
      return;
    }
    for (var t = 0; t < newKeys.length; t++) {
      var key = newKeys[t];
      if (!hasOwnProperty(mirror, key) && obj[key] !== void 0) {
        patches.push({ op: "add", path: path7 + "/" + escapePathComponent(key), value: _deepClone(obj[key]) });
      }
    }
  }
  function compare(tree1, tree2, invertible) {
    if (invertible === void 0) {
      invertible = false;
    }
    var patches = [];
    _generate(tree1, tree2, patches, "", invertible);
    return patches;
  }

  // node_modules/.pnpm/fast-json-patch@3.1.1/node_modules/fast-json-patch/index.mjs
  var fast_json_patch_default = Object.assign({}, core_exports, duplex_exports, {
    JsonPatchError: PatchError,
    deepClone: _deepClone,
    escapePathComponent,
    unescapePathComponent
  });

  // node_modules/.pnpm/olid.ts@git+https+++codeberg.org+basil+OLID.ts.git#ca092d7f5dcc0b1db59e84e85e650c61a58c93b4_pzpyof43zttzesvjfn2oievxfe/node_modules/olid.ts/src/lib/lib.ts
  var import_zlib = __toESM(__require("zlib"), 1);
  var TILE_SIZE = 16;
  var PIXELS = TILE_SIZE * TILE_SIZE;
  var MASK_SIZE = 32;
  function applyDiffs(orig, deltas) {
    let canvas;
    let ctx;
    let firstDeltaDV;
    for (const delta of deltas) {
      const deltaDV = new DataView(delta);
      if (!firstDeltaDV)
        firstDeltaDV = deltaDV;
      if (deltaDV.getUint32(0) !== 4278179848 || deltaDV.getUint16(4) !== 56609)
        throw new Error("Invalid header");
      if (!canvas || !ctx) {
        canvas = document.createElement("canvas");
        canvas.width = Math.ceil(deltaDV.getUint32(6) / 16) * 16;
        canvas.height = Math.ceil(deltaDV.getUint32(10) / 16) * 16;
        ctx = canvas.getContext("2d", {
          willReadFrequently: true
        });
        ctx.drawImage(orig, 0, 0);
      }
      const compressedBitstreamAB = delta.slice(26, deltaDV.getUint32(22) + 26);
      const deltaBitstream = import_zlib.default.inflateSync(
        Buffer.from(new Uint8Array(compressedBitstreamAB))
      );
      const deltaBitstreamDV = new DataView(deltaBitstream.buffer);
      let deltaBitstreamPtr = 0;
      while (deltaBitstreamPtr < deltaBitstream.byteLength) {
        const tileX = deltaBitstreamDV.getUint16(deltaBitstreamPtr);
        const tileY = deltaBitstreamDV.getUint16(deltaBitstreamPtr + 2);
        const tileBitstreamLen = deltaBitstreamDV.getUint32(deltaBitstreamPtr + 4);
        deltaBitstreamPtr += 8;
        const tileBitstream = deltaBitstream.buffer.slice(deltaBitstreamPtr, deltaBitstreamPtr + tileBitstreamLen);
        deltaBitstreamPtr += tileBitstreamLen;
        let sourceBitmap;
        if (orig.width < tileX * TILE_SIZE || orig.height < tileY * TILE_SIZE)
          sourceBitmap = new ArrayBuffer(TILE_SIZE * TILE_SIZE * 4);
        else
          sourceBitmap = ctx.getImageData(tileX * TILE_SIZE, tileY * TILE_SIZE, TILE_SIZE, TILE_SIZE).data.buffer;
        const targetBitmap = applyDiffTile(new Uint32Array(sourceBitmap), new Uint8Array(tileBitstream));
        const imgData = new ImageData(new Uint8ClampedArray(targetBitmap.buffer), TILE_SIZE, TILE_SIZE);
        ctx.putImageData(imgData, tileX * TILE_SIZE, tileY * TILE_SIZE);
      }
    }
    if (!canvas || !firstDeltaDV)
      throw new Error("No deltas supplied");
    if (canvas.width !== firstDeltaDV.getUint32(6) || canvas.height !== firstDeltaDV.getUint32(10)) {
      const fc = document.createElement("canvas");
      fc.width = firstDeltaDV.getUint32(6);
      fc.height = firstDeltaDV.getUint32(10);
      fc.getContext("2d").drawImage(canvas, 0, 0);
      canvas = fc;
    }
    return canvas.toDataURL("type/png");
  }
  function applyDiffTile(source, diffStream) {
    if (diffStream.length < MASK_SIZE)
      throw new Error("Diff stream is below 32 bytes which is impossible");
    if (source.length !== PIXELS)
      throw new Error("Source must be 1024 bytes long!");
    const bitmap = new Uint8Array(MASK_SIZE);
    for (let i = 0; i < MASK_SIZE; i++)
      bitmap[i] = diffStream[i];
    const result = source.slice();
    let diff_stream_ptr = MASK_SIZE;
    for (let i = 0; i < PIXELS; i++) {
      if ((bitmap[Math.floor(i / 8)] >> i % 8 & 1) === 1) {
        if (diffStream.length < diff_stream_ptr + 4)
          throw new Error("Diff stream truncated");
        result[i] = (diffStream[diff_stream_ptr] << 24) + (diffStream[diff_stream_ptr + 1] << 16) + (diffStream[diff_stream_ptr + 2] << 8) + diffStream[diff_stream_ptr + 3];
        diff_stream_ptr += 4;
      }
    }
    return result;
  }

  // src/tomb/util.ts
  var has = (obj, property) => Object.prototype.hasOwnProperty.call(obj, property);
  var getModById = (id) => $tomb.mods.find((mod) => mod.id === id);
  var s = (num) => num === 1 ? "" : "s";
  var isObject = (item) => item && typeof item === "object" && !Array.isArray(item);
  function deepMerge(target, ...sources) {
    if (!sources.length)
      return target;
    const source = sources.shift();
    if (isObject(target) && isObject(source)) {
      for (const key in source) {
        if (isObject(source[key])) {
          if (!target[key])
            Object.assign(target, { [key]: {} });
          deepMerge(target[key], source[key]);
        } else {
          Object.assign(target, { [key]: source[key] });
        }
      }
    }
    return deepMerge(target, ...sources);
  }
  var fromK9A = (fullPath) => {
    if (/^data(\/|\\)/.test(fullPath))
      return fullPath.replace(/\.k9a$/, ".json");
    if (/^img(\/|\\)/.test(fullPath))
      return fullPath.replace(/\.k9a$/, ".png");
    if (/^audio(\/|\\)/.test(fullPath))
      return fullPath.replace(/\.k9a$/, ".ogg");
    return fullPath;
  };
  var bootLog = (msg) => {
    const log = document.querySelector("#log");
    if (log) {
      log.innerText += msg + "\n";
      log.scrollTop = log.scrollHeight;
    }
  };
  var gameVersion = () => GAME_VERSION != null ? GAME_VERSION : VERSION;

  // src/mods/tomb/plugins/lib/util/decrypt.ts
  function decrypt(rawUint, filePath) {
    if (Crypto.dekit)
      return new Uint8Array(Crypto.dekit(rawUint, filePath, Crypto.guard()));
    let mask = Crypto.mask(filePath);
    const signatureLength = SIGNATURE.length;
    const fileSignature = rawUint.slice(0, signatureLength);
    const expectedSignature = Array.from(SIGNATURE).map(
      (char) => (char.charCodeAt(0) ^ mask) % 256
    );
    if (fileSignature.toString() !== expectedSignature.toString()) {
      return rawUint;
    }
    let firstDataByte = rawUint[signatureLength];
    const data = rawUint.slice(signatureLength + 1);
    if (firstDataByte === 0) {
      firstDataByte = data.length;
    }
    for (let i = 0; i < firstDataByte; i++) {
      const byte = data[i];
      data[i] = (data[i] ^ mask) % 256;
      mask = mask << 1 ^ byte;
    }
    return data;
  }

  // src/tomb/classes/cache.ts
  var Cache = class {
    constructor() {
      __publicField(this, "cache");
      this.cache = {
        delta: {
          data: {},
          image: {}
        },
        static: {
          asset: {},
          plugin: {}
        }
      };
    }
    getOriginalFile(filePath) {
      let buf, newFilePath;
      try {
        newFilePath = filePath.replace(/\.(png|ogg|json)$/, ".k9a");
        buf = import_fs.default.readFileSync(newFilePath);
      } catch (e) {
        newFilePath = filePath;
        buf = import_fs.default.readFileSync(newFilePath);
      }
      const decrypted = decrypt(new Uint8Array(buf), newFilePath);
      return decrypted;
    }
    getStaticAsset(filePath) {
      if (!has(this.cache.static.asset, filePath)) {
        const modId = $tomb.patches.static.assets[filePath];
        const mod = getModById(modId);
        const data = mod.readFile(filePath);
        this.cache.static.asset[filePath] = URL.createObjectURL(new Blob([data]));
      }
      return this.cache.static.asset[filePath];
    }
    getStaticPlugin(filePath) {
      if (!has(this.cache.static.plugin, filePath)) {
        const modId = $tomb.patches.static.plugin[filePath];
        const mod = getModById(modId);
        const data = mod.readTextFile(filePath.replace(/^.+?\//, ""));
        this.cache.static.plugin[filePath] = URL.createObjectURL(
          new Blob([data])
        );
      }
      return this.cache.static.plugin[filePath];
    }
    getDeltaData(filePath) {
      if (!has(this.cache.delta.data, filePath)) {
        const patches = $tomb.patches.delta.data[filePath];
        const decrypted = this.getOriginalFile(import_path.default.join("www", filePath));
        const str = new TextDecoder().decode(decrypted);
        const patched = applyPatch(JSON.parse(str), patches).newDocument;
        this.cache.delta.data[filePath] = URL.createObjectURL(
          new Blob([JSON.stringify(patched)])
        );
      }
      return this.cache.delta.data[filePath];
    }
    async generatePatchedImages() {
      const imageCount = Object.keys($tomb.patches.delta.image).length;
      bootLog(`Patching ${imageCount} image${s(imageCount)}`);
      const _padLength = imageCount.toString().length;
      const pad = (i2) => i2.toString().padStart(_padLength, "0");
      let i = 1;
      for (const [filePath, modIds] of Object.entries(
        $tomb.patches.delta.image
      )) {
        bootLog(`Patching image [${pad(i++)}/${imageCount}] ${filePath}`);
        const decrypted = this.getOriginalFile(import_path.default.join("www", filePath));
        const img = await createImageBitmap(new Blob([decrypted]));
        const deltas = modIds.map((modId) => {
          const buffer = getModById(modId).readFile(filePath + ".olid");
          const arrayBuffer = new ArrayBuffer(buffer.length);
          const view = new Uint8Array(arrayBuffer);
          for (let i2 = 0; i2 < buffer.length; ++i2) {
            view[i2] = buffer[i2];
          }
          return arrayBuffer;
        });
        const data = applyDiffs(img, deltas);
        this.cache.delta.image[filePath] = import_zlib2.default.deflateSync(data);
      }
    }
    getDeltaImage(filePath) {
      return import_zlib2.default.inflateSync(this.cache.delta.image[filePath]).toString();
    }
    isAssetModified(filePath) {
      return has($tomb.patches.delta.data, filePath) || has($tomb.patches.delta.image, filePath) || has($tomb.patches.static.assets, filePath) || has($tomb.patches.static.plugin, filePath);
    }
  };

  // src/tomb/classes/gui.ts
  var GUI = class {
    /**
     * Utility function to create and style an HTML element.
     * @param node HTML element, like 'p' or 'div'
     * @param styles An
     * @returns The created element
     */
    e(node, styles = {}) {
      const el = document.createElement(node);
      for (const [key, val] of Object.entries(styles)) {
        el.style[key] = val;
      }
      return el;
    }
    showError(error, exit = false) {
      const { e } = this;
      const container = e("div", {
        zIndex: "100",
        position: "absolute",
        top: "40px",
        left: "50%",
        width: "400px",
        transform: "translateX(-50%)",
        padding: "12px 8px",
        border: "1px solid #931b2b",
        borderRadius: "4px",
        background: "radial-gradient(circle at top, #480e15 25%, #3e070d)",
        color: "white",
        font: "inherit",
        fontSize: "inherit"
      });
      const title = e("h1", {
        textAlign: "center",
        margin: "0",
        marginBottom: "12px",
        fontSize: "1.5rem",
        textShadow: "0 3px 2px #200306"
      });
      title.innerText = "An error occurred";
      container.append(title);
      const errorContainer = e("div", {
        padding: "8px",
        borderRadius: "4px",
        backgroundColor: "#1a0000",
        boxShadow: "0 4px 8px -2px #24010f, inset 0 0 16px #140000"
      });
      if (error.message) {
        for (const line of error.message.split("\n")) {
          const message = e("p", {
            whiteSpace: "pre-wrap",
            fontFamily: "monospace",
            margin: "0",
            lineHeight: "1.25",
            marginBottom: "8px"
          });
          message.innerText = line;
          errorContainer.append(message);
        }
      }
      const stackContainer = e("div", {
        overflow: "auto",
        marginTop: "16px"
      });
      stackContainer.id = "tomb-stack";
      const style = e("style");
      style.innerText = `
			#tomb-stack::-webkit-scrollbar {
				background-color: transparent;
				height: 8px;
			}

			#tomb-stack::-webkit-scrollbar-thumb {
				background-color: #650e17;
				border: 1px solid #76101b;
				border-radius: 4px;
			}
		`;
      document.head.appendChild(style);
      const lines = error.stack.slice(`${error.name}: ${error.message}`.length).split("\n").slice(1);
      for (const line of lines) {
        const [fn, file] = (() => {
          const fnAndFile = line.match(/^\s+at (.+) \((.+?)\)$/);
          if (fnAndFile)
            return [fnAndFile[1], fnAndFile[2]];
          const file2 = line.match(/^\s+at (.+?)$/);
          if (file2)
            return [void 0, file2[1]];
          console.error("Tomb Error GUI: Failed to parse line: " + line);
          return [void 0, ""];
        })();
        const lineContainer = e("span", {
          display: "block",
          marginLeft: "2ch",
          fontFamily: "monospace",
          fontSize: "0.75rem",
          lineHeight: "1.25",
          whiteSpace: "pre"
        });
        if (fn) {
          const fnLine = e("span", {
            fontWeight: "600",
            whiteSpace: "pre"
          });
          fnLine.innerText = fn + " ";
          lineContainer.append(fnLine);
        }
        const source = e("span", {
          color: "#ea7777",
          whiteSpace: "nowrap"
        });
        source.innerText = file.replace(/^chrome-extension:\/\/\w+\/www\//, "");
        lineContainer.append(source);
        stackContainer.append(lineContainer);
      }
      errorContainer.append(stackContainer);
      container.append(errorContainer);
      const buttons = e("div", {
        display: "flex",
        justifyContent: "center",
        gap: "8px",
        marginTop: "8px"
      });
      const buttonStyles = {
        padding: "8px 0px",
        width: "100%",
        borderRadius: "4px",
        backgroundColor: "#1a0000",
        border: "unset",
        color: "inherit",
        fontFamily: "inherit",
        fontSize: "inherit",
        fontWeight: "600",
        boxShadow: "0 4px 8px -2px #24010f, inset 0 0 16px #140000",
        cursor: "pointer"
      };
      const reload = e("button", buttonStyles);
      reload.innerText = "Reload";
      reload.addEventListener("click", () => chrome.runtime.reload());
      buttons.append(reload);
      if (process.versions["nw-flavor"] === "sdk") {
        const openDevTools = e("button", buttonStyles);
        openDevTools.innerText = "Open Dev Tools";
        openDevTools.addEventListener(
          "click",
          () => __require("nw.gui").Window.get().showDevTools()
        );
        buttons.append(openDevTools);
      }
      const closeError = e("button", buttonStyles);
      closeError.innerText = "Close";
      closeError.addEventListener("click", () => container.remove());
      buttons.append(closeError);
      container.append(buttons);
      document.body.append(container);
      if (exit)
        window.stop();
    }
  };

  // src/tomb/mods.ts
  var import_fs3 = __toESM(__require("fs"), 1);
  var import_path3 = __toESM(__require("path"), 1);

  // src/tomb/classes/mod.ts
  var import_fs2 = __toESM(__require("fs"), 1);
  var import_path2 = __toESM(__require("path"), 1);
  var import_node_stream_zip = __toESM(require_node_stream_zip(), 1);
  var modsFolder = import_path2.default.join("tomb", "mods");
  var Mod = class _Mod {
    constructor(type, path7, json, zip) {
      __publicField(this, "type");
      // ZIP support may be added in the future is added
      __publicField(this, "path");
      // Either the name of the folder, or in the future, the name (without the extension) of the ZIP file
      __publicField(this, "zip");
      __publicField(this, "id");
      __publicField(this, "name");
      __publicField(this, "authors");
      __publicField(this, "description");
      __publicField(this, "version");
      __publicField(this, "dependencies");
      __publicField(this, "files");
      if (json.dependencies === void 0)
        throw new Error(`Mod "${json.name}" is missing the \`dependencies\` key. Download a newer version of this mod or ask the developer to update it.`);
      this.type = type;
      this.path = path7;
      if (zip)
        this.zip = zip;
      this.id = json.id;
      this.name = json.name;
      this.authors = json.authors;
      this.description = json.description;
      this.version = json.version;
      this.dependencies = json.dependencies;
      this.files = json.files;
    }
    static init(pathInMods) {
      return new Promise((resolve, reject) => {
        const modPath = import_path2.default.join(modsFolder, pathInMods);
        const stat = import_fs2.default.statSync(import_path2.default.join(modsFolder, pathInMods));
        if (stat.isDirectory()) {
          const modJsonPath = import_path2.default.join(modPath, "mod.json");
          if (!import_fs2.default.existsSync(modJsonPath)) {
            throw new Error(
              `Mod at location ${pathInMods} does not have a mod.json at the expected location, ${modJsonPath}`
            );
          }
          const rawJson = import_fs2.default.readFileSync(modJsonPath, "utf8");
          const modJson = JSON.parse(rawJson);
          const mod = new _Mod("folder" /* Folder */, pathInMods, modJson);
          resolve(mod);
        } else if (stat.isFile()) {
          const zip = new import_node_stream_zip.default({
            file: modPath
          });
          zip.on("ready", () => {
            let buffer;
            try {
              buffer = zip.entryDataSync("mod.json");
            } catch (e) {
              throw new Error(
                `Could not read mod.json in ${pathInMods}. Make sure mod.json is at the root of the ZIP.`
              );
            }
            const modJson = JSON.parse(buffer.toString());
            try {
              const mod = new _Mod("zip" /* Zip */, pathInMods, modJson, zip);
              resolve(mod);
            } catch (e) {
              reject(e);
            }
          });
        } else {
          throw new Error("Other mod format not supported");
        }
      });
    }
    exists(pathToFile) {
      if (this.type === "folder" /* Folder */)
        return import_fs2.default.existsSync(import_path2.default.join(modsFolder, this.path, pathToFile));
      if (this.type === "zip" /* Zip */)
        return this.zip.entries()[pathToFile] !== void 0;
    }
    readFile(pathToFile) {
      if (this.type === "folder" /* Folder */)
        return import_fs2.default.readFileSync(import_path2.default.join(modsFolder, this.path, pathToFile));
      if (this.type === "zip" /* Zip */)
        return this.zip.entryDataSync(pathToFile);
    }
    readTextFile(pathToFile) {
      if (this.type === "folder" /* Folder */)
        return import_fs2.default.readFileSync(
          import_path2.default.join(modsFolder, this.path, pathToFile),
          "utf8"
        );
      if (this.type === "zip" /* Zip */)
        return this.zip.entryDataSync(pathToFile).toString();
    }
  };

  // src/tomb/mods.ts
  async function parseMods() {
    const mods = [];
    for (const entry of import_fs3.default.readdirSync(modsFolder)) {
      const stat = import_fs3.default.statSync(import_path3.default.join(modsFolder, entry));
      if (!stat.isDirectory() && !entry.toLowerCase().endsWith(".zip"))
        continue;
      const mod = await Mod.init(entry);
      if (!/^[0-9a-z-_]{1,}$/.test(mod.id))
        throw new Error(
          `Mod ID Error: Mod "${mod.name}" has ID "${mod.id}" but mod IDs must only consist of lowercase letters, numbers, and the following characters: '-' and '_'`
        );
      const conflict = mods.find(({ id }) => id === mod.id);
      if (conflict)
        throw new Error(
          `Mod ID Conflict: Mod "${mod.name}" has ID "${mod.id}" which conflicts with mod "${conflict.name}"`
        );
      mods.push(mod);
    }
    return mods;
  }
  function processMods(mods) {
    const dataDelta = {};
    const imageDelta = {};
    const pluginStatic = {};
    const assetStatic = {};
    const lanuageDelta = {};
    const prevLanguages = {};
    for (const mod of mods) {
      if (mod.files.dataDeltas) {
        for (let deltaPath of mod.files.dataDeltas) {
          if (!mod.exists(deltaPath))
            throw new Error(
              `Mod "${mod.name}" missing JSON delta patch at path: ${deltaPath}`
            );
          const delta = JSON.parse(mod.readTextFile(deltaPath));
          deltaPath = deltaPath.replace(/\.jsond$/, ".json");
          if (has(dataDelta, deltaPath))
            dataDelta[deltaPath] = [...dataDelta[deltaPath], ...delta];
          else
            dataDelta[deltaPath] = delta;
        }
      }
      if (mod.files.imageDeltas) {
        for (let deltaPath of mod.files.imageDeltas) {
          if (!mod.exists(deltaPath))
            throw new Error(
              `Mod "${mod.name}" missing image delta patch at path: ${deltaPath}`
            );
          deltaPath = deltaPath.replace(/\.olid$/, "");
          if (has(imageDelta, deltaPath))
            imageDelta[deltaPath] = [...imageDelta[deltaPath], mod.id];
          else
            imageDelta[deltaPath] = [mod.id];
        }
      }
      if (mod.files.plugins) {
        for (const pluginPath of mod.files.plugins) {
          if (!mod.exists(pluginPath))
            throw new Error(
              `Mod "${mod.name}" missing plugin at path: ${pluginPath}`
            );
          if (import_fs3.default.existsSync(import_path3.default.join("www", "js", "plugins", pluginPath)))
            throw new Error(
              `Conflict: Mod "${mod.name}" is trying to inject "${pluginPath}", but the file path conflicts with an existing game plugin at "www/js/plugins/${pluginPath}"
Mod developers: Consider moving the injected file to a subfolder or renaming it.`
            );
          pluginStatic[mod.id + "/" + pluginPath] = mod.id;
        }
      }
      if (mod.files.assets) {
        for (const assetPath of mod.files.assets) {
          if (!mod.exists(assetPath))
            throw new Error(
              `Mod "${mod.name}" missing asset at path: ${assetPath}`
            );
          if (has(assetStatic, assetPath)) {
            const conflictingMod = getModById(assetStatic[assetPath]);
            throw new Error(
              `Conflict: Plugin "${mod.name}" is trying to override ${assetPath}, but it's already overridden by "${conflictingMod.name}"`
            );
          }
          assetStatic[assetPath] = mod.id;
        }
      }
      if (mod.files.languages) {
        for (const languagePath of mod.files.languages) {
          if (!mod.exists(languagePath))
            throw new Error(
              `Mod "${mod.name}" missing language file at path: ${languagePath}`
            );
          let lang;
          try {
            lang = JSON.parse(mod.readTextFile(languagePath));
          } catch (e) {
            throw new Error(
              `Error: Failed to read file ${languagePath} from mod "${mod.name}"`
            );
          }
          const name = import_path3.default.basename(languagePath, ".json");
          for (const langKey of [
            "sysLabel",
            "sysMenus",
            "labelLUT",
            "linesLUT"
          ]) {
            if (lang[langKey]) {
              if (!lanuageDelta[name])
                lanuageDelta[name] = {};
              if (!lanuageDelta[name][langKey])
                lanuageDelta[name][langKey] = {};
              for (const [key, val] of Object.entries(lang[langKey])) {
                if (lanuageDelta[name][langKey][key]) {
                  for (const { modName, lang: lang2 } of prevLanguages[name]) {
                    if (lang2[langKey] && lang2[langKey][key])
                      throw new Error(
                        `Conflict: Mod ${mod.name} trying to set "${langKey}[${key}]" but it has already been set by mod "${modName}"`
                      );
                  }
                }
                lanuageDelta[name][langKey][key] = val;
              }
            }
          }
          if (prevLanguages[name])
            prevLanguages[name].push({ modName: mod.name, lang });
          else
            prevLanguages[name] = [{ modName: mod.name, lang }];
        }
      }
    }
    for (const asset of Object.keys(assetStatic)) {
      if (dataDelta[asset] || imageDelta[asset]) {
        throw new Error(
          `Conflict: File ${asset} cannot be both asset replaced and delta modified.`
        );
      }
    }
    return {
      delta: {
        data: dataDelta,
        image: imageDelta,
        language: lanuageDelta
      },
      static: {
        plugin: pluginStatic,
        assets: assetStatic
      }
    };
  }

  // src/tomb/dependencies.ts
  var import_semver = __toESM(require_semver2(), 1);
  function checkSpec() {
    const errors = [];
    for (const mod of $tomb.mods) {
      const { spec } = mod.dependencies;
      if (!(0, import_semver.satisfies)(spec, "0.1.0")) {
        errors.push(`Mod "${mod.name}" expects support for the mod.json spec version "${spec}", but this version of Tomb does not support it.`);
        continue;
      }
    }
    if (errors.length > 0)
      throw new Error(`Error${s(errors.length)} encountered:
- ${errors.join("\n- ")}`);
  }
  function checkMods() {
    const errors = [];
    for (const mod of $tomb.mods) {
      const { mods } = mod.dependencies;
      if (mods === void 0)
        continue;
      for (const [id, range] of Object.entries(mods)) {
        const depMod = getModById(id);
        if (!depMod) {
          errors.push(`Mod "${mod.name}" expects a mod with the ID of "${id}" to be installed, but no mod with that ID could be found.`);
          continue;
        }
        if (!(0, import_semver.satisfies)(depMod.version, range)) {
          errors.push(`Mod "${mod.name}" expects a different version of the mod "${depMod.name}" | Expected range: "${range}" Recived: "${depMod.version}"`);
          continue;
        }
      }
    }
    if (errors.length > 0)
      throw new Error(`Error${s(errors.length)} encountered:
- ${errors.join("\n- ")}`);
  }
  function checkGame() {
    const errors = [];
    for (const mod of $tomb.mods) {
      const { game } = mod.dependencies;
      if (!(0, import_semver.satisfies)(gameVersion(), game)) {
        errors.push(`Mod "${mod.name}" expects a different version of the game | Expected range: "${game}" Recived: "${gameVersion()}"`);
        continue;
      }
    }
    if (errors.length > 0)
      throw new Error(`Error${s(errors.length)} encountered:
- ${errors.join("\n- ")}`);
  }

  // src/tomb/patches/patchNetRequests.ts
  function patchURL(originalURL) {
    if (originalURL === "")
      return "index.html";
    let url = fromK9A(decodeURI(originalURL));
    if (!$tomb.cache.isAssetModified(url))
      return originalURL;
    let patched = false;
    if (has($tomb.patches.delta.data, url)) {
      url = $tomb.cache.getDeltaData(url);
      patched = true;
    }
    if (has($tomb.patches.delta.image, url)) {
      url = $tomb.cache.getDeltaImage(url);
      patched = true;
    }
    if (has($tomb.patches.static.assets, url)) {
      if (patched)
        throw new Error(
          `Attempting to modify ${url}, but it has already been delta modified.`
        );
      url = $tomb.cache.getStaticAsset(url);
    }
    return url;
  }
  function patchNetRequests() {
    before(
      "open",
      XMLHttpRequest.prototype,
      (args) => {
        args[1] = patchURL(args[1]);
        return args;
      }
    );
    before("fetch", window, (args) => {
      args[0] = patchURL(args[0]);
      return args;
    });
  }

  // src/tomb/patches/patchScripts.ts
  function patchScripts() {
    instead("loadScript", PluginManager, function([name]) {
      let url;
      const noEnding = name.slice(0, -3);
      if (has($tomb.patches.static.plugin, noEnding))
        url = $tomb.cache.getStaticPlugin(noEnding);
      else
        url = this._path + name;
      const script = document.createElement("script");
      script.type = "text/javascript";
      script.src = url;
      script.async = false;
      script.onerror = this.onError.bind(this);
      script._url = url;
      document.body.appendChild(script);
    });
  }

  // src/tomb/patches/patchLang.ts
  var import_path4 = __toESM(__require("path"), 1);
  function handleLang([absFilePath], response) {
    const dirs = import_path4.default.dirname(absFilePath).split(import_path4.default.sep);
    const name = dirs[dirs.length - 1];
    const lang = $tomb.patches.delta.language[name];
    if (!lang)
      return;
    return deepMerge(response, lang);
  }
  function patchLang() {
    $tomb.lib.spitroast.before("run", SceneManager, () => {
      $tomb.lib.lang = {
        loadLOC: function(filePath) {
          return Lang.loadLOC(filePath);
        },
        loadTXT: function(filePath) {
          return Lang.loadTXT(filePath);
        },
        loadCSV: function(filePath) {
          return Lang.loadCSV(filePath);
        }
      };
      $tomb.lib.spitroast.after("loadLOC", Lang, handleLang);
      $tomb.lib.spitroast.after("loadTXT", Lang, handleLang);
      $tomb.lib.spitroast.after("loadCSV", Lang, handleLang);
    });
  }

  // src/tomb/patches/patchDekit.ts
  function patchDekit() {
    if (Crypto.dekit) {
      $tomb.lib.spitroast.instead(
        "dekit",
        Crypto,
        function(args, orig) {
          const [content, path7] = args;
          if ($tomb.cache.isAssetModified(fromK9A(decodeURI(path7)))) {
            return content;
          }
          return orig.apply(this, args);
        }
      );
    }
  }

  // src/tomb/patches/patchVideos.ts
  function patchURL2(originalURL) {
    const url = fromK9A(decodeURI(originalURL));
    if (!$tomb.cache.isAssetModified(url))
      return originalURL;
    return $tomb.cache.getStaticAsset(url);
  }
  function patchVideos() {
    before(
      "_playVideo",
      Graphics,
      (args) => {
        args[0] = patchURL2(args[0]);
        return args;
      }
    );
  }

  // src/tomb/classes/tomb.ts
  var Tomb = class {
    constructor() {
      __publicField(this, "version");
      __publicField(this, "mods");
      __publicField(this, "patches");
      __publicField(this, "cache");
      __publicField(this, "gui");
      __publicField(this, "lib");
      if (has(window, "$tomb"))
        throw new Error(
          "Tomb has already been initialized ($tomb global already exists)"
        );
      window.$tomb = this;
      this.version = "0.6.0-beta.5";
      this.gui = new GUI();
      window.addEventListener("error", (e) => {
        bootLog("Error: " + e.message);
        this.gui.showError(e.error, true);
      });
      this.cache = new Cache();
      this.lib = {
        spitroast: esm_exports,
        semver: { satisfies: import_semver2.satisfies }
      };
    }
    async loadMods() {
      bootLog("Loading mods");
      this.mods = await parseMods();
      this.hook("tombPostModParse");
      checkSpec();
      checkMods();
      this.patches = processMods(this.mods);
      this.hook("tombPostModProcess");
      const count = this.mods.length;
      bootLog(`${count} mod${s(count)} loaded`);
    }
    init() {
      patchNetRequests();
    }
    // Taken from CALM (which I think took it from CCLoader?)
    // https://github.com/ac2pic/CALM/blob/6ebdfbf4e8fa89c1b40d8438f8d85bc7df193e10/calm/js/calm.js#L37
    loadGame() {
      bootLog("Loading the game");
      const indexSource = import_fs4.default.readFileSync(import_path5.default.join("www", "index.html"), "utf8");
      const index = new DOMParser().parseFromString(indexSource, "text/html");
      const base = index.createElement("base");
      base.href = "/www/";
      index.head.insertBefore(base, index.head.firstChild);
      index.body.insertBefore(document.querySelector("#log"), index.body.firstChild);
      const formatScript = (fn) => "(" + fn.toString() + ")();";
      {
        const script = index.createElement("script");
        script.type = "text/javascript";
        script.textContent = formatScript(() => $tomb.postPlugins());
        index.querySelector('script[src="js/plugins.js"]').after(script);
      }
      {
        const script = index.createElement("script");
        script.type = "text/javascript";
        script.textContent = formatScript(() => $tomb.preWindowLoad());
        index.body.append(script);
      }
      document.open();
      document.write(index.documentElement.outerHTML);
      document.close();
      process.mainModule.filename = import_path5.default.join(
        process.mainModule.filename,
        "..",
        "..",
        "www",
        "index.html"
      );
    }
    hook(hook) {
      bootLog("Running hook " + hook);
      const injections = [];
      for (const mod of this.mods) {
        if (!mod.files.inject)
          continue;
        for (const injection of mod.files.inject) {
          if (injection.at === hook) {
            if (!mod.exists(injection.file))
              throw new Error(
                `Mod "${mod.name}" is trying to inject ${hook} hook, but the specified file "${injection.file}" does not exist`
              );
            injections.push(mod.readTextFile(injection.file));
          }
        }
      }
      for (const injection of injections) {
        const fn = new Function("$tomb", injection);
        fn(this);
      }
    }
    postPlugins() {
      for (const key of Object.keys(this.patches.static.plugin)) {
        const modId = this.patches.static.plugin[key];
        const mod = getModById(modId);
        window.$plugins.push({
          name: key,
          // Whether or not the plugin is enabled
          status: true,
          description: `A plugin injected by Tomb from the mod "${mod.name}"`,
          parameters: {}
        });
      }
      this.hook("tombPostPluginInject");
      patchScripts();
      patchLang();
      patchVideos();
    }
    preWindowLoad() {
      const orig = window.onload;
      window.onload = async function(...args) {
        try {
          checkGame();
        } catch (e) {
          $tomb.gui.showError(e);
          throw e;
        }
        patchDekit();
        await $tomb.cache.generatePatchedImages();
        document.querySelector("#log").remove();
        orig.apply(this, args);
      };
    }
  };

  // src/tomb/index.ts
  (async () => {
    try {
      bootLog("Tomb v0.6.0-beta.5");
      new Tomb();
      await $tomb.loadMods();
      $tomb.init();
      $tomb.loadGame();
    } catch (e) {
      console.error(e);
      $tomb.gui.showError(e);
    }
  })();
})();
//! NOTE: I'm not sure what the expected behavior for two patches that influence the same area is
/*! Bundled license information:

node-stream-zip/node_stream_zip.js:
  (**
   * @license node-stream-zip | (c) 2020 Antelle | https://github.com/antelle/node-stream-zip/blob/master/LICENSE
   * Portions copyright https://github.com/cthackers/adm-zip | https://raw.githubusercontent.com/cthackers/adm-zip/master/LICENSE
   *)

fast-json-patch/module/helpers.mjs:
  (*!
   * https://github.com/Starcounter-Jack/JSON-Patch
   * (c) 2017-2022 Joachim Wester
   * MIT licensed
   *)

fast-json-patch/module/duplex.mjs:
  (*!
   * https://github.com/Starcounter-Jack/JSON-Patch
   * (c) 2017-2021 Joachim Wester
   * MIT license
   *)
*/
