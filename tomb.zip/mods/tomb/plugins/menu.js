(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // src/mods/tomb/plugins/menu.ts
  var import_fs20 = __toESM(__require("fs"), 1);
  var import_path12 = __toESM(__require("path"), 1);

  // src/mods/tomb/plugins/lib/genProject.ts
  var import_fs3 = __toESM(__require("fs"), 1);
  var import_path3 = __toESM(__require("path"), 1);

  // src/mods/tomb/plugins/lib/util/fileList.ts
  var import_fs = __toESM(__require("fs"), 1);
  var import_path = __toESM(__require("path"), 1);
  function fileList(folder, fragment = "") {
    const currentPath = import_path.default.join(folder, fragment);
    const entries = import_fs.default.readdirSync(currentPath);
    const files = [];
    for (const entry of entries) {
      if (entry === ".DS_Store")
        continue;
      const currentFile = import_path.default.join(currentPath, entry);
      const stats = import_fs.default.statSync(currentFile);
      if (stats.isFile()) {
        files.push(import_path.default.join(fragment, entry));
      } else if (stats.isDirectory()) {
        const subDir = fileList(folder, import_path.default.join(fragment, entry));
        for (const file of subDir) {
          files.push(file);
        }
      } else {
        throw new Error(`${currentFile} is not a file or a folder`);
      }
    }
    return files;
  }

  // src/mods/tomb/plugins/lib/util/fs.ts
  var import_fs2 = __toESM(__require("fs"), 1);
  var import_path2 = __toESM(__require("path"), 1);

  // src/mods/tomb/plugins/lib/util/decrypt.ts
  function decrypt(rawUint, filePath) {
    if (Crypto.dekit)
      return new Uint8Array(Crypto.dekit(rawUint, filePath, Crypto.guard()));
    let mask = Crypto.mask(filePath);
    const signatureLength = SIGNATURE.length;
    const fileSignature = rawUint.slice(0, signatureLength);
    const expectedSignature = Array.from(SIGNATURE).map(
      (char) => (char.charCodeAt(0) ^ mask) % 256
    );
    if (fileSignature.toString() !== expectedSignature.toString()) {
      return rawUint;
    }
    let firstDataByte = rawUint[signatureLength];
    const data = rawUint.slice(signatureLength + 1);
    if (firstDataByte === 0) {
      firstDataByte = data.length;
    }
    for (let i = 0; i < firstDataByte; i++) {
      const byte = data[i];
      data[i] = (data[i] ^ mask) % 256;
      mask = mask << 1 ^ byte;
    }
    return data;
  }

  // src/mods/tomb/plugins/lib/util/fs.ts
  function readFile(path13) {
    const data = import_fs2.default.readFileSync(path13);
    return decrypt(new Uint8Array(data), path13);
  }
  function ensureDir(pathStr) {
    let current = "";
    const segments = pathStr.split(import_path2.default.sep);
    for (const segment of segments) {
      current = import_path2.default.join(current, segment);
      if (!import_fs2.default.existsSync(current))
        import_fs2.default.mkdirSync(current);
    }
  }
  function writeFile(filePath, data) {
    ensureDir(import_path2.default.dirname(filePath));
    import_fs2.default.writeFileSync(filePath, data);
  }
  function copyFile(src, dest) {
    ensureDir(import_path2.default.dirname(dest));
    import_fs2.default.copyFileSync(src, dest);
  }
  function hashFile(filePath) {
    return Crypto.djb2(readFile(filePath));
  }
  function isModified(filePath1, filePath2) {
    return hashFile(filePath1) !== hashFile(filePath2);
  }

  // src/tomb/util.ts
  var fromK9A = (fullPath) => {
    if (/^data(\/|\\)/.test(fullPath))
      return fullPath.replace(/\.k9a$/, ".json");
    if (/^img(\/|\\)/.test(fullPath))
      return fullPath.replace(/\.k9a$/, ".png");
    if (/^audio(\/|\\)/.test(fullPath))
      return fullPath.replace(/\.k9a$/, ".ogg");
    return fullPath;
  };
  var toK9A = (fullPath) => fullPath.replace(/\.(png|ogg|json)$/, ".k9a");
  var gameVersion = () => GAME_VERSION != null ? GAME_VERSION : VERSION;

  // src/mods/tomb/plugins/lib/genProject.ts
  async function copyFolder(input, output) {
    console.time("copy");
    const files = fileList(input);
    for (const file of files) {
      const ext = import_path3.default.extname(file);
      if (ext === ".k9a") {
        const newPath = fromK9A(file);
        const dec = readFile(import_path3.default.join("www", file));
        writeFile(import_path3.default.join(output, newPath), dec);
      } else if (ext === ".loc") {
        const rawData = import_fs3.default.readFileSync(import_path3.default.join("www", file));
        const data = rawData.subarray(
          Buffer.byteLength(SIGNATURE, "utf8") + 4,
          rawData.length + 4
        );
        const dataStr = JSON.parse(new TextDecoder().decode(data));
        const dataFmt = JSON.stringify(dataStr, null, "	");
        writeFile(import_path3.default.join(output, file), dataFmt);
      } else {
        const dec = readFile(import_path3.default.join("www", file));
        writeFile(import_path3.default.join(output, file), dec);
      }
    }
    console.timeEnd("copy");
  }
  function generateRpgProject(output) {
    import_fs3.default.writeFileSync(import_path3.default.join(output, "Game.rpgproject"), "RPGMV 1.6.2");
  }
  function updatePackageJson(output) {
    const pkgPath = import_path3.default.join(output, "package.json");
    const rawPkg = import_fs3.default.readFileSync(pkgPath, "utf8");
    const pkg = JSON.parse(rawPkg);
    pkg.name = "tcoaal";
    const newPkg = JSON.stringify(pkg, null, "    ");
    import_fs3.default.writeFileSync(pkgPath, newPkg);
  }
  function patchIndexHtml(output) {
    const script = `
		<script>
			// Some patches provided by Tomb

			// Patch language loading to support loading base-game language files without the header
			const orig = window.onload;
			window.onload = () => {
				const readFile = Utils.readFile;
				Utils.readFile = (arg) => {
					if (Utils.ext(arg) === '.loc') {
						// We pad the response with empty data, which the game cuts off
						return ' '.repeat(Buffer.byteLength(SIGNATURE, 'utf8') + 4)
							+ readFile(arg);
					}

					return readFile(arg);
				};

				if (Crypto.resolveURL) Crypto.resolveURL = url => url;

				orig();
			}
		<\/script>
	`.trim();
    const indexPath = import_path3.default.join(output, "index.html");
    const index = import_fs3.default.readFileSync(indexPath, "utf8");
    import_fs3.default.writeFileSync(indexPath, index.replace("</body>", `${script}
</body>`));
  }
  async function genProject() {
    const input = "www";
    const output = "project";
    import_fs3.default.mkdirSync(output);
    await copyFolder(input, output);
    generateRpgProject(output);
    updatePackageJson(output);
    patchIndexHtml(output);
  }

  // src/mods/tomb/plugins/lib/genMod.ts
  var import_fs18 = __toESM(__require("fs"), 1);
  var import_path11 = __toESM(__require("path"), 1);

  // src/mods/tomb/plugins/lib/genMod/diffData.ts
  var import_fs6 = __toESM(__require("fs"), 1);
  var import_path5 = __toESM(__require("path"), 1);

  // node_modules/.pnpm/fast-json-patch@3.1.1/node_modules/fast-json-patch/module/core.mjs
  var core_exports = {};
  __export(core_exports, {
    JsonPatchError: () => JsonPatchError,
    _areEquals: () => _areEquals,
    applyOperation: () => applyOperation,
    applyPatch: () => applyPatch,
    applyReducer: () => applyReducer,
    deepClone: () => deepClone,
    getValueByPointer: () => getValueByPointer,
    validate: () => validate,
    validator: () => validator
  });

  // node_modules/.pnpm/fast-json-patch@3.1.1/node_modules/fast-json-patch/module/helpers.mjs
  var __extends = /* @__PURE__ */ function() {
    var extendStatics = function(d, b) {
      extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
        d2.__proto__ = b2;
      } || function(d2, b2) {
        for (var p in b2)
          if (b2.hasOwnProperty(p))
            d2[p] = b2[p];
      };
      return extendStatics(d, b);
    };
    return function(d, b) {
      extendStatics(d, b);
      function __() {
        this.constructor = d;
      }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
  }();
  var _hasOwnProperty = Object.prototype.hasOwnProperty;
  function hasOwnProperty(obj, key) {
    return _hasOwnProperty.call(obj, key);
  }
  function _objectKeys(obj) {
    if (Array.isArray(obj)) {
      var keys_1 = new Array(obj.length);
      for (var k = 0; k < keys_1.length; k++) {
        keys_1[k] = "" + k;
      }
      return keys_1;
    }
    if (Object.keys) {
      return Object.keys(obj);
    }
    var keys = [];
    for (var i in obj) {
      if (hasOwnProperty(obj, i)) {
        keys.push(i);
      }
    }
    return keys;
  }
  function _deepClone(obj) {
    switch (typeof obj) {
      case "object":
        return JSON.parse(JSON.stringify(obj));
      case "undefined":
        return null;
      default:
        return obj;
    }
  }
  function isInteger(str) {
    var i = 0;
    var len = str.length;
    var charCode;
    while (i < len) {
      charCode = str.charCodeAt(i);
      if (charCode >= 48 && charCode <= 57) {
        i++;
        continue;
      }
      return false;
    }
    return true;
  }
  function escapePathComponent(path13) {
    if (path13.indexOf("/") === -1 && path13.indexOf("~") === -1)
      return path13;
    return path13.replace(/~/g, "~0").replace(/\//g, "~1");
  }
  function unescapePathComponent(path13) {
    return path13.replace(/~1/g, "/").replace(/~0/g, "~");
  }
  function hasUndefined(obj) {
    if (obj === void 0) {
      return true;
    }
    if (obj) {
      if (Array.isArray(obj)) {
        for (var i_1 = 0, len = obj.length; i_1 < len; i_1++) {
          if (hasUndefined(obj[i_1])) {
            return true;
          }
        }
      } else if (typeof obj === "object") {
        var objKeys = _objectKeys(obj);
        var objKeysLength = objKeys.length;
        for (var i = 0; i < objKeysLength; i++) {
          if (hasUndefined(obj[objKeys[i]])) {
            return true;
          }
        }
      }
    }
    return false;
  }
  function patchErrorMessageFormatter(message, args) {
    var messageParts = [message];
    for (var key in args) {
      var value = typeof args[key] === "object" ? JSON.stringify(args[key], null, 2) : args[key];
      if (typeof value !== "undefined") {
        messageParts.push(key + ": " + value);
      }
    }
    return messageParts.join("\n");
  }
  var PatchError = (
    /** @class */
    function(_super) {
      __extends(PatchError2, _super);
      function PatchError2(message, name, index, operation, tree) {
        var _newTarget = this.constructor;
        var _this = _super.call(this, patchErrorMessageFormatter(message, { name, index, operation, tree })) || this;
        _this.name = name;
        _this.index = index;
        _this.operation = operation;
        _this.tree = tree;
        Object.setPrototypeOf(_this, _newTarget.prototype);
        _this.message = patchErrorMessageFormatter(message, { name, index, operation, tree });
        return _this;
      }
      return PatchError2;
    }(Error)
  );

  // node_modules/.pnpm/fast-json-patch@3.1.1/node_modules/fast-json-patch/module/core.mjs
  var JsonPatchError = PatchError;
  var deepClone = _deepClone;
  var objOps = {
    add: function(obj, key, document2) {
      obj[key] = this.value;
      return { newDocument: document2 };
    },
    remove: function(obj, key, document2) {
      var removed = obj[key];
      delete obj[key];
      return { newDocument: document2, removed };
    },
    replace: function(obj, key, document2) {
      var removed = obj[key];
      obj[key] = this.value;
      return { newDocument: document2, removed };
    },
    move: function(obj, key, document2) {
      var removed = getValueByPointer(document2, this.path);
      if (removed) {
        removed = _deepClone(removed);
      }
      var originalValue = applyOperation(document2, { op: "remove", path: this.from }).removed;
      applyOperation(document2, { op: "add", path: this.path, value: originalValue });
      return { newDocument: document2, removed };
    },
    copy: function(obj, key, document2) {
      var valueToCopy = getValueByPointer(document2, this.from);
      applyOperation(document2, { op: "add", path: this.path, value: _deepClone(valueToCopy) });
      return { newDocument: document2 };
    },
    test: function(obj, key, document2) {
      return { newDocument: document2, test: _areEquals(obj[key], this.value) };
    },
    _get: function(obj, key, document2) {
      this.value = obj[key];
      return { newDocument: document2 };
    }
  };
  var arrOps = {
    add: function(arr, i, document2) {
      if (isInteger(i)) {
        arr.splice(i, 0, this.value);
      } else {
        arr[i] = this.value;
      }
      return { newDocument: document2, index: i };
    },
    remove: function(arr, i, document2) {
      var removedList = arr.splice(i, 1);
      return { newDocument: document2, removed: removedList[0] };
    },
    replace: function(arr, i, document2) {
      var removed = arr[i];
      arr[i] = this.value;
      return { newDocument: document2, removed };
    },
    move: objOps.move,
    copy: objOps.copy,
    test: objOps.test,
    _get: objOps._get
  };
  function getValueByPointer(document2, pointer) {
    if (pointer == "") {
      return document2;
    }
    var getOriginalDestination = { op: "_get", path: pointer };
    applyOperation(document2, getOriginalDestination);
    return getOriginalDestination.value;
  }
  function applyOperation(document2, operation, validateOperation, mutateDocument, banPrototypeModifications, index) {
    if (validateOperation === void 0) {
      validateOperation = false;
    }
    if (mutateDocument === void 0) {
      mutateDocument = true;
    }
    if (banPrototypeModifications === void 0) {
      banPrototypeModifications = true;
    }
    if (index === void 0) {
      index = 0;
    }
    if (validateOperation) {
      if (typeof validateOperation == "function") {
        validateOperation(operation, 0, document2, operation.path);
      } else {
        validator(operation, 0);
      }
    }
    if (operation.path === "") {
      var returnValue = { newDocument: document2 };
      if (operation.op === "add") {
        returnValue.newDocument = operation.value;
        return returnValue;
      } else if (operation.op === "replace") {
        returnValue.newDocument = operation.value;
        returnValue.removed = document2;
        return returnValue;
      } else if (operation.op === "move" || operation.op === "copy") {
        returnValue.newDocument = getValueByPointer(document2, operation.from);
        if (operation.op === "move") {
          returnValue.removed = document2;
        }
        return returnValue;
      } else if (operation.op === "test") {
        returnValue.test = _areEquals(document2, operation.value);
        if (returnValue.test === false) {
          throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document2);
        }
        returnValue.newDocument = document2;
        return returnValue;
      } else if (operation.op === "remove") {
        returnValue.removed = document2;
        returnValue.newDocument = null;
        return returnValue;
      } else if (operation.op === "_get") {
        operation.value = document2;
        return returnValue;
      } else {
        if (validateOperation) {
          throw new JsonPatchError("Operation `op` property is not one of operations defined in RFC-6902", "OPERATION_OP_INVALID", index, operation, document2);
        } else {
          return returnValue;
        }
      }
    } else {
      if (!mutateDocument) {
        document2 = _deepClone(document2);
      }
      var path13 = operation.path || "";
      var keys = path13.split("/");
      var obj = document2;
      var t = 1;
      var len = keys.length;
      var existingPathFragment = void 0;
      var key = void 0;
      var validateFunction = void 0;
      if (typeof validateOperation == "function") {
        validateFunction = validateOperation;
      } else {
        validateFunction = validator;
      }
      while (true) {
        key = keys[t];
        if (key && key.indexOf("~") != -1) {
          key = unescapePathComponent(key);
        }
        if (banPrototypeModifications && (key == "__proto__" || key == "prototype" && t > 0 && keys[t - 1] == "constructor")) {
          throw new TypeError("JSON-Patch: modifying `__proto__` or `constructor/prototype` prop is banned for security reasons, if this was on purpose, please set `banPrototypeModifications` flag false and pass it to this function. More info in fast-json-patch README");
        }
        if (validateOperation) {
          if (existingPathFragment === void 0) {
            if (obj[key] === void 0) {
              existingPathFragment = keys.slice(0, t).join("/");
            } else if (t == len - 1) {
              existingPathFragment = operation.path;
            }
            if (existingPathFragment !== void 0) {
              validateFunction(operation, 0, document2, existingPathFragment);
            }
          }
        }
        t++;
        if (Array.isArray(obj)) {
          if (key === "-") {
            key = obj.length;
          } else {
            if (validateOperation && !isInteger(key)) {
              throw new JsonPatchError("Expected an unsigned base-10 integer value, making the new referenced value the array element with the zero-based index", "OPERATION_PATH_ILLEGAL_ARRAY_INDEX", index, operation, document2);
            } else if (isInteger(key)) {
              key = ~~key;
            }
          }
          if (t >= len) {
            if (validateOperation && operation.op === "add" && key > obj.length) {
              throw new JsonPatchError("The specified index MUST NOT be greater than the number of elements in the array", "OPERATION_VALUE_OUT_OF_BOUNDS", index, operation, document2);
            }
            var returnValue = arrOps[operation.op].call(operation, obj, key, document2);
            if (returnValue.test === false) {
              throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document2);
            }
            return returnValue;
          }
        } else {
          if (t >= len) {
            var returnValue = objOps[operation.op].call(operation, obj, key, document2);
            if (returnValue.test === false) {
              throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document2);
            }
            return returnValue;
          }
        }
        obj = obj[key];
        if (validateOperation && t < len && (!obj || typeof obj !== "object")) {
          throw new JsonPatchError("Cannot perform operation at the desired path", "OPERATION_PATH_UNRESOLVABLE", index, operation, document2);
        }
      }
    }
  }
  function applyPatch(document2, patch, validateOperation, mutateDocument, banPrototypeModifications) {
    if (mutateDocument === void 0) {
      mutateDocument = true;
    }
    if (banPrototypeModifications === void 0) {
      banPrototypeModifications = true;
    }
    if (validateOperation) {
      if (!Array.isArray(patch)) {
        throw new JsonPatchError("Patch sequence must be an array", "SEQUENCE_NOT_AN_ARRAY");
      }
    }
    if (!mutateDocument) {
      document2 = _deepClone(document2);
    }
    var results = new Array(patch.length);
    for (var i = 0, length_1 = patch.length; i < length_1; i++) {
      results[i] = applyOperation(document2, patch[i], validateOperation, true, banPrototypeModifications, i);
      document2 = results[i].newDocument;
    }
    results.newDocument = document2;
    return results;
  }
  function applyReducer(document2, operation, index) {
    var operationResult = applyOperation(document2, operation);
    if (operationResult.test === false) {
      throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document2);
    }
    return operationResult.newDocument;
  }
  function validator(operation, index, document2, existingPathFragment) {
    if (typeof operation !== "object" || operation === null || Array.isArray(operation)) {
      throw new JsonPatchError("Operation is not an object", "OPERATION_NOT_AN_OBJECT", index, operation, document2);
    } else if (!objOps[operation.op]) {
      throw new JsonPatchError("Operation `op` property is not one of operations defined in RFC-6902", "OPERATION_OP_INVALID", index, operation, document2);
    } else if (typeof operation.path !== "string") {
      throw new JsonPatchError("Operation `path` property is not a string", "OPERATION_PATH_INVALID", index, operation, document2);
    } else if (operation.path.indexOf("/") !== 0 && operation.path.length > 0) {
      throw new JsonPatchError('Operation `path` property must start with "/"', "OPERATION_PATH_INVALID", index, operation, document2);
    } else if ((operation.op === "move" || operation.op === "copy") && typeof operation.from !== "string") {
      throw new JsonPatchError("Operation `from` property is not present (applicable in `move` and `copy` operations)", "OPERATION_FROM_REQUIRED", index, operation, document2);
    } else if ((operation.op === "add" || operation.op === "replace" || operation.op === "test") && operation.value === void 0) {
      throw new JsonPatchError("Operation `value` property is not present (applicable in `add`, `replace` and `test` operations)", "OPERATION_VALUE_REQUIRED", index, operation, document2);
    } else if ((operation.op === "add" || operation.op === "replace" || operation.op === "test") && hasUndefined(operation.value)) {
      throw new JsonPatchError("Operation `value` property is not present (applicable in `add`, `replace` and `test` operations)", "OPERATION_VALUE_CANNOT_CONTAIN_UNDEFINED", index, operation, document2);
    } else if (document2) {
      if (operation.op == "add") {
        var pathLen = operation.path.split("/").length;
        var existingPathLen = existingPathFragment.split("/").length;
        if (pathLen !== existingPathLen + 1 && pathLen !== existingPathLen) {
          throw new JsonPatchError("Cannot perform an `add` operation at the desired path", "OPERATION_PATH_CANNOT_ADD", index, operation, document2);
        }
      } else if (operation.op === "replace" || operation.op === "remove" || operation.op === "_get") {
        if (operation.path !== existingPathFragment) {
          throw new JsonPatchError("Cannot perform the operation at a path that does not exist", "OPERATION_PATH_UNRESOLVABLE", index, operation, document2);
        }
      } else if (operation.op === "move" || operation.op === "copy") {
        var existingValue = { op: "_get", path: operation.from, value: void 0 };
        var error = validate([existingValue], document2);
        if (error && error.name === "OPERATION_PATH_UNRESOLVABLE") {
          throw new JsonPatchError("Cannot perform the operation from a path that does not exist", "OPERATION_FROM_UNRESOLVABLE", index, operation, document2);
        }
      }
    }
  }
  function validate(sequence, document2, externalValidator) {
    try {
      if (!Array.isArray(sequence)) {
        throw new JsonPatchError("Patch sequence must be an array", "SEQUENCE_NOT_AN_ARRAY");
      }
      if (document2) {
        applyPatch(_deepClone(document2), _deepClone(sequence), externalValidator || true);
      } else {
        externalValidator = externalValidator || validator;
        for (var i = 0; i < sequence.length; i++) {
          externalValidator(sequence[i], i, document2, void 0);
        }
      }
    } catch (e) {
      if (e instanceof JsonPatchError) {
        return e;
      } else {
        throw e;
      }
    }
  }
  function _areEquals(a, b) {
    if (a === b)
      return true;
    if (a && b && typeof a == "object" && typeof b == "object") {
      var arrA = Array.isArray(a), arrB = Array.isArray(b), i, length, key;
      if (arrA && arrB) {
        length = a.length;
        if (length != b.length)
          return false;
        for (i = length; i-- !== 0; )
          if (!_areEquals(a[i], b[i]))
            return false;
        return true;
      }
      if (arrA != arrB)
        return false;
      var keys = Object.keys(a);
      length = keys.length;
      if (length !== Object.keys(b).length)
        return false;
      for (i = length; i-- !== 0; )
        if (!b.hasOwnProperty(keys[i]))
          return false;
      for (i = length; i-- !== 0; ) {
        key = keys[i];
        if (!_areEquals(a[key], b[key]))
          return false;
      }
      return true;
    }
    return a !== a && b !== b;
  }

  // node_modules/.pnpm/fast-json-patch@3.1.1/node_modules/fast-json-patch/module/duplex.mjs
  var duplex_exports = {};
  __export(duplex_exports, {
    compare: () => compare,
    generate: () => generate,
    observe: () => observe,
    unobserve: () => unobserve
  });
  var beforeDict = /* @__PURE__ */ new WeakMap();
  var Mirror = (
    /** @class */
    /* @__PURE__ */ function() {
      function Mirror2(obj) {
        this.observers = /* @__PURE__ */ new Map();
        this.obj = obj;
      }
      return Mirror2;
    }()
  );
  var ObserverInfo = (
    /** @class */
    /* @__PURE__ */ function() {
      function ObserverInfo2(callback, observer) {
        this.callback = callback;
        this.observer = observer;
      }
      return ObserverInfo2;
    }()
  );
  function getMirror(obj) {
    return beforeDict.get(obj);
  }
  function getObserverFromMirror(mirror, callback) {
    return mirror.observers.get(callback);
  }
  function removeObserverFromMirror(mirror, observer) {
    mirror.observers.delete(observer.callback);
  }
  function unobserve(root, observer) {
    observer.unobserve();
  }
  function observe(obj, callback) {
    var patches = [];
    var observer;
    var mirror = getMirror(obj);
    if (!mirror) {
      mirror = new Mirror(obj);
      beforeDict.set(obj, mirror);
    } else {
      var observerInfo = getObserverFromMirror(mirror, callback);
      observer = observerInfo && observerInfo.observer;
    }
    if (observer) {
      return observer;
    }
    observer = {};
    mirror.value = _deepClone(obj);
    if (callback) {
      observer.callback = callback;
      observer.next = null;
      var dirtyCheck = function() {
        generate(observer);
      };
      var fastCheck = function() {
        clearTimeout(observer.next);
        observer.next = setTimeout(dirtyCheck);
      };
      if (typeof window !== "undefined") {
        window.addEventListener("mouseup", fastCheck);
        window.addEventListener("keyup", fastCheck);
        window.addEventListener("mousedown", fastCheck);
        window.addEventListener("keydown", fastCheck);
        window.addEventListener("change", fastCheck);
      }
    }
    observer.patches = patches;
    observer.object = obj;
    observer.unobserve = function() {
      generate(observer);
      clearTimeout(observer.next);
      removeObserverFromMirror(mirror, observer);
      if (typeof window !== "undefined") {
        window.removeEventListener("mouseup", fastCheck);
        window.removeEventListener("keyup", fastCheck);
        window.removeEventListener("mousedown", fastCheck);
        window.removeEventListener("keydown", fastCheck);
        window.removeEventListener("change", fastCheck);
      }
    };
    mirror.observers.set(callback, new ObserverInfo(callback, observer));
    return observer;
  }
  function generate(observer, invertible) {
    if (invertible === void 0) {
      invertible = false;
    }
    var mirror = beforeDict.get(observer.object);
    _generate(mirror.value, observer.object, observer.patches, "", invertible);
    if (observer.patches.length) {
      applyPatch(mirror.value, observer.patches);
    }
    var temp = observer.patches;
    if (temp.length > 0) {
      observer.patches = [];
      if (observer.callback) {
        observer.callback(temp);
      }
    }
    return temp;
  }
  function _generate(mirror, obj, patches, path13, invertible) {
    if (obj === mirror) {
      return;
    }
    if (typeof obj.toJSON === "function") {
      obj = obj.toJSON();
    }
    var newKeys = _objectKeys(obj);
    var oldKeys = _objectKeys(mirror);
    var changed = false;
    var deleted = false;
    for (var t = oldKeys.length - 1; t >= 0; t--) {
      var key = oldKeys[t];
      var oldVal = mirror[key];
      if (hasOwnProperty(obj, key) && !(obj[key] === void 0 && oldVal !== void 0 && Array.isArray(obj) === false)) {
        var newVal = obj[key];
        if (typeof oldVal == "object" && oldVal != null && typeof newVal == "object" && newVal != null && Array.isArray(oldVal) === Array.isArray(newVal)) {
          _generate(oldVal, newVal, patches, path13 + "/" + escapePathComponent(key), invertible);
        } else {
          if (oldVal !== newVal) {
            changed = true;
            if (invertible) {
              patches.push({ op: "test", path: path13 + "/" + escapePathComponent(key), value: _deepClone(oldVal) });
            }
            patches.push({ op: "replace", path: path13 + "/" + escapePathComponent(key), value: _deepClone(newVal) });
          }
        }
      } else if (Array.isArray(mirror) === Array.isArray(obj)) {
        if (invertible) {
          patches.push({ op: "test", path: path13 + "/" + escapePathComponent(key), value: _deepClone(oldVal) });
        }
        patches.push({ op: "remove", path: path13 + "/" + escapePathComponent(key) });
        deleted = true;
      } else {
        if (invertible) {
          patches.push({ op: "test", path: path13, value: mirror });
        }
        patches.push({ op: "replace", path: path13, value: obj });
        changed = true;
      }
    }
    if (!deleted && newKeys.length == oldKeys.length) {
      return;
    }
    for (var t = 0; t < newKeys.length; t++) {
      var key = newKeys[t];
      if (!hasOwnProperty(mirror, key) && obj[key] !== void 0) {
        patches.push({ op: "add", path: path13 + "/" + escapePathComponent(key), value: _deepClone(obj[key]) });
      }
    }
  }
  function compare(tree1, tree2, invertible) {
    if (invertible === void 0) {
      invertible = false;
    }
    var patches = [];
    _generate(tree1, tree2, patches, "", invertible);
    return patches;
  }

  // node_modules/.pnpm/fast-json-patch@3.1.1/node_modules/fast-json-patch/index.mjs
  var fast_json_patch_default = Object.assign({}, core_exports, duplex_exports, {
    JsonPatchError: PatchError,
    deepClone: _deepClone,
    escapePathComponent,
    unescapePathComponent
  });

  // src/mods/tomb/plugins/lib/util/winToPosix.ts
  var import_path4 = __toESM(__require("path"), 1);
  var winToPosix = (winPath) => winPath.split(import_path4.default.sep).join(import_path4.default.posix.sep);
  var winToPosix_default = winToPosix;

  // src/mods/tomb/plugins/lib/util/k9a.ts
  var import_fs5 = __toESM(__require("fs"), 1);
  var k9a = (wwwPath) => {
    const k9aPath = toK9A(wwwPath);
    if (import_fs5.default.existsSync(k9aPath))
      return k9aPath;
    return wwwPath;
  };

  // src/mods/tomb/plugins/lib/genMod/diffData.ts
  function diffData(json, modPath) {
    const dataFiles = fileList("project/data");
    for (const _filePath of dataFiles) {
      const filePath = import_path5.default.join("data", _filePath);
      if (!filePath.endsWith(".json"))
        continue;
      const origPath = k9a(import_path5.default.join("www", filePath));
      const newPath = import_path5.default.join("project", filePath);
      if (!import_fs6.default.existsSync(origPath)) {
        copyFile(newPath, import_path5.default.join(modPath, filePath));
        json.files.assets.push(winToPosix_default(filePath));
      } else if (isModified(newPath, origPath)) {
        const decoder = new TextDecoder();
        const origFile = JSON.parse(decoder.decode(readFile(origPath)));
        const newFile = JSON.parse(decoder.decode(readFile(newPath)));
        const patch = compare(origFile, newFile);
        if (patch.length === 0)
          continue;
        const newRelativePath = filePath + "d";
        json.files.dataDeltas.push(winToPosix_default(newRelativePath));
        writeFile(
          import_path5.default.join(modPath, newRelativePath),
          JSON.stringify(patch, null, "	")
        );
      }
    }
    return json;
  }

  // src/mods/tomb/plugins/lib/genMod/diffLanguages.ts
  var import_path6 = __toESM(__require("path"), 1);
  var import_fs8 = __toESM(__require("fs"), 1);
  function parseLanguageFile(pathToFile) {
    pathToFile = winToPosix_default(pathToFile);
    switch (import_path6.default.extname(pathToFile).toLowerCase()) {
      case ".loc": {
        const data = import_fs8.default.readFileSync(pathToFile);
        const signatureLength = Buffer.byteLength(SIGNATURE, "utf8");
        const signature = data.slice(0, signatureLength).toString("utf8");
        const hasSignature = signature === SIGNATURE;
        const segment = hasSignature ? data.slice(signatureLength + 4) : data;
        const lang = JSON.parse(segment.toString("utf8"));
        return lang;
      }
      case ".txt":
        return $tomb.lib.lang.loadTXT(pathToFile);
      case ".csv":
        return $tomb.lib.lang.loadCSV(pathToFile);
      default:
        throw new Error("Failed to match language file extension to parser");
    }
  }
  function diffLanguages(json, modPath) {
    const sections = [
      "sysLabel",
      "sysMenus",
      "labelLUT",
      "linesLUT"
    ];
    const langDir = import_path6.default.join(App.rootPath(), LANG_DIR);
    const langFolders = Utils.folders(langDir);
    for (let i = 0; i < langFolders.length; i++) {
      const folder = import_path6.default.join(langDir, langFolders[i]);
      const files = Utils.files(folder);
      for (const file of files) {
        const ext = import_path6.default.extname(file).toLowerCase();
        if (!VALID_EXT.includes(ext))
          continue;
        const filePath = import_path6.default.join(LANG_DIR, langFolders[i], file);
        const origPath = k9a(import_path6.default.join("www", filePath));
        const newPath = import_path6.default.join("project", filePath);
        if (!import_fs8.default.existsSync(origPath))
          throw new Error(
            `Language file ${filePath} does not exist in www/, so we cannot generate a patched version`
          );
        if (isModified(origPath, newPath)) {
          const origLangData = parseLanguageFile(origPath);
          const newLangData = parseLanguageFile(newPath);
          const diff = {};
          for (const section of sections) {
            for (const key in newLangData[section]) {
              if (JSON.stringify(origLangData[section][key]) !== JSON.stringify(newLangData[section][key])) {
                if (!diff[section])
                  diff[section] = {};
                diff[section][key] = newLangData[section][key];
              }
            }
          }
          if (Object.keys(diff).length > 0) {
            const outputFile = import_path6.default.join(LANG_DIR, `${langFolders[i]}.json`);
            json.files.languages.push(winToPosix_default(outputFile));
            writeFile(
              import_path6.default.join(modPath, outputFile),
              JSON.stringify(diff, null, "	")
            );
          }
        }
      }
    }
    return json;
  }

  // src/mods/tomb/plugins/lib/genMod/diffImages.ts
  var import_path7 = __toESM(__require("path"), 1);
  var import_fs10 = __toESM(__require("fs"), 1);

  // node_modules/.pnpm/olid.ts@git+https+++codeberg.org+basil+OLID.ts.git#ca092d7f5dcc0b1db59e84e85e650c61a58c93b4_pzpyof43zttzesvjfn2oievxfe/node_modules/olid.ts/src/lib/lib.ts
  var import_zlib = __toESM(__require("zlib"), 1);
  var TILE_SIZE = 16;
  var PIXELS = TILE_SIZE * TILE_SIZE;
  var MASK_SIZE = 32;
  function computeDiff(sourceImg, targetImg) {
    const sourceCanvas = document.createElement("canvas");
    const targetCanvas = document.createElement("canvas");
    sourceCanvas.width = sourceImg.width;
    sourceCanvas.height = sourceImg.height;
    targetCanvas.width = targetImg.width;
    targetCanvas.height = targetImg.height;
    const source = sourceCanvas.getContext("2d", {
      willReadFrequently: true
    });
    const target = targetCanvas.getContext("2d", {
      willReadFrequently: true
    });
    source.drawImage(sourceImg, 0, 0);
    target.drawImage(targetImg, 0, 0);
    const segments = [];
    for (let x = 0; x < Math.ceil(targetImg.width / TILE_SIZE); x++) {
      for (let y = 0; y < Math.ceil(targetImg.height / TILE_SIZE); y++) {
        let sourceBitmap;
        if (sourceImg.width < x * TILE_SIZE || sourceImg.height < y * TILE_SIZE) {
          sourceBitmap = new ArrayBuffer(TILE_SIZE * TILE_SIZE * 4);
        } else {
          sourceBitmap = source.getImageData(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE).data.buffer;
        }
        const targetBitmap = target.getImageData(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE).data.buffer;
        const diff = computeDiffTile(new Uint32Array(sourceBitmap), new Uint32Array(targetBitmap));
        if (diff.byteLength > Math.floor(TILE_SIZE * TILE_SIZE / 8)) {
          const targetData = new ArrayBuffer(8 + diff.byteLength);
          const view = new DataView(targetData);
          view.setUint16(0, x);
          view.setUint16(2, y);
          view.setUint32(4, diff.byteLength);
          const targetArr = new Uint8Array(targetData);
          targetArr.set(diff, 8);
          segments.push(targetArr);
        }
      }
    }
    const totalLen = segments.reduce((a, b) => a + b.byteLength, 0);
    const uncompressed = new Uint8Array(new ArrayBuffer(totalLen));
    let ptr = 0;
    for (let block of segments) {
      uncompressed.set(block, ptr);
      ptr += block.byteLength;
    }
    const compressed = import_zlib.default.deflateSync(Buffer.from(uncompressed));
    const randomBytes = new ArrayBuffer(8);
    const randomBytesDV = new DataView(randomBytes);
    for (let i = 0; i < 8; i++) {
      randomBytesDV.setUint8(i, Math.floor(Math.random() * 256));
    }
    const output = new ArrayBuffer(6 + 4 + 4 + 8 + 4 + compressed.byteLength);
    const outputDv = new DataView(output);
    const outputBuf = new Uint8Array(output);
    outputDv.setUint32(0, 4278179848);
    outputDv.setUint16(4, 56609);
    outputDv.setUint32(6, targetImg.width);
    outputDv.setUint32(10, targetImg.height);
    outputBuf.set(new Uint8Array(randomBytes), 14);
    outputDv.setUint32(22, compressed.byteLength);
    outputBuf.set(compressed, 26);
    return output;
  }
  function computeDiffTile(source, target) {
    if (source.length !== PIXELS || target.length !== PIXELS)
      throw new Error("Source and target must be 1024 bytes long");
    const bitmap = new Uint8Array(MASK_SIZE);
    const values = [];
    for (let i = 0; i < PIXELS; i++) {
      if (source[i] !== target[i]) {
        values.push(target[i]);
        bitmap[Math.floor(i / 8)] = bitmap[Math.floor(i / 8)] + (1 << i % 8);
      }
    }
    const output = Array.from(bitmap.slice());
    for (const value of values) {
      output.push(value >> 24 & 255);
      output.push(value >> 16 & 255);
      output.push(value >> 8 & 255);
      output.push(value & 255);
    }
    return new Uint32Array(output);
  }

  // src/mods/tomb/plugins/lib/genMod/diffImages.ts
  async function diffImages(json, modPath) {
    const folders = [
      "animations",
      "battlebacks1",
      "battlebacks2",
      "characters",
      "enemies",
      "faces",
      "parallaxes",
      "pictures",
      "sv_actors",
      "sv_enemies",
      "system",
      "tilesets",
      "titles1",
      "titles2"
    ];
    for (const folder of folders) {
      if (!import_fs10.default.existsSync(import_path7.default.join("project/img", folder)))
        continue;
      const images = fileList(import_path7.default.join("project/img", folder));
      for (const filePath of images) {
        if (!filePath.endsWith(".png"))
          continue;
        const relativePath = import_path7.default.join("img", folder, filePath);
        const origPath = k9a(import_path7.default.join("www", relativePath));
        const newPath = import_path7.default.join("project", relativePath);
        if (!import_fs10.default.existsSync(origPath)) {
          copyFile(newPath, import_path7.default.join(modPath, relativePath));
          json.files.assets.push(winToPosix_default(relativePath));
        } else if (isModified(origPath, newPath)) {
          const origFile = readFile(origPath);
          const newFile = readFile(newPath);
          const origImg = await createImageBitmap(new Blob([origFile]));
          const newImg = await createImageBitmap(new Blob([newFile]));
          const diff = computeDiff(origImg, newImg);
          const newRelativePath = import_path7.default.join("img", folder, `${filePath}.olid`);
          json.files.imageDeltas.push(winToPosix_default(newRelativePath));
          writeFile(import_path7.default.join(modPath, newRelativePath), new Uint8Array(diff));
        }
      }
    }
    return json;
  }

  // src/mods/tomb/plugins/lib/genMod/diffAudio.ts
  var import_path8 = __toESM(__require("path"), 1);
  var import_fs12 = __toESM(__require("fs"), 1);
  function diffAudio(json, modPath) {
    const folders = ["bgm", "bgs", "me", "se"];
    for (const folder of folders) {
      if (!import_fs12.default.existsSync(import_path8.default.join("project/audio", folder)))
        continue;
      const images = fileList(import_path8.default.join("project/audio", folder));
      for (const filePath of images) {
        if (!filePath.endsWith(".ogg"))
          continue;
        const relativePath = import_path8.default.join("audio", folder, filePath);
        const origPath = k9a(import_path8.default.join("www", relativePath));
        const newPath = import_path8.default.join("project", relativePath);
        if (!import_fs12.default.existsSync(origPath) || isModified(origPath, newPath)) {
          copyFile(newPath, import_path8.default.join(modPath, relativePath));
          json.files.assets.push(winToPosix_default(relativePath));
        }
      }
    }
    return json;
  }

  // src/mods/tomb/plugins/lib/genMod/diffVideos.ts
  var import_path9 = __toESM(__require("path"), 1);
  var import_fs14 = __toESM(__require("fs"), 1);
  function diffVideos(json, modPath) {
    if (!(0, import_fs14.existsSync)(import_path9.default.join("project", "movies")))
      return json;
    const videos = fileList(import_path9.default.join("project", "movies"));
    for (const filePath of videos) {
      if (!filePath.endsWith(".webm"))
        continue;
      const relativePath = import_path9.default.join("movies", filePath);
      const origPath = k9a(import_path9.default.join("www", relativePath));
      const newPath = import_path9.default.join("project", relativePath);
      if (!import_fs14.default.existsSync(origPath) || isModified(origPath, newPath)) {
        copyFile(newPath, import_path9.default.join(modPath, relativePath));
        json.files.assets.push(winToPosix_default(relativePath));
      }
    }
    return json;
  }

  // src/mods/tomb/plugins/lib/genMod/diffPlugins.ts
  var import_path10 = __toESM(__require("path"), 1);
  var import_fs16 = __toESM(__require("fs"), 1);
  function loadPlugin(path13) {
    const data = import_fs16.default.readFileSync(path13, "utf8");
    const plugins = new Function(`${data}
; return $plugins;`)();
    return plugins;
  }
  function diffPlugins(json, modPath) {
    const oldPlugins = loadPlugin("www/js/plugins.js");
    const newPlugins = loadPlugin("project/js/plugins.js");
    for (const plugin of newPlugins) {
      if (plugin.status === false)
        continue;
      if (oldPlugins.some((oldPlugin) => plugin.name === oldPlugin.name))
        continue;
      const file = `${plugin.name}.js`;
      copyFile(import_path10.default.join("project", "js", "plugins", file), import_path10.default.join(modPath, "js", "plugins", file));
      json.files.plugins.push(`js/plugins/${file}`);
    }
    return json;
  }

  // src/mods/tomb/plugins/lib/genMod.ts
  async function genMod(modId) {
    const modPath = import_path11.default.join("tomb/mods/", modId);
    let json = {
      id: modId,
      name: modId,
      authors: ["Your Name"],
      description: "Enter a description here!",
      version: "1.0.0",
      dependencies: {
        game: gameVersion(),
        spec: "0.1.0"
      },
      files: {
        assets: [],
        dataDeltas: [],
        imageDeltas: [],
        plugins: [],
        languages: []
      }
    };
    if (import_fs18.default.existsSync(modPath))
      throw new Error(`Folder already exists at tomb/mods/${modId}`);
    import_fs18.default.mkdirSync(modPath);
    json = diffData(json, modPath);
    json = diffLanguages(json, modPath);
    json = await diffImages(json, modPath);
    json = diffAudio(json, modPath);
    json = diffVideos(json, modPath);
    json = diffPlugins(json, modPath);
    for (const _key in json.files) {
      const key = _key;
      if (Object.keys(json.files[key]).length === 0)
        delete json.files[key];
    }
    writeFile(import_path11.default.join(modPath, "mod.json"), JSON.stringify(json, null, "	"));
  }

  // src/mods/tomb/plugins/menu.ts
  {
    const lines = [
      `${$tomb.mods.length} mod${$tomb.mods.length === 1 ? "" : "s"} loaded`,
      "Tomb v0.6.0-beta.5",
      `The Coffin of Andy and Leyley v${gameVersion()}`
    ].reverse();
    $tomb.lib.spitroast.after("create", Scene_Title.prototype, function() {
      this._tomb_messages = [];
      lines.forEach((line, i) => {
        const text = new Sprite(new Bitmap(Graphics.width, Graphics.height));
        this._tomb_messages.push(text);
        this.addChild(text);
        const fontSize = 16;
        text.bitmap.outlineColor = "black";
        text.bitmap.outlineWidth = 2;
        text.bitmap.fontSize = fontSize;
        const padding = 4;
        const x = 4;
        const y = Graphics.height - (fontSize + padding) * (i + 1);
        const maxWidth = Graphics.width - x * 2;
        text.bitmap.drawText(line, x, y, maxWidth, fontSize, "left");
      });
    });
    const optionText = "Tomb";
    const optionIcon = "wrench";
    MenuOptions.orderAndIcons[optionText] = optionIcon;
    class Window_Tomb extends Window_Command {
      constructor() {
        super();
      }
      initialize() {
        Window_Command.prototype.initialize.call(this, 0, 0);
        this.x = (Graphics.boxWidth - this.width) / 2;
        this.y = (Graphics.boxHeight - this.height) / 2;
      }
      makeCommandList() {
        const showGenProject = !import_fs20.default.existsSync("project");
        this.addCommand(
          "Generate RPG Maker MV Project",
          "genProject",
          showGenProject
        );
        this.addCommand("Bundle", "bundle", !showGenProject);
      }
      windowWidth() {
        return 400;
      }
      numVisibleRows() {
        return 5;
      }
      update() {
        Window_Command.prototype.update.call(this);
        if (Input.isTriggered("cancel")) {
          SceneManager.pop();
          SoundManager.playCancel();
        }
      }
      refresh() {
        Window_Selectable.prototype.refresh.call(this);
      }
      processOk() {
        const index = this.index();
        const id = this.commandSymbol(index);
        const enabled = this.isCommandEnabled(index);
        switch (id) {
          case "genProject":
            if (!enabled)
              return alert(
                `There's already a folder called "project" in the game directory.`
              );
            this._list[index].enabled = false;
            this.refresh();
            genProject().then(() => {
              const bundleIndex = this._list.findIndex(
                (item) => item.symbol === "bundle"
              );
              this._list[index].enabled = false;
              this._list[bundleIndex].enabled = true;
              nw.Shell.showItemInFolder(
                import_path12.default.join(nw.__dirname, "project", "Game.rpgproject")
              );
            }).catch((e) => {
              this._list[index].enabled = true;
              console.error(e);
              alert("An error ocurred :(");
            }).finally(() => {
              this.refresh();
            });
            break;
          case "bundle": {
            if (!enabled)
              return alert("Already running bundle.");
            this._list[index].enabled = false;
            this.refresh();
            const modId = prompt("Mod ID");
            genMod(modId).then(() => {
              nw.Shell.showItemInFolder(
                import_path12.default.join(nw.__dirname, "tomb/mods", modId)
              );
            }).catch((e) => {
              console.error(e);
              alert("An error ocurred :(");
            }).finally(() => {
              this._list[index].enabled = true;
              this.refresh();
            });
          }
        }
      }
    }
    class Scene_Tomb extends Scene_MenuBase {
      constructor() {
        super();
      }
      create() {
        Scene_MenuBase.prototype.create.call(this);
        this.setBackgroundOpacity(128);
        this.addWindow(new Window_Tomb());
      }
    }
    $tomb.lib.spitroast.after(
      "makeCommandList",
      Window_TitleCommand.prototype,
      function() {
        const fnThis = this;
        fnThis.addCommand(optionText, optionIcon);
        const optionsIndex = fnThis._list.findIndex(
          (option) => option.symbol === "options"
        );
        if (optionsIndex > -1)
          fnThis._list.splice(optionsIndex + 1, 0, fnThis._list.pop());
      }
    );
    $tomb.lib.spitroast.after(
      "createCommandWindow",
      Scene_Title.prototype,
      function() {
        this._commandWindow.setHandler(optionIcon, () => {
          SceneManager.push(Scene_Tomb);
        });
      }
    );
  }
})();
/*! Bundled license information:

fast-json-patch/module/helpers.mjs:
  (*!
   * https://github.com/Starcounter-Jack/JSON-Patch
   * (c) 2017-2022 Joachim Wester
   * MIT licensed
   *)

fast-json-patch/module/duplex.mjs:
  (*!
   * https://github.com/Starcounter-Jack/JSON-Patch
   * (c) 2017-2021 Joachim Wester
   * MIT license
   *)
*/
